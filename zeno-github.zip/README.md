# ZENO

Android AI operator (Jetpack Compose, Firebase AI Logic / Gemini, Accessibility + overlay).

## Build the APK on GitHub (no local setup)

1. Create a GitHub repo and upload the contents of this folder (keep `.github/` at the repo root).
2. Optional: add a repository secret `GOOGLE_SERVICES_JSON` (your full `google-services.json`).
   `app/google-services.json` is already included for package `com.aistudio.zeno.qvrtxb`.
3. Push to `main` (or run **Actions → Build ZENO Android APK → Run workflow**).
4. When it finishes, download **zeno-debug-apk** from the run's *Artifacts* section and install the `.apk`.

## Build locally

Android Studio (Open this folder) or, with Gradle 9.3.1 + JDK 17:

```
cp .env.example .env
gradle :app:assembleDebug
```

The debug keystore is generated automatically in CI; locally, create `debug.keystore`
(alias `androiddebugkey`, password `android`) in the project root, or remove the
`signingConfig` line from the `debug` build type.

## Using the app

Enable the ZENO Accessibility service and "Display over other apps" in Android settings.
Built-in AI needs Firebase config; alternatively choose **Compatible API** in Settings and enter your own key.
