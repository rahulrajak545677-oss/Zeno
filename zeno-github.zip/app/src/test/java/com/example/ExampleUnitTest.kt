package com.example

import com.example.zeno.accessibility.ZenoAccessibilityService
import com.example.zeno.ai.AIProvider
import com.example.zeno.ai.GeminiClientWrapper
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.core.model.ActionType
import com.example.zeno.core.model.InstalledAppInfo
import com.example.zeno.core.model.OrbState
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.RectBounds
import com.example.zeno.core.model.ScreenNode
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.StepStatus
import com.example.zeno.core.model.TaskLogEntry
import com.example.zeno.core.model.ZenoAction
import com.example.zeno.core.model.ZenoState
import com.example.zeno.data.local.TaskHistoryRepository
import com.example.zeno.data.repository.GeminiPromptRepository
import com.example.zeno.data.repository.GeminiRepository
import com.example.zeno.engine.ZenoSafetyGuard
import com.example.zeno.overlay.ZenoOverlayService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun actionTypeWireMapping_handlesSupportedActions() {
        assertEquals(ActionType.TEXT_INPUT, ActionType.fromWireName("text_input"))
        assertEquals(ActionType.SLIDER_ADJUST, ActionType.fromWireName("SLIDER_ADJUST"))
        assertEquals(ActionType.OPEN_APP, ActionType.fromWireName("open_app"))
        assertEquals(ActionType.TAP, ActionType.fromWireName("unknown_action"))
    }

    @Test
    fun orbState_mapsFromZenoEngineStates() {
        assertEquals(OrbState.THINKING, OrbState.fromZenoState(ZenoState.PLANNING))
        assertEquals(OrbState.WORKING, OrbState.fromZenoState(ZenoState.EXECUTING))
        assertEquals(OrbState.WORKING, OrbState.fromZenoState(ZenoState.VERIFYING))
        assertEquals(OrbState.PAUSED, OrbState.fromZenoState(ZenoState.PAUSED))
        assertEquals(OrbState.ERROR, OrbState.fromZenoState(ZenoState.ERROR))
        assertEquals(OrbState.COMPLETED, OrbState.fromZenoState(ZenoState.COMPLETED))
    }

    @Test
    fun screenNode_primaryLabelAndCenterBounds_workCorrectly() {
        val node = ScreenNode(
            nodeId = "n1",
            className = "android.widget.ImageButton",
            text = "",
            contentDescription = "Apply filter",
            viewIdResourceName = "com.app:id/btn_apply",
            bounds = RectBounds(10, 20, 110, 120),
            isClickable = true,
            isEditable = false,
            isScrollable = false,
            isCheckable = false,
            isChecked = false,
            isEnabled = true,
            isFocused = false,
            childCount = 0
        )
        assertEquals("Apply filter", node.primaryLabel())
        assertEquals(60, node.bounds.centerX)
        assertEquals(70, node.bounds.centerY)
    }

    @Test
    fun geminiClientWrapper_sanitizesDeprecatedOrUnknownModels() {
        assertEquals("gemini-3.8-flash", GeminiClientWrapper.sanitizeModelName("gemini-1.5-flash"))
        assertEquals("gemini-3.8-flash", GeminiClientWrapper.sanitizeModelName("unknown-model"))
        assertEquals("gemini-4-argon", GeminiClientWrapper.sanitizeModelName("gemini-4-argon"))
        assertEquals("gemini-3.5-flash-lite", GeminiClientWrapper.sanitizeModelName("gemini-3.5-flash-lite"))
    }

    @Test
    fun geminiPromptRepository_rejectsBlankPromptsSafely() = runBlocking {
        val repository = GeminiPromptRepository(GeminiClientWrapper())
        val result = repository.sendPrompt("   ")
        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull() is IllegalArgumentException)
    }

    @Test
    fun safetyGuard_blocksPasswordAuthScreens() {
        val passwordNode = ScreenNode(
            nodeId = "n0",
            className = "android.widget.EditText",
            text = "",
            contentDescription = "Password",
            viewIdResourceName = "",
            bounds = RectBounds(0, 0, 100, 50),
            isClickable = true,
            isEditable = true,
            isScrollable = false,
            isCheckable = false,
            isChecked = false,
            isEnabled = true,
            isFocused = false,
            childCount = 0,
            isPassword = true
        )
        val obs = ScreenObservation(
            timestampMs = 1L,
            packageName = "com.bank.app",
            appName = "Bank",
            windowTitle = "Sign in",
            screenWidth = 1080,
            screenHeight = 2400,
            nodes = listOf(passwordNode),
            summaryText = "Sign in",
            hasAccessibilityData = true
        )
        assertNotNull(ZenoSafetyGuard.detectSecurityOrAuthScreen(obs))
    }

    @Test
    fun safetyGuard_flagsDestructiveActionsAndUnexpectedAppSwitches() {
        val obs = ScreenObservation(
            timestampMs = 1L,
            packageName = "com.files.app",
            appName = "Files",
            windowTitle = "Files",
            screenWidth = 1080,
            screenHeight = 2400,
            nodes = emptyList(),
            summaryText = "Files",
            hasAccessibilityData = true
        )
        val action = ZenoAction(
            actionId = "a1",
            type = ActionType.TAP,
            targetLabel = "Delete permanently",
            reason = "Remove file",
            expectedOutcome = "File removed",
            isConsequential = false
        )
        val evaluated = ZenoSafetyGuard.evaluateConsequentialAction(action, obs)
        assertTrue(evaluated.isConsequential)
        assertNull(ZenoSafetyGuard.detectSecurityOrAuthScreen(obs))
        assertTrue(ZenoSafetyGuard.isUnexpectedAppSwitch("com.editor.app", "com.other.app", action))
        assertFalse(
            ZenoSafetyGuard.isUnexpectedAppSwitch(
                "com.editor.app",
                "com.google.android.permissioncontroller",
                action
            )
        )
    }

    @Test
    fun systemBridge_resolvesAppByNameOrPackage() {
        val apps = listOf(
            InstalledAppInfo("CapCut", "com.lemon.lvoverseas", "Video & Motion"),
            InstalledAppInfo("Canva", "com.canva.editor", "Photo & Design"),
            InstalledAppInfo("Files", "com.google.android.apps.nbu.files", "File Management")
        )
        assertEquals("com.lemon.lvoverseas", ZenoSystemBridge.resolveBestAppPackage(apps, "capcut"))
        assertEquals("com.canva.editor", ZenoSystemBridge.resolveBestAppPackage(apps, "com.canva.editor"))
        assertEquals("com.google.android.apps.nbu.files", ZenoSystemBridge.resolveBestAppPackage(apps, "File"))
        assertNull(ZenoSystemBridge.resolveBestAppPackage(apps, "   "))
    }

    @Test
    fun overlayService_clampsOrbWithinScreenBounds() {
        assertEquals(0 to 0, ZenoOverlayService.clampOrbPosition(-50, -20, 120, 1080, 2400))
        assertEquals(960 to 2280, ZenoOverlayService.clampOrbPosition(1500, 2600, 120, 1080, 2400))
        assertEquals(300 to 500, ZenoOverlayService.clampOrbPosition(300, 500, 120, 1080, 2400))
    }

    @Test
    fun overlayService_clampsExpandedPanelAcrossOrientations() {
        // Portrait screen (1080x2400) with orb parked near bottom-right corner
        val (px, py) = ZenoOverlayService.clampExpandedPanelPosition(
            x = 960,
            y = 2200,
            panelWidthPx = 900,
            panelHeightPx = 1200,
            screenWidthPx = 1080,
            screenHeightPx = 2400,
            marginPx = 24
        )
        assertEquals(156, px)
        assertEquals(1176, py)

        // Landscape screen (2400x1080) where vertical space is tighter than panel height + margin
        val (lx, ly) = ZenoOverlayService.clampExpandedPanelPosition(
            x = 1800,
            y = 900,
            panelWidthPx = 900,
            panelHeightPx = 1100,
            screenWidthPx = 2400,
            screenHeightPx = 1080,
            marginPx = 16
        )
        assertEquals(1484, lx)
        assertEquals(16, ly)
    }

    @Test
    fun geminiRepository_implementsAiProviderAndValidatesInputs() = runBlocking {
        val repo: AIProvider = GeminiRepository(GeminiClientWrapper())
        assertEquals("Firebase AI Logic (Gemini)", repo.providerName)

        val blankResult = repo.interpretInstruction("   ", null, GeminiClientWrapper.DEFAULT_MODEL)
        assertTrue(blankResult.isFailure)
        assertTrue(blankResult.exceptionOrNull() is IllegalArgumentException)

        val emptyObs = ScreenObservation(
            timestampMs = 1L,
            packageName = "",
            appName = "",
            windowTitle = "",
            screenWidth = 1080,
            screenHeight = 2400,
            nodes = emptyList(),
            summaryText = "",
            hasAccessibilityData = false
        )
        val missingScreenResult = repo.analyzeScreen(emptyObs, null, GeminiClientWrapper.DEFAULT_MODEL)
        assertTrue(missingScreenResult.isFailure)
        assertTrue(missingScreenResult.exceptionOrNull() is IllegalStateException)
    }

    @Test
    fun geminiRepository_parsesInstructionPlanAndVisionAnalysisJson() {
        val planJson = """
            {"steps":[
              {"title":"Open timeline","detail":"Select active video track"},
              {"title":"Apply grading","detail":"Adjust contrast and shadows"}
            ]}
        """.trimIndent()
        val steps = GeminiRepository.parsePlanStepsJson(planJson)
        assertEquals(2, steps.size)
        assertEquals("Open timeline", steps[0].title)
        assertEquals("step_2", steps[1].id)

        val analysisJson = """
            {
              "appName":"CapCut",
              "screenPurpose":"Video timeline editor workspace",
              "keyControls":["Split","Filters","Adjust","Export"],
              "accessibilityLimitation":""
            }
        """.trimIndent()
        val report = GeminiRepository.parseScreenAnalysisJson(analysisJson)
        assertEquals("CapCut", report.appName)
        assertEquals(4, report.keyControls.size)
        assertNull(report.accessibilityLimitation)
    }

    @Test
    fun accessibilityService_buildsScreenContextSummaryFromTraversedNodes() {
        val nodes = listOf(
            ScreenNode(
                nodeId = "n0",
                className = "android.widget.Button",
                text = "New project",
                contentDescription = "",
                viewIdResourceName = "com.editor:id/new_btn",
                bounds = RectBounds(20, 40, 220, 120),
                isClickable = true,
                isEditable = false,
                isScrollable = false,
                isCheckable = false,
                isChecked = false,
                isEnabled = true,
                isFocused = false,
                childCount = 0
            ),
            ScreenNode(
                nodeId = "n1",
                className = "android.widget.EditText",
                text = "",
                contentDescription = "Search templates",
                viewIdResourceName = "com.editor:id/search",
                bounds = RectBounds(20, 140, 820, 220),
                isClickable = true,
                isEditable = true,
                isScrollable = false,
                isCheckable = false,
                isChecked = false,
                isEnabled = true,
                isFocused = false,
                childCount = 0
            )
        )
        val summary = ZenoAccessibilityService.buildScreenContextSummary(
            appName = "CapCut",
            packageName = "com.lemon.lvoverseas",
            nodes = nodes
        )
        assertTrue(summary.contains("CapCut (com.lemon.lvoverseas)"))
        assertTrue(summary.contains("Visible controls: 2"))
        assertTrue(summary.contains("New project"))
        assertTrue(summary.contains("Search templates"))
    }

    @Test
    fun taskHistoryRepository_planAndLogJsonRoundtrip_works() {
        val plan = listOf(
            PlanStep(
                id = "step_1",
                title = "Inspect screen",
                status = StepStatus.VERIFIED,
                detail = "Done"
            )
        )
        val logs = listOf(
            TaskLogEntry(
                id = "l1",
                timestampMs = 1000L,
                phase = "VERIFY",
                message = "Confirmed",
                isVerified = true,
                isError = false
            )
        )
        val parsedPlan = TaskHistoryRepository.parsePlan(TaskHistoryRepository.serializePlan(plan))
        val parsedLogs = TaskHistoryRepository.parseLogs(TaskHistoryRepository.serializeLogs(logs))
        assertEquals(1, parsedPlan.size)
        assertEquals("Inspect screen", parsedPlan.first().title)
        assertEquals(StepStatus.VERIFIED, parsedPlan.first().status)
        assertEquals(1, parsedLogs.size)
        assertTrue(parsedLogs.first().isVerified)
    }
}
