package com.example.zeno.ai

import android.graphics.Bitmap
import com.example.zeno.core.model.AiDecisionResult
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.ScreenAnalysisReport
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.VerificationResult
import com.example.zeno.core.model.ZenoAction
import com.example.zeno.data.repository.GeminiPromptRepository
import com.example.zeno.data.repository.GeminiRepository

/**
 * Adapter bridging ZENO's [ZenoAiProvider] / [AIProvider] contract to [GeminiRepository],
 * backed by Firebase AI Logic (`Firebase.ai`) and App Check.
 */
class FirebaseAiLogicProvider(
    clientWrapper: GeminiClientWrapper = GeminiClientWrapper(),
    promptRepository: GeminiPromptRepository = GeminiPromptRepository(clientWrapper),
    private val geminiRepository: GeminiRepository = GeminiRepository(
        clientWrapper = clientWrapper,
        promptRepository = promptRepository
    )
) : ZenoAiProvider, AIProvider by geminiRepository {

    override suspend fun createNeuralPlan(
        instruction: String,
        observation: ScreenObservation?,
        modelName: String
    ): Result<List<PlanStep>> = geminiRepository.interpretInstruction(
        instruction = instruction,
        observation = observation,
        modelName = modelName
    )

    override suspend fun decideNextAction(
        memory: TaskMemory,
        observation: ScreenObservation,
        screenshot: Bitmap?,
        textModel: String,
        visionModel: String
    ): Result<AiDecisionResult> = geminiRepository.decideNextAction(
        memory = memory,
        observation = observation,
        screenshot = screenshot,
        textModel = textModel,
        visionModel = visionModel
    )

    override suspend fun verifyActionOutcome(
        action: ZenoAction,
        before: ScreenObservation,
        after: ScreenObservation,
        screenshot: Bitmap?,
        modelName: String
    ): Result<VerificationResult> = geminiRepository.verifyActionOutcome(
        action = action,
        before = before,
        after = after,
        screenshot = screenshot,
        modelName = modelName
    )

    override suspend fun analyzeScreen(
        observation: ScreenObservation,
        screenshot: Bitmap?,
        modelName: String
    ): Result<ScreenAnalysisReport> = geminiRepository.analyzeScreen(
        observation = observation,
        screenshot = screenshot,
        modelName = modelName
    )
}

