package com.example.zeno.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Minimize
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.ui.theme.ZenoBgPrimary
import com.example.ui.theme.ZenoBgSecondary
import com.example.ui.theme.ZenoBorder
import com.example.ui.theme.ZenoCardBg
import com.example.ui.theme.ZenoElevatedBg
import com.example.ui.theme.ZenoError
import com.example.ui.theme.ZenoSuccess
import com.example.ui.theme.ZenoTextPrimary
import com.example.ui.theme.ZenoTextSecondary
import com.example.ui.theme.ZenoTheme
import com.example.ui.theme.ZenoWarning
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.core.model.OrbState
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.ZenoState
import com.example.zeno.data.local.AnimationIntensity
import com.example.zeno.data.local.ZenoPreferencesRepository
import com.example.zeno.data.local.ZenoSettings
import com.example.zeno.engine.ZenoAgentEngine
import com.example.zeno.ui.components.PlanStepRow
import com.example.zeno.ui.components.ZenoLogoMark
import com.example.zeno.ui.components.ZenoStatusPill
import com.example.zeno.ui.components.formatElapsed
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private const val TAG = "ZenoOverlayService"
private const val CHANNEL_ID = "zeno_overlay_channel"
private const val NOTIFICATION_ID = 4101

class ZenoOverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    private lateinit var windowManager: WindowManager
    private lateinit var prefsRepo: ZenoPreferencesRepository
    private lateinit var engine: ZenoAgentEngine
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var overlayView: ComposeView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var isExpandedState = mutableStateOf(false)
    private var isEditingPromptState = mutableStateOf(false)
    private var savedOrbPos: Pair<Int, Int>? = null
    private var currentOrbSizeDp: Int = 58
    private var overlayAttachStarted: Boolean = false

    override fun onCreate() {
        super.onCreate()
        savedStateController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefsRepo = ZenoPreferencesRepository(applicationContext)
        engine = ZenoAgentEngine.getInstance(applicationContext)

        createNotificationChannel()
        val notification = buildNotification(engine.taskMemory.value)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "SYSTEM_ALERT_WINDOW permission missing; stopping overlay service.")
            stopSelf()
            return
        }

        ensureOverlayAttached()
        serviceScope.launch {
            val notificationManager = getSystemService(NotificationManager::class.java)
            engine.taskMemory
                .distinctUntilChangedBy { Triple(it.status, it.currentOperation, it.targetAppName) }
                .collect { memory ->
                    runCatching {
                        notificationManager?.notify(NOTIFICATION_ID, buildNotification(memory))
                    }
                }
        }
        ZenoSystemBridge.setOverlayRunning(true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Overlay permission revoked; stopping ZenoOverlayService.")
            stopSelf()
            return START_NOT_STICKY
        }
        ensureOverlayAttached()
        when (intent?.action) {
            ACTION_EXPAND -> expandPanel()
            ACTION_COLLAPSE -> collapsePanel()
            ACTION_PAUSE_TASK -> engine.pauseTask("Paused from notification")
            ACTION_RESUME_TASK -> engine.resumeTask()
            ACTION_STOP_TASK -> engine.stopTask()
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val lp = layoutParams ?: return
        val view = overlayView ?: return
        val (screenW, screenH) = getOverlayScreenBounds()
        val density = resources.displayMetrics.density
        if (isExpandedState.value) {
            val panelW = (EXPANDED_PANEL_WIDTH_DP * density).roundToInt()
            val panelH = (EXPANDED_PANEL_APPROX_HEIGHT_DP * density).roundToInt()
            val (nextX, nextY) = clampExpandedPanelPosition(lp.x, lp.y, panelW, panelH, screenW, screenH)
            lp.x = nextX
            lp.y = nextY
            savedOrbPos?.let { (ox, oy) ->
                val orbPx = (currentOrbSizeDp * density).roundToInt()
                savedOrbPos = clampOrbPosition(ox, oy, orbPx, screenW, screenH)
            }
        } else {
            val orbPx = (currentOrbSizeDp * density).roundToInt()
            val (nextX, nextY) = clampOrbPosition(lp.x, lp.y, orbPx, screenW, screenH)
            lp.x = nextX
            lp.y = nextY
            savedOrbPos = nextX to nextY
        }
        runCatching { windowManager.updateViewLayout(view, lp) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        ZenoSystemBridge.setOverlayRunning(false)
        overlayView?.let { view ->
            runCatching { windowManager.removeView(view) }
        }
        overlayView = null
        layoutParams = null
        serviceScope.cancel()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        super.onDestroy()
    }

    private fun ensureOverlayAttached() {
        if (overlayView != null || overlayAttachStarted) return
        overlayAttachStarted = true
        serviceScope.launch {
            val settings = prefsRepo.settingsFlow.first()
            currentOrbSizeDp = settings.orbSizeDp
            if (engine.taskMemory.value.originalInstruction.isBlank() &&
                settings.savedInstruction.isNotBlank()
            ) {
                engine.setInstructionDraft(settings.savedInstruction)
            }
            attachOverlayWindow(settings.orbPosX, settings.orbPosY, settings.orbSizeDp)
        }
    }

    private fun attachOverlayWindow(initialX: Int, initialY: Int, orbSizeDp: Int) {
        if (overlayView != null) return
        val (screenW, screenH) = getOverlayScreenBounds()
        val orbSizePx = (orbSizeDp * resources.displayMetrics.density).roundToInt()
        val (clampedX, clampedY) = clampOrbPosition(initialX, initialY, orbSizePx, screenW, screenH)
        savedOrbPos = clampedX to clampedY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = clampedX
            y = clampedY
        }
        layoutParams = params

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@ZenoOverlayService)
            setViewTreeViewModelStoreOwner(this@ZenoOverlayService)
            setViewTreeSavedStateRegistryOwner(this@ZenoOverlayService)
            setContent {
                val settings by prefsRepo.settingsFlow.collectAsStateWithLifecycle(initialValue = ZenoSettings())
                currentOrbSizeDp = settings.orbSizeDp
                val memory by engine.taskMemory.collectAsStateWithLifecycle()
                val observation by ZenoSystemBridge.latestObservation.collectAsStateWithLifecycle()
                val a11yConnected by ZenoSystemBridge.isAccessibilityConnected.collectAsStateWithLifecycle()
                val captureActive by ZenoSystemBridge.isScreenCaptureActive.collectAsStateWithLifecycle()
                val expanded by isExpandedState
                var editing by isEditingPromptState

                ZenoTheme(
                    darkTheme = settings.darkTheme,
                    accentStyle = settings.accentStyle
                ) {
                    if (!expanded) {
                        CollapsedZenoOrb(
                            orbState = OrbState.fromZenoState(memory.status),
                            sizeDp = settings.orbSizeDp,
                            alpha = settings.orbTransparency,
                            animationIntensity = settings.animationIntensity,
                            hapticsEnabled = settings.hapticsEnabled,
                            onTap = { expandPanel() },
                            onDragDelta = { dx, dy ->
                                val lp = this@ZenoOverlayService.layoutParams ?: return@CollapsedZenoOrb
                                val (curW, curH) = getOverlayScreenBounds()
                                val sizePx = (settings.orbSizeDp * resources.displayMetrics.density).roundToInt()
                                val (nextX, nextY) = clampOrbPosition(
                                    x = lp.x + dx.roundToInt(),
                                    y = lp.y + dy.roundToInt(),
                                    orbSizePx = sizePx,
                                    screenWidthPx = curW,
                                    screenHeightPx = curH
                                )
                                lp.x = nextX
                                lp.y = nextY
                                savedOrbPos = nextX to nextY
                                runCatching { windowManager.updateViewLayout(this@apply, lp) }
                            },
                            onDragEnd = {
                                val lp = this@ZenoOverlayService.layoutParams ?: return@CollapsedZenoOrb
                                serviceScope.launch {
                                    prefsRepo.updateOrbPosition(lp.x, lp.y)
                                }
                            }
                        )
                    } else {
                        ExpandedOrbPanel(
                            memory = memory,
                            settings = settings,
                            currentAppName = observation?.appName ?: if (a11yConnected) "Ready" else "A11y Off",
                            hasVision = a11yConnected || captureActive,
                            isEditing = editing,
                            onHeaderDragDelta = { dx, dy ->
                                val lp = this@ZenoOverlayService.layoutParams ?: return@ExpandedOrbPanel
                                val (curW, curH) = getOverlayScreenBounds()
                                val density = resources.displayMetrics.density
                                val panelW = (EXPANDED_PANEL_WIDTH_DP * density).roundToInt()
                                val panelH = (EXPANDED_PANEL_APPROX_HEIGHT_DP * density).roundToInt()
                                val (nextX, nextY) = clampExpandedPanelPosition(
                                    x = lp.x + dx.roundToInt(),
                                    y = lp.y + dy.roundToInt(),
                                    panelWidthPx = panelW,
                                    panelHeightPx = panelH,
                                    screenWidthPx = curW,
                                    screenHeightPx = curH
                                )
                                lp.x = nextX
                                lp.y = nextY
                                runCatching { windowManager.updateViewLayout(this@apply, lp) }
                            },
                            onToggleEditing = { nextEdit ->
                                editing = nextEdit
                                updateFocusability(nextEdit)
                            },
                            onUpdateInstruction = { text ->
                                engine.updateInstructionLive(text)
                                editing = false
                                updateFocusability(false)
                            },
                            onVoiceInput = {
                                OrbVoiceInputActivity.launch(this@ZenoOverlayService, applyToEngine = true)
                            },
                            onStart = {
                                collapsePanel()
                                engine.startTask()
                            },
                            onPause = { engine.pauseTask() },
                            onResume = {
                                collapsePanel()
                                engine.resumeTask()
                            },
                            onStop = { engine.stopTask() },
                            onConfirmConsequential = { engine.confirmPendingConsequentialAction() },
                            onCancelConsequential = { engine.cancelPendingConsequentialAction() },
                            onMinimize = { collapsePanel() },
                            onClose = { stopSelf() }
                        )
                    }
                }
            }
        }
        overlayView = composeView
        windowManager.addView(composeView, params)
    }

    private fun expandPanel() {
        val lp = layoutParams
        val view = overlayView
        if (lp != null) {
            if (!isExpandedState.value) {
                savedOrbPos = lp.x to lp.y
            }
            val (screenW, screenH) = getOverlayScreenBounds()
            val density = resources.displayMetrics.density
            val panelW = (EXPANDED_PANEL_WIDTH_DP * density).roundToInt()
            val panelH = (EXPANDED_PANEL_APPROX_HEIGHT_DP * density).roundToInt()
            val (nextX, nextY) = clampExpandedPanelPosition(
                x = lp.x,
                y = lp.y,
                panelWidthPx = panelW,
                panelHeightPx = panelH,
                screenWidthPx = screenW,
                screenHeightPx = screenH
            )
            lp.x = nextX
            lp.y = nextY
            if (view != null) {
                runCatching { windowManager.updateViewLayout(view, lp) }
            }
        }
        isExpandedState.value = true
        updateFocusability(isEditingPromptState.value)
    }

    private fun collapsePanel() {
        isEditingPromptState.value = false
        isExpandedState.value = false
        val lp = layoutParams
        val view = overlayView
        if (lp != null) {
            val (screenW, screenH) = getOverlayScreenBounds()
            val orbPx = (currentOrbSizeDp * resources.displayMetrics.density).roundToInt()
            val target = savedOrbPos ?: (lp.x to lp.y)
            val (nextX, nextY) = clampOrbPosition(
                x = target.first,
                y = target.second,
                orbSizePx = orbPx,
                screenWidthPx = screenW,
                screenHeightPx = screenH
            )
            lp.x = nextX
            lp.y = nextY
            savedOrbPos = nextX to nextY
            if (view != null) {
                runCatching { windowManager.updateViewLayout(view, lp) }
            }
        }
        updateFocusability(false)
    }

    private fun updateFocusability(focusable: Boolean) {
        val lp = layoutParams ?: return
        val view = overlayView ?: return
        lp.flags = if (focusable) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        runCatching { windowManager.updateViewLayout(view, lp) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.overlay_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.overlay_notification_channel_desc)
            }
            mgr.createNotificationChannel(channel)
        }
    }

    private fun getOverlayScreenBounds(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }
    }

    private fun buildNotification(memory: TaskMemory): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val pauseIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, ZenoOverlayService::class.java).apply { action = ACTION_PAUSE_TASK },
            PendingIntent.FLAG_IMMUTABLE
        )
        val resumeIntent = PendingIntent.getService(
            this,
            4,
            Intent(this, ZenoOverlayService::class.java).apply { action = ACTION_RESUME_TASK },
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopTaskIntent = PendingIntent.getService(
            this,
            3,
            Intent(this, ZenoOverlayService::class.java).apply { action = ACTION_STOP_TASK },
            PendingIntent.FLAG_IMMUTABLE
        )
        val hideOrbIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ZenoOverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        val title = when {
            memory.status.isRunning -> "ZENO ${memory.status.label} • ${memory.targetAppName.ifBlank { "AutoPilot" }}"
            memory.status == ZenoState.PAUSED -> "ZENO Paused"
            memory.status == ZenoState.COMPLETED -> "ZENO Completed"
            memory.status == ZenoState.ERROR -> "ZENO Needs Attention"
            else -> "ZENO Orb Active"
        }
        val body = memory.currentOperation.ifBlank {
            "Tap the floating orb in any app to start, pause, or stop ZENO"
        }

        val builder = androidx.core.app.NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent)

        when {
            memory.status.isRunning -> {
                builder.addAction(0, "Pause", pauseIntent)
                builder.addAction(0, "Stop", stopTaskIntent)
            }
            memory.status == ZenoState.PAUSED || memory.status == ZenoState.ERROR -> {
                builder.addAction(0, "Resume", resumeIntent)
                builder.addAction(0, "Stop", stopTaskIntent)
            }
        }
        builder.addAction(0, "Hide Orb", hideOrbIntent)
        return builder.build()
    }

    companion object {
        private const val EXPANDED_PANEL_WIDTH_DP = 326
        private const val EXPANDED_PANEL_APPROX_HEIGHT_DP = 460

        const val ACTION_STOP = "com.example.zeno.ACTION_STOP_ORB"
        const val ACTION_EXPAND = "com.example.zeno.ACTION_EXPAND_ORB"
        const val ACTION_COLLAPSE = "com.example.zeno.ACTION_COLLAPSE_ORB"
        const val ACTION_PAUSE_TASK = "com.example.zeno.ACTION_PAUSE_TASK"
        const val ACTION_RESUME_TASK = "com.example.zeno.ACTION_RESUME_TASK"
        const val ACTION_STOP_TASK = "com.example.zeno.ACTION_STOP_TASK"

        fun clampOrbPosition(
            x: Int,
            y: Int,
            orbSizePx: Int,
            screenWidthPx: Int,
            screenHeightPx: Int
        ): Pair<Int, Int> {
            val safeSize = orbSizePx.coerceAtLeast(1)
            val maxX = (screenWidthPx - safeSize).coerceAtLeast(0)
            val maxY = (screenHeightPx - safeSize).coerceAtLeast(0)
            return x.coerceIn(0, maxX) to y.coerceIn(0, maxY)
        }

        fun clampExpandedPanelPosition(
            x: Int,
            y: Int,
            panelWidthPx: Int,
            panelHeightPx: Int,
            screenWidthPx: Int,
            screenHeightPx: Int,
            marginPx: Int = 16
        ): Pair<Int, Int> {
            val safeMargin = marginPx.coerceAtLeast(0)
            val usableW = (screenWidthPx - panelWidthPx - safeMargin).coerceAtLeast(safeMargin)
            val usableH = (screenHeightPx - panelHeightPx - safeMargin).coerceAtLeast(safeMargin)
            return x.coerceIn(safeMargin, usableW) to y.coerceIn(safeMargin, usableH)
        }

        fun start(context: Context) {
            val intent = Intent(context, ZenoOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ZenoOverlayService::class.java))
        }
    }
}

@Composable
private fun CollapsedZenoOrb(
    orbState: OrbState,
    sizeDp: Int,
    alpha: Float,
    animationIntensity: AnimationIntensity,
    hapticsEnabled: Boolean,
    onTap: () -> Unit,
    onDragDelta: (Float, Float) -> Unit,
    onDragEnd: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val accent = MaterialTheme.colorScheme.primary
    val ringColor = when (orbState) {
        OrbState.IDLE -> ZenoTextSecondary
        OrbState.READY -> ZenoSuccess
        OrbState.LISTENING, OrbState.PAUSED -> ZenoWarning
        OrbState.THINKING, OrbState.WORKING -> accent
        OrbState.ERROR -> ZenoError
        OrbState.COMPLETED -> ZenoSuccess
    }

    val transition = rememberInfiniteTransition(label = "orb_ring")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when {
                    orbState == OrbState.WORKING || orbState == OrbState.THINKING -> 1600
                    animationIntensity == AnimationIntensity.MINIMAL -> 5000
                    else -> 3400
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_rotate"
    )

    val showMiniBadge = orbState == OrbState.WORKING ||
        orbState == OrbState.THINKING ||
        orbState == OrbState.PAUSED ||
        orbState == OrbState.ERROR

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .alpha(alpha)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = { onDragEnd() },
                    onDragCancel = { onDragEnd() }
                ) { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            }
    ) {
        Box(
            modifier = Modifier
                .size(sizeDp.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(ZenoElevatedBg, ZenoBgPrimary)
                    )
                )
                .drawBehind {
                    val stroke = 3.dp.toPx()
                    drawCircle(
                        color = ringColor.copy(alpha = 0.22f),
                        style = Stroke(width = stroke)
                    )
                    if (animationIntensity != AnimationIntensity.MINIMAL ||
                        orbState == OrbState.WORKING || orbState == OrbState.THINKING
                    ) {
                        rotate(angle) {
                            drawArc(
                                color = ringColor,
                                startAngle = 0f,
                                sweepAngle = if (orbState == OrbState.WORKING) 220f else 110f,
                                useCenter = false,
                                style = Stroke(width = stroke)
                            )
                        }
                    } else {
                        drawCircle(color = ringColor, style = Stroke(width = stroke))
                    }
                }
                .clickable(role = Role.Button) {
                    if (hapticsEnabled) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                    onTap()
                }
                .semantics {
                    contentDescription = "Open ZENO floating controls (${orbState.name})"
                }
                .testTag("zeno_floating_orb"),
            contentAlignment = Alignment.Center
        ) {
            ZenoLogoMark(size = (sizeDp * 0.56f).dp)
        }
        if (showMiniBadge) {
            Spacer(Modifier.height(3.dp))
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = ZenoBgPrimary.copy(alpha = 0.92f),
                border = BorderStroke(1.dp, ringColor.copy(alpha = 0.7f))
            ) {
                Text(
                    text = orbState.name,
                    style = MaterialTheme.typography.labelSmall,
                    color = ringColor,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                )
            }
        }
    }
}

@Composable
private fun ExpandedOrbPanel(
    memory: com.example.zeno.core.model.TaskMemory,
    settings: ZenoSettings,
    currentAppName: String,
    hasVision: Boolean,
    isEditing: Boolean,
    onHeaderDragDelta: (Float, Float) -> Unit,
    onToggleEditing: (Boolean) -> Unit,
    onUpdateInstruction: (String) -> Unit,
    onVoiceInput: () -> Unit,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onConfirmConsequential: () -> Unit,
    onCancelConsequential: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit
) {
    var draftText by remember(memory.originalInstruction) {
        mutableStateOf(memory.originalInstruction)
    }

    LaunchedEffect(memory.originalInstruction) {
        if (!isEditing) {
            draftText = memory.originalInstruction
        }
    }

    Surface(
        modifier = Modifier
            .width(326.dp)
            .heightIn(max = 520.dp),
        shape = RoundedCornerShape(22.dp),
        color = ZenoBgSecondary.copy(alpha = 0.96f),
        border = BorderStroke(1.dp, ZenoBorder),
        shadowElevation = 14.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Draggable Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onHeaderDragDelta(dragAmount.x, dragAmount.y)
                        }
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ZenoLogoMark(size = 24.dp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "ZENO AI",
                            style = MaterialTheme.typography.titleMedium,
                            color = ZenoTextPrimary,
                            maxLines = 1
                        )
                        Text(
                            text = "App: $currentAppName",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenoTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ZenoStatusPill(state = memory.status)
                    IconButton(
                        onClick = onMinimize,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("orb_minimize_btn")
                    ) {
                        Icon(
                            Icons.Rounded.Minimize,
                            contentDescription = "Minimize orb",
                            tint = ZenoTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("orb_close_btn")
                    ) {
                        Icon(
                            Icons.Rounded.Close,
                            contentDescription = "Close orb",
                            tint = ZenoTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Mode chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OverlayModeChip("Vision", active = hasVision)
                OverlayModeChip("AutoPilot", active = settings.autoPilotEnabled)
                OverlayModeChip("Self-Check", active = settings.verificationEnabled)
            }

            Spacer(Modifier.height(10.dp))

            // Instruction Area
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = ZenoCardBg,
                border = BorderStroke(1.dp, ZenoBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    if (isEditing) {
                        OutlinedTextField(
                            value = draftText,
                            onValueChange = { draftText = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Edit ZENO instruction...") },
                            maxLines = 3
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(onClick = { onToggleEditing(false) }) {
                                Text("Cancel")
                            }
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { onUpdateInstruction(draftText) }) {
                                Icon(Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Apply")
                            }
                        }
                    } else {
                        Text(
                            text = memory.originalInstruction.ifBlank {
                                "Open ZENO or tap edit/mic to enter a task instruction."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextPrimary,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            IconButton(
                                onClick = onVoiceInput,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("orb_voice_btn")
                            ) {
                                Icon(
                                    Icons.Rounded.Mic,
                                    contentDescription = "Voice instruction",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { onToggleEditing(true) },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("orb_edit_btn")
                            ) {
                                Icon(
                                    Icons.Rounded.Edit,
                                    contentDescription = "Edit instruction",
                                    tint = ZenoTextSecondary,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Consequential action safety gate
            if (memory.pendingConfirmationReason != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ZenoWarning.copy(alpha = 0.14f))
                        .border(1.dp, ZenoWarning.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "Confirm Action",
                            style = MaterialTheme.typography.labelLarge,
                            color = ZenoWarning
                        )
                        Text(
                            text = memory.pendingConfirmationReason,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextPrimary
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onConfirmConsequential,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ZenoWarning,
                                    contentColor = ZenoBgPrimary
                                )
                            ) { Text("Proceed") }
                            OutlinedButton(onClick = onCancelConsequential) { Text("Cancel") }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            // Main Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when {
                    memory.status.isRunning -> {
                        Button(
                            onClick = onPause,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("orb_pause_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ZenoWarning,
                                contentColor = ZenoBgPrimary
                            )
                        ) {
                            Icon(Icons.Rounded.Pause, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("PAUSE")
                        }
                        OutlinedButton(
                            onClick = onStop,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("orb_stop_btn")
                        ) {
                            Icon(Icons.Rounded.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("STOP")
                        }
                    }
                    memory.status == ZenoState.PAUSED -> {
                        Button(
                            onClick = onResume,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("orb_resume_btn")
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("RESUME")
                        }
                        OutlinedButton(
                            onClick = onStop,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("orb_stop_btn")
                        ) {
                            Icon(Icons.Rounded.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("STOP")
                        }
                    }
                    else -> {
                        Button(
                            onClick = onStart,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("orb_start_btn")
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("START AUTOPILOT")
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Live Progress & Logs
            Text(
                text = "${memory.currentOperation} • ${formatElapsed(memory.elapsedMs)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 170.dp)
            ) {
                if (memory.plan.isNotEmpty()) {
                    items(memory.plan, key = { it.id }) { step ->
                        PlanStepRow(step = step)
                    }
                } else {
                    items(memory.logs.takeLast(6), key = { it.id }) { log ->
                        Text(
                            text = "[${log.phase}] ${log.message}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (log.isError) ZenoError else ZenoTextSecondary,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OverlayModeChip(
    label: String,
    active: Boolean
) {
    val accent = MaterialTheme.colorScheme.primary
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (active) accent.copy(alpha = 0.14f) else ZenoCardBg,
        border = BorderStroke(
            1.dp,
            if (active) accent.copy(alpha = 0.45f) else ZenoBorder
        )
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) accent else ZenoTextSecondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
