package com.example.zeno.core.model

import android.graphics.Rect

enum class ZenoState(val label: String) {
    IDLE("Idle"),
    READY("Ready"),
    OFFLINE("Offline"),
    LISTENING("Listening"),
    OBSERVING("Observing"),
    THINKING("Thinking"),
    PLANNING("Planning"),
    EXECUTING("Executing"),
    VERIFYING("Verifying"),
    WAITING("Waiting"),
    WORKING("Working"),
    PAUSED("Paused"),
    COMPLETED("Completed"),
    FAILED("Failed"),
    CANCELLED("Cancelled"),
    ERROR("Error");

    val isRunning: Boolean
        get() = this == OBSERVING || this == THINKING || this == PLANNING ||
            this == EXECUTING || this == VERIFYING || this == WAITING || this == WORKING
}

enum class OrbState(val label: String) {
    IDLE("Idle"),
    READY("Ready"),
    LISTENING("Listening"),
    THINKING("Thinking"),
    WORKING("Working"),
    PAUSED("Paused"),
    ERROR("Error"),
    COMPLETED("Completed");

    companion object {
        fun fromZenoState(state: ZenoState): OrbState = when (state) {
            ZenoState.IDLE -> IDLE
            ZenoState.READY, ZenoState.OFFLINE -> READY
            ZenoState.LISTENING -> LISTENING
            ZenoState.OBSERVING, ZenoState.THINKING, ZenoState.PLANNING -> THINKING
            ZenoState.EXECUTING, ZenoState.VERIFYING, ZenoState.WAITING, ZenoState.WORKING -> WORKING
            ZenoState.PAUSED -> PAUSED
            ZenoState.FAILED, ZenoState.ERROR -> ERROR
            ZenoState.COMPLETED, ZenoState.CANCELLED -> COMPLETED
        }
    }
}

enum class ActionType(val wireName: String) {
    TAP("tap"),
    LONG_PRESS("long_press"),
    SWIPE("swipe"),
    SCROLL("scroll"),
    DRAG("drag"),
    TEXT_INPUT("text_input"),
    BACK("back"),
    NAVIGATE("navigate"),
    OPEN_APP("open_app"),
    SELECT_ELEMENT("select_element"),
    SLIDER_ADJUST("slider_adjust"),
    WAIT("wait"),
    SCREENSHOT("screenshot"),
    OBSERVE("observe"),
    VERIFY("verify"),
    ASK_USER("ask_user");

    companion object {
        fun fromWireName(value: String): ActionType {
            val normalized = value.trim().lowercase()
            return entries.firstOrNull { it.wireName == normalized } ?: TAP
        }
    }
}

enum class StepStatus {
    PENDING,
    IN_PROGRESS,
    VERIFIED,
    FAILED,
    SKIPPED
}

data class RectBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val width: Int get() = (right - left).coerceAtLeast(0)
    val height: Int get() = (bottom - top).coerceAtLeast(0)

    fun toRect(): Rect = Rect(left, top, right, bottom)
    fun toShortString(): String = "[$left,$top,$right,$bottom]"
}

data class ScreenNode(
    val nodeId: String,
    val className: String,
    val text: String,
    val contentDescription: String,
    val viewIdResourceName: String,
    val bounds: RectBounds,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean,
    val isCheckable: Boolean,
    val isChecked: Boolean,
    val isEnabled: Boolean,
    val isFocused: Boolean,
    val childCount: Int,
    val isPassword: Boolean = false
) {
    fun primaryLabel(): String {
        return text.ifBlank { contentDescription }.ifBlank {
            viewIdResourceName.substringAfterLast('/').ifBlank {
                className.substringAfterLast('.')
            }
        }
    }
}

data class ScreenObservation(
    val timestampMs: Long,
    val packageName: String,
    val appName: String,
    val windowTitle: String,
    val screenWidth: Int,
    val screenHeight: Int,
    val nodes: List<ScreenNode>,
    val summaryText: String,
    val hasAccessibilityData: Boolean,
    val hasScreenshot: Boolean = false
)

data class ZenoAction(
    val actionId: String,
    val type: ActionType,
    val targetNodeId: String = "",
    val targetLabel: String = "",
    val x: Int? = null,
    val y: Int? = null,
    val endX: Int? = null,
    val endY: Int? = null,
    val inputText: String = "",
    val packageName: String = "",
    val scrollDirection: String = "forward",
    val sliderPercent: Float? = null,
    val reason: String,
    val expectedOutcome: String,
    val verificationMethod: String = "screen_diff_and_ai",
    val timeoutMs: Long = 8000L,
    val retryPolicyMax: Int = 2,
    val isConsequential: Boolean = false
)

data class PlanStep(
    val id: String,
    val title: String,
    val status: StepStatus = StepStatus.PENDING,
    val detail: String = ""
)

data class TaskLogEntry(
    val id: String,
    val timestampMs: Long,
    val phase: String,
    val message: String,
    val isVerified: Boolean = false,
    val isError: Boolean = false
)

data class TaskMemory(
    val taskId: String = "",
    val taskTitle: String = "",
    val originalInstruction: String = "",
    val targetAppPackage: String = "",
    val targetAppName: String = "No active app",
    val plan: List<PlanStep> = emptyList(),
    val completedSteps: Int = 0,
    val failedSteps: Int = 0,
    val verifiedActionsCount: Int = 0,
    val totalActionsCount: Int = 0,
    val currentScreenSummary: String = "",
    val currentOperation: String = "Ready for instruction",
    val lastAction: ZenoAction? = null,
    val lastVerification: String = "Not yet verified",
    val pendingAction: ZenoAction? = null,
    val pendingConfirmationReason: String? = null,
    val retryCount: Int = 0,
    val status: ZenoState = ZenoState.READY,
    val startTimeMs: Long = 0L,
    val elapsedMs: Long = 0L,
    val logs: List<TaskLogEntry> = emptyList()
)

data class PromptTemplate(
    val id: String,
    val title: String,
    val category: String,
    val prompt: String
)

data class InstalledAppInfo(
    val appName: String,
    val packageName: String,
    val categoryHint: String
)

data class AiDecisionResult(
    val isTaskComplete: Boolean,
    val completionSummary: String,
    val activeStepIndex: Int,
    val needsUserInput: Boolean,
    val userPromptReason: String,
    val nextAction: ZenoAction?
)

data class VerificationResult(
    val verified: Boolean,
    val confidenceSummary: String,
    val uiChanged: Boolean,
    val shouldReplan: Boolean
)

data class ScreenAnalysisReport(
    val appName: String,
    val screenPurpose: String,
    val keyControls: List<String>,
    val accessibilityLimitation: String?
)
