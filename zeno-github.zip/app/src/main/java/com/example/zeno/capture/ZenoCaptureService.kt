package com.example.zeno.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.zeno.core.ZenoSystemBridge
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

private const val TAG = "ZenoCaptureService"
private const val CHANNEL_ID = "zeno_capture_channel"
private const val NOTIFICATION_ID = 4102

class ZenoCaptureService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = mgr.getMediaProjection(resultCode, resultData)
            if (projection != null) {
                projection.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        Log.i(TAG, "MediaProjection stopped by system/user")
                        releaseProjection()
                    }
                }, Handler(Looper.getMainLooper()))
                activeProjection = projection
                appContextRef = applicationContext
                ZenoSystemBridge.setScreenCaptureActive(true)
            } else {
                stopSelf()
            }
        } else {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        releaseProjection()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.capture_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.capture_notification_channel_desc)
            }
            mgr.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("ZENO Screen Vision Ready")
            .setContentText("On-demand visual inspection active only during tasks")
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .build()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        private var activeProjection: MediaProjection? = null
        private var appContextRef: Context? = null
        private val captureMutex = Mutex()

        fun stopCaptureService(context: Context) {
            releaseProjection()
            context.stopService(Intent(context, ZenoCaptureService::class.java))
        }

        private fun releaseProjection() {
            runCatching { activeProjection?.stop() }
            activeProjection = null
            ZenoSystemBridge.setScreenCaptureActive(false)
        }

        suspend fun captureSingleFrame(): Bitmap? = captureMutex.withLock {
            val projection = activeProjection ?: return null
            val ctx = appContextRef ?: return null
            var imageReader: ImageReader? = null
            var virtualDisplay: VirtualDisplay? = null
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealMetrics(metrics)
                val width = (metrics.widthPixels / 2).coerceAtLeast(360)
                val height = (metrics.heightPixels / 2).coerceAtLeast(640)
                val density = metrics.densityDpi

                imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
                virtualDisplay = projection.createVirtualDisplay(
                    "ZenoVisionCapture",
                    width,
                    height,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.surface,
                    null,
                    null
                )
                delay(180L)
                val image = imageReader.acquireLatestImage() ?: return null
                image.use { img ->
                    val plane = img.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val raw = Bitmap.createBitmap(
                        width + rowPadding / pixelStride,
                        height,
                        Bitmap.Config.ARGB_8888
                    )
                    raw.copyPixelsFromBuffer(buffer)
                    val cropped = Bitmap.createBitmap(raw, 0, 0, width, height)
                    if (cropped !== raw) raw.recycle()
                    return cropped
                }
            } catch (se: SecurityException) {
                Log.w(TAG, "MediaProjection token expired or revoked; resetting session.", se)
                stopCaptureService(ctx)
                null
            } catch (e: Exception) {
                Log.e(TAG, "Failed to capture single MediaProjection frame", e)
                null
            } finally {
                runCatching { virtualDisplay?.release() }
                runCatching { imageReader?.close() }
            }
        }
    }
}
