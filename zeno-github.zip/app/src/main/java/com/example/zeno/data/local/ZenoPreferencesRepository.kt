package com.example.zeno.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.zenoDataStore: DataStore<Preferences> by preferencesDataStore(name = "zeno_prefs")

enum class AccentStyle(val label: String, val primaryHex: Long, val secondaryHex: Long) {
    ELECTRIC_LIME("Electric Lime", 0xFFC6FF45, 0xFF93C42F),
    SOLAR_LIME("Solar Volt", 0xFFD9FF54, 0xFFA4D12E),
    CYBER_MINT("Hyper Mint", 0xFF9BFF64, 0xFF67C93A)
}

enum class AnimationIntensity(val label: String) {
    HIGH("Fluid"),
    BALANCED("Balanced"),
    MINIMAL("Minimal")
}

enum class AiProviderType(val label: String) {
    FIREBASE_GEMINI("Firebase AI Logic (Gemini)"),
    CUSTOM_COMPATIBLE("Compatible REST Provider")
}

enum class ReasoningDepth(val label: String) {
    FAST("Fast"),
    BALANCED("Balanced"),
    DEEP("Deep")
}

data class ZenoSettings(
    val darkTheme: Boolean = true,
    val accentStyle: AccentStyle = AccentStyle.ELECTRIC_LIME,
    val orbSizeDp: Int = 60,
    val orbTransparency: Float = 0.94f,
    val orbPosX: Int = 40,
    val orbPosY: Int = 420,
    val animationIntensity: AnimationIntensity = AnimationIntensity.BALANCED,
    val hapticsEnabled: Boolean = true,
    val autoPilotEnabled: Boolean = true,
    val screenAwarenessEnabled: Boolean = true,
    val actionDelayMs: Int = 1100,
    val verificationEnabled: Boolean = true,
    val maxRetries: Int = 2,
    val pauseOnUnexpectedScreen: Boolean = true,
    val confirmConsequentialActions: Boolean = true,
    val aiProviderType: AiProviderType = AiProviderType.FIREBASE_GEMINI,
    val textModel: String = "gemini-3.8-flash",
    val visionModel: String = "gemini-3.8-flash",
    val reasoningDepth: ReasoningDepth = ReasoningDepth.BALANCED,
    val customEndpointUrl: String = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    val customApiKey: String = "",
    val customModelId: String = "gemini-3.8-flash",
    val totalAiCalls: Long = 0L,
    val savedInstruction: String = ""
)

class ZenoPreferencesRepository(private val context: Context) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val ACCENT_STYLE = stringPreferencesKey("accent_style")
        val ORB_SIZE_DP = intPreferencesKey("orb_size_dp")
        val ORB_TRANSPARENCY = floatPreferencesKey("orb_transparency")
        val ORB_POS_X = intPreferencesKey("orb_pos_x")
        val ORB_POS_Y = intPreferencesKey("orb_pos_y")
        val ANIMATION_INTENSITY = stringPreferencesKey("animation_intensity")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        val AUTOPILOT_ENABLED = booleanPreferencesKey("autopilot_enabled")
        val SCREEN_AWARENESS_ENABLED = booleanPreferencesKey("screen_awareness_enabled")
        val ACTION_DELAY_MS = intPreferencesKey("action_delay_ms")
        val VERIFICATION_ENABLED = booleanPreferencesKey("verification_enabled")
        val MAX_RETRIES = intPreferencesKey("max_retries")
        val PAUSE_UNEXPECTED = booleanPreferencesKey("pause_unexpected")
        val CONFIRM_CONSEQUENTIAL = booleanPreferencesKey("confirm_consequential")
        val AI_PROVIDER_TYPE = stringPreferencesKey("ai_provider_type")
        val TEXT_MODEL = stringPreferencesKey("text_model")
        val VISION_MODEL = stringPreferencesKey("vision_model")
        val REASONING_DEPTH = stringPreferencesKey("reasoning_depth")
        val CUSTOM_ENDPOINT = stringPreferencesKey("custom_endpoint")
        val CUSTOM_API_KEY = stringPreferencesKey("custom_api_key")
        val CUSTOM_MODEL_ID = stringPreferencesKey("custom_model_id")
        val TOTAL_AI_CALLS = longPreferencesKey("total_ai_calls")
        val SAVED_INSTRUCTION = stringPreferencesKey("saved_instruction")
    }

    val settingsFlow: Flow<ZenoSettings> = context.zenoDataStore.data.map { prefs ->
        ZenoSettings(
            darkTheme = prefs[Keys.DARK_THEME] ?: true,
            accentStyle = runCatching {
                AccentStyle.valueOf(prefs[Keys.ACCENT_STYLE] ?: AccentStyle.ELECTRIC_LIME.name)
            }.getOrDefault(AccentStyle.ELECTRIC_LIME),
            orbSizeDp = prefs[Keys.ORB_SIZE_DP] ?: 60,
            orbTransparency = prefs[Keys.ORB_TRANSPARENCY] ?: 0.94f,
            orbPosX = prefs[Keys.ORB_POS_X] ?: 40,
            orbPosY = prefs[Keys.ORB_POS_Y] ?: 420,
            animationIntensity = runCatching {
                AnimationIntensity.valueOf(prefs[Keys.ANIMATION_INTENSITY] ?: AnimationIntensity.BALANCED.name)
            }.getOrDefault(AnimationIntensity.BALANCED),
            hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
            autoPilotEnabled = prefs[Keys.AUTOPILOT_ENABLED] ?: true,
            screenAwarenessEnabled = prefs[Keys.SCREEN_AWARENESS_ENABLED] ?: true,
            actionDelayMs = prefs[Keys.ACTION_DELAY_MS] ?: 1100,
            verificationEnabled = prefs[Keys.VERIFICATION_ENABLED] ?: true,
            maxRetries = prefs[Keys.MAX_RETRIES] ?: 2,
            pauseOnUnexpectedScreen = prefs[Keys.PAUSE_UNEXPECTED] ?: true,
            confirmConsequentialActions = prefs[Keys.CONFIRM_CONSEQUENTIAL] ?: true,
            aiProviderType = runCatching {
                AiProviderType.valueOf(prefs[Keys.AI_PROVIDER_TYPE] ?: AiProviderType.FIREBASE_GEMINI.name)
            }.getOrDefault(AiProviderType.FIREBASE_GEMINI),
            textModel = prefs[Keys.TEXT_MODEL] ?: "gemini-3.8-flash",
            visionModel = prefs[Keys.VISION_MODEL] ?: "gemini-3.8-flash",
            reasoningDepth = runCatching {
                ReasoningDepth.valueOf(prefs[Keys.REASONING_DEPTH] ?: ReasoningDepth.BALANCED.name)
            }.getOrDefault(ReasoningDepth.BALANCED),
            customEndpointUrl = prefs[Keys.CUSTOM_ENDPOINT]
                ?: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
            customApiKey = prefs[Keys.CUSTOM_API_KEY] ?: "",
            customModelId = prefs[Keys.CUSTOM_MODEL_ID] ?: "gemini-3.8-flash",
            totalAiCalls = prefs[Keys.TOTAL_AI_CALLS] ?: 0L,
            savedInstruction = prefs[Keys.SAVED_INSTRUCTION] ?: ""
        )
    }

    suspend fun updateSavedInstruction(instruction: String) {
        context.zenoDataStore.edit { it[Keys.SAVED_INSTRUCTION] = instruction }
    }

    suspend fun updateOrbPosition(x: Int, y: Int) {
        context.zenoDataStore.edit {
            it[Keys.ORB_POS_X] = x
            it[Keys.ORB_POS_Y] = y
        }
    }

    suspend fun incrementAiCalls() {
        context.zenoDataStore.edit {
            it[Keys.TOTAL_AI_CALLS] = (it[Keys.TOTAL_AI_CALLS] ?: 0L) + 1L
        }
    }

    suspend fun update(transform: (MutableMap<String, Any>) -> Unit) {
        // Explicit typed setters below are preferred
    }

    suspend fun setDarkTheme(enabled: Boolean) = context.zenoDataStore.edit { it[Keys.DARK_THEME] = enabled }
    suspend fun setAccentStyle(style: AccentStyle) = context.zenoDataStore.edit { it[Keys.ACCENT_STYLE] = style.name }
    suspend fun setOrbSize(sizeDp: Int) = context.zenoDataStore.edit { it[Keys.ORB_SIZE_DP] = sizeDp.coerceIn(48, 84) }
    suspend fun setOrbTransparency(alpha: Float) = context.zenoDataStore.edit { it[Keys.ORB_TRANSPARENCY] = alpha.coerceIn(0.45f, 1.0f) }
    suspend fun setAnimationIntensity(intensity: AnimationIntensity) = context.zenoDataStore.edit { it[Keys.ANIMATION_INTENSITY] = intensity.name }
    suspend fun setHapticsEnabled(enabled: Boolean) = context.zenoDataStore.edit { it[Keys.HAPTICS_ENABLED] = enabled }
    suspend fun setAutoPilotEnabled(enabled: Boolean) = context.zenoDataStore.edit { it[Keys.AUTOPILOT_ENABLED] = enabled }
    suspend fun setScreenAwarenessEnabled(enabled: Boolean) = context.zenoDataStore.edit { it[Keys.SCREEN_AWARENESS_ENABLED] = enabled }
    suspend fun setActionDelayMs(ms: Int) = context.zenoDataStore.edit { it[Keys.ACTION_DELAY_MS] = ms.coerceIn(400, 3000) }
    suspend fun setVerificationEnabled(enabled: Boolean) = context.zenoDataStore.edit { it[Keys.VERIFICATION_ENABLED] = enabled }
    suspend fun setMaxRetries(retries: Int) = context.zenoDataStore.edit { it[Keys.MAX_RETRIES] = retries.coerceIn(1, 5) }
    suspend fun setPauseOnUnexpectedScreen(enabled: Boolean) = context.zenoDataStore.edit { it[Keys.PAUSE_UNEXPECTED] = enabled }
    suspend fun setConfirmConsequentialActions(enabled: Boolean) = context.zenoDataStore.edit { it[Keys.CONFIRM_CONSEQUENTIAL] = enabled }
    suspend fun setAiProviderType(type: AiProviderType) = context.zenoDataStore.edit { it[Keys.AI_PROVIDER_TYPE] = type.name }
    suspend fun setTextModel(model: String) = context.zenoDataStore.edit { it[Keys.TEXT_MODEL] = model }
    suspend fun setVisionModel(model: String) = context.zenoDataStore.edit { it[Keys.VISION_MODEL] = model }
    suspend fun setReasoningDepth(depth: ReasoningDepth) = context.zenoDataStore.edit { it[Keys.REASONING_DEPTH] = depth.name }
    suspend fun setCustomEndpointUrl(url: String) = context.zenoDataStore.edit { it[Keys.CUSTOM_ENDPOINT] = url }
    suspend fun setCustomApiKey(key: String) = context.zenoDataStore.edit { it[Keys.CUSTOM_API_KEY] = key }
    suspend fun setCustomModelId(modelId: String) = context.zenoDataStore.edit { it[Keys.CUSTOM_MODEL_ID] = modelId }
}
