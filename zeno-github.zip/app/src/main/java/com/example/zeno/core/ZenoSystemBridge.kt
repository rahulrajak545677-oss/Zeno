package com.example.zeno.core

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.zeno.accessibility.ZenoAccessibilityService
import com.example.zeno.core.model.InstalledAppInfo
import com.example.zeno.core.model.ScreenObservation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

object ZenoSystemBridge {

    private var accessibilityServiceRef: WeakReference<ZenoAccessibilityService>? = null

    private val _isAccessibilityConnected = MutableStateFlow(false)
    val isAccessibilityConnected: StateFlow<Boolean> = _isAccessibilityConnected.asStateFlow()

    private val _isOverlayRunning = MutableStateFlow(false)
    val isOverlayRunning: StateFlow<Boolean> = _isOverlayRunning.asStateFlow()

    private val _isScreenCaptureActive = MutableStateFlow(false)
    val isScreenCaptureActive: StateFlow<Boolean> = _isScreenCaptureActive.asStateFlow()

    private val _latestObservation = MutableStateFlow<ScreenObservation?>(null)
    val latestObservation: StateFlow<ScreenObservation?> = _latestObservation.asStateFlow()

    private val _latestScreenshot = MutableStateFlow<Bitmap?>(null)
    val latestScreenshot: StateFlow<Bitmap?> = _latestScreenshot.asStateFlow()

    private val _lastVoiceTranscript = MutableStateFlow<String?>(null)
    val lastVoiceTranscript: StateFlow<String?> = _lastVoiceTranscript.asStateFlow()

    fun attachAccessibilityService(service: ZenoAccessibilityService) {
        accessibilityServiceRef = WeakReference(service)
        _isAccessibilityConnected.value = true
    }

    fun detachAccessibilityService() {
        accessibilityServiceRef = null
        _isAccessibilityConnected.value = false
    }

    fun getAccessibilityService(): ZenoAccessibilityService? = accessibilityServiceRef?.get()

    fun setOverlayRunning(running: Boolean) {
        _isOverlayRunning.value = running
    }

    fun setScreenCaptureActive(active: Boolean) {
        _isScreenCaptureActive.value = active
    }

    fun updateObservation(observation: ScreenObservation) {
        _latestObservation.value = observation
    }

    fun updateScreenshot(bitmap: Bitmap?) {
        _latestScreenshot.value = bitmap
    }

    fun clearCachedScreenshots() {
        _latestScreenshot.value = null
    }

    fun postVoiceTranscript(text: String) {
        _lastVoiceTranscript.value = text
    }

    fun consumeVoiceTranscript() {
        _lastVoiceTranscript.value = null
    }

    fun isAccessibilityEnabledInSettings(context: Context): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
            ?: return false
        val expectedComponent = ComponentName(context, ZenoAccessibilityService::class.java)
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        if (enabledServices.any {
                it.resolveInfo?.serviceInfo?.let { si ->
                    si.packageName == expectedComponent.packageName && si.name == expectedComponent.className
                } == true
            }
        ) {
            return true
        }
        val enabledSetting = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledSetting.contains(expectedComponent.flattenToString(), ignoreCase = true) ||
            enabledSetting.contains(expectedComponent.flattenToShortString(), ignoreCase = true)
    }

    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun areNotificationsEnabled(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED &&
                NotificationManagerCompat.from(context).areNotificationsEnabled()
        } else {
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        }
    }

    fun isMicrophoneGranted(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun isFirebaseReady(context: Context): Boolean =
        com.example.zeno.ai.ensureFirebaseInitialized(context)

    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openOverlayPermissionSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openAppNotificationSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openBatteryOptimizationSettings(context: Context) {
        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun getLaunchableApps(context: Context): List<InstalledAppInfo> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        return resolveInfos
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) return@mapNotNull null
                val label = info.loadLabel(pm)?.toString()?.trim().orEmpty().ifBlank { pkg }
                InstalledAppInfo(
                    appName = label,
                    packageName = pkg,
                    categoryHint = classifyAppCategory(label, pkg)
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.appName.lowercase() }
    }

    fun launchApp(context: Context, packageOrAppName: String): Boolean {
        val query = packageOrAppName.trim()
        if (query.isBlank()) return false
        return runCatching {
            val directIntent = context.packageManager.getLaunchIntentForPackage(query)
            val resolvedIntent = directIntent ?: run {
                val bestPkg = resolveBestAppPackage(getLaunchableApps(context), query) ?: return false
                context.packageManager.getLaunchIntentForPackage(bestPkg) ?: return false
            }
            resolvedIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            context.startActivity(resolvedIntent)
            true
        }.getOrDefault(false)
    }

    fun resolveBestAppPackage(apps: List<InstalledAppInfo>, query: String): String? {
        val normalized = query.trim().lowercase()
        if (normalized.isBlank()) return null
        return apps.firstOrNull { it.packageName.equals(normalized, ignoreCase = true) }?.packageName
            ?: apps.firstOrNull { it.appName.equals(normalized, ignoreCase = true) }?.packageName
            ?: apps.firstOrNull { it.appName.lowercase().startsWith(normalized) }?.packageName
            ?: apps.firstOrNull {
                it.appName.lowercase().contains(normalized) ||
                    it.packageName.lowercase().contains(normalized)
            }?.packageName
    }

    private fun classifyAppCategory(label: String, pkg: String): String {
        val combined = "$label $pkg".lowercase()
        return when {
            listOf("capcut", "alight", "vn", "inshot", "kinemaster", "video", "editor", "premiere")
                .any { combined.contains(it) } -> "Video & Motion"
            listOf("canva", "figma", "snapseed", "lightroom", "photoshop", "photo", "pixlr", "picsart")
                .any { combined.contains(it) } -> "Photo & Design"
            listOf("docs", "word", "notion", "notes", "keep", "drive", "sheets", "office")
                .any { combined.contains(it) } -> "Docs & Writing"
            listOf("files", "file", "explorer", "solid", "cx", "manager")
                .any { combined.contains(it) } -> "File Management"
            else -> "General App"
        }
    }
}
