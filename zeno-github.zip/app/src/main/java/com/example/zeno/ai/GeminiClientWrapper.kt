package com.example.zeno.ai

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.zeno.ZenoApplication
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "GeminiClientWrapper"
private const val DEFAULT_TIMEOUT_MS = 60_000L

/**
 * Secure AI provider wrapper around Firebase AI Logic (`Firebase.ai`).
 * Uses Firebase App Check attestation configured in `MainActivity.onCreate()`
 * rather than embedding client-side API keys.
 */
class GeminiClientWrapper(
    private val defaultModelName: String = DEFAULT_MODEL
) {
    private val defaultTextModel: GenerativeModel by lazy {
        Firebase.ai.generativeModel(modelName = sanitizeModelName(defaultModelName))
    }

    private val modelCache = ConcurrentHashMap<String, GenerativeModel>()

    fun isFirebaseReady(context: Context? = ZenoApplication.appContext): Boolean {
        val ctx = context ?: return runCatching {
            FirebaseApp.getApps(FirebaseApp.getInstance().applicationContext).isNotEmpty()
        }.getOrDefault(false)
        return ensureFirebaseInitialized(ctx)
    }

    private fun ensureFirebaseReadyForAi() {
        val ctx = ZenoApplication.appContext
        if (ctx != null) {
            if (!ensureFirebaseInitialized(ctx)) {
                throw IllegalStateException(MISSING_FIREBASE_CONFIG_MESSAGE)
            }
            ensureAppCheckConfiguredIfNeeded(ctx)
        }
    }

    fun getModel(
        modelName: String = defaultModelName,
        responseSchema: Schema? = null,
        systemInstruction: Content? = null
    ): GenerativeModel {
        ensureFirebaseReadyForAi()
        val resolvedModel = sanitizeModelName(modelName)
        if (resolvedModel == sanitizeModelName(defaultModelName) &&
            responseSchema == null &&
            systemInstruction == null
        ) {
            return defaultTextModel
        }

        val cacheKey = buildString {
            append(resolvedModel)
            append("|schema=")
            append(responseSchema?.hashCode() ?: 0)
            append("|sys=")
            append(systemInstruction?.hashCode() ?: 0)
        }

        return modelCache.getOrPut(cacheKey) {
            val config = if (responseSchema != null) {
                generationConfig {
                    responseMimeType = "application/json"
                    this.responseSchema = responseSchema
                }
            } else {
                null
            }
            Firebase.ai.generativeModel(
                modelName = resolvedModel,
                generationConfig = config,
                systemInstruction = systemInstruction
            )
        }
    }

    suspend fun generateText(
        prompt: String,
        modelName: String = defaultModelName,
        systemInstruction: String? = null,
        timeoutMs: Long = DEFAULT_TIMEOUT_MS
    ): Result<String> {
        if (prompt.isBlank()) {
            return Result.failure(IllegalArgumentException("Prompt cannot be blank."))
        }
        return executeUnary(timeoutMs) {
            val sysContent = systemInstruction?.takeIf { it.isNotBlank() }?.let {
                content("system") { text(it) }
            }
            val model = getModel(modelName = modelName, systemInstruction = sysContent)
            val response = model.generateContent(prompt)
            response.text?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("Gemini returned an empty response.")
        }
    }

    suspend fun generateMultimodal(
        prompt: String,
        image: Bitmap,
        modelName: String = defaultModelName,
        timeoutMs: Long = DEFAULT_TIMEOUT_MS
    ): Result<String> {
        if (prompt.isBlank()) {
            return Result.failure(IllegalArgumentException("Prompt cannot be blank."))
        }
        return executeUnary(timeoutMs) {
            val model = getModel(modelName = modelName)
            val response = model.generateContent(
                content {
                    image(image)
                    text(prompt)
                }
            )
            response.text?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("Gemini returned an empty multimodal response.")
        }
    }

    suspend fun generateStructuredJson(
        prompt: String,
        schema: Schema,
        image: Bitmap? = null,
        modelName: String = defaultModelName,
        timeoutMs: Long = DEFAULT_TIMEOUT_MS
    ): Result<String> {
        if (prompt.isBlank()) {
            return Result.failure(IllegalArgumentException("Prompt cannot be blank."))
        }
        return executeUnary(timeoutMs) {
            val model = getModel(modelName = modelName, responseSchema = schema)
            val response = if (image != null) {
                model.generateContent(
                    content {
                        image(image)
                        text(prompt)
                    }
                )
            } else {
                model.generateContent(prompt)
            }
            response.text?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("Gemini returned an empty structured JSON response.")
        }
    }

    fun streamText(
        prompt: String,
        modelName: String = defaultModelName,
        timeoutMs: Long = DEFAULT_TIMEOUT_MS
    ): Flow<String> = flow {
        require(prompt.isNotBlank()) { "Prompt cannot be blank." }
        val model = getModel(modelName = modelName)
        withTimeout(timeoutMs) {
            model.generateContentStream(prompt).collect { chunk ->
                val text = chunk.text.orEmpty()
                if (text.isNotEmpty()) emit(text)
            }
        }
    }.catch { throwable ->
        if (throwable is CancellationException && throwable !is TimeoutCancellationException) {
            throw throwable
        }
        Log.e(TAG, "Streaming generation failed", throwable)
        throw throwable
    }

    private suspend inline fun executeUnary(
        timeoutMs: Long,
        crossinline block: suspend () -> String
    ): Result<String> {
        return try {
            val output = withTimeout(timeoutMs) { block() }
            Result.success(output)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini request timed out after ${timeoutMs}ms", e)
            Result.failure(
                IllegalStateException("AI request timed out after ${timeoutMs / 1000} seconds. Please try again.")
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini request failed", e)
            val msg = e.message.orEmpty()
            if (msg.contains("Default FirebaseApp is not initialized", ignoreCase = true)) {
                Result.failure(IllegalStateException(MISSING_FIREBASE_CONFIG_MESSAGE, e))
            } else {
                Result.failure(e)
            }
        }
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"
        const val MISSING_FIREBASE_CONFIG_MESSAGE =
            "Built-in Firebase AI is unavailable because this APK was built without app/google-services.json. Add google-services.json before building, or switch AI Provider to 'Compatible API' in ZENO Settings."
        val SUPPORTED_MODELS = setOf(
            "gemini-3.8-flash",
            "gemini-3.5-flash-lite",
            "gemini-4-argon"
        )

        fun sanitizeModelName(requested: String): String {
            val trimmed = requested.trim()
            return if (trimmed in SUPPORTED_MODELS) trimmed else DEFAULT_MODEL
        }
    }
}
