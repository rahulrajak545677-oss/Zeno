package com.example.zeno

import android.app.Application
import android.content.Context
import com.example.zeno.ai.ensureFirebaseInitialized

class ZenoApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext
        ensureFirebaseInitialized(applicationContext)
    }

    companion object {
        @Volatile
        var appContext: Context? = null
            private set
    }
}
