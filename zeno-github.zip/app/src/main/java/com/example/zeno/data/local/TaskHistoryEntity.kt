package com.example.zeno.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "task_history")
data class TaskHistoryEntity(
    @PrimaryKey val taskId: String,
    val taskName: String,
    val originalPrompt: String,
    val targetAppName: String,
    val targetAppPackage: String,
    val timestampMs: Long,
    val durationMs: Long,
    val status: String,
    val actionsPerformed: Int,
    val verifiedActions: Int,
    val failedActions: Int,
    val summary: String,
    val planJson: String,
    val logsJson: String
)
