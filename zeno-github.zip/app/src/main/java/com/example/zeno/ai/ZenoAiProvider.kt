package com.example.zeno.ai

import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.ScreenObservation

interface ZenoAiProvider : AIProvider {
    suspend fun createNeuralPlan(
        instruction: String,
        observation: ScreenObservation?,
        modelName: String
    ): Result<List<PlanStep>> = interpretInstruction(instruction, observation, modelName)
}

