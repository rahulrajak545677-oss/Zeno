package com.example.zeno.data.repository

import android.graphics.Bitmap
import android.util.Log
import com.example.zeno.ai.AIProvider
import com.example.zeno.ai.GeminiClientWrapper
import com.example.zeno.core.model.ActionType
import com.example.zeno.core.model.AiDecisionResult
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.ScreenAnalysisReport
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.StepStatus
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.VerificationResult
import com.example.zeno.core.model.ZenoAction
import com.example.zeno.data.local.ZenoPreferencesRepository
import com.google.firebase.ai.type.Schema
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import java.util.UUID

private const val TAG = "GeminiRepository"
private const val MAX_VISION_EDGE_PX = 1080

data class InstructionInterpretation(
    val goalSummary: String,
    val targetAppHint: String?,
    val requiresUserReview: Boolean,
    val steps: List<PlanStep>
)

/**
 * Secure Gemini repository implementing [AIProvider] via Firebase AI Logic (`Firebase.ai`)
 * and Firebase App Check attestation (no client-side API keys required).
 *
 * Manages both natural-language instruction interpretation and multimodal vision-based
 * Android screen analysis.
 */
class GeminiRepository(
    private val clientWrapper: GeminiClientWrapper = GeminiClientWrapper(),
    private val prefsRepo: ZenoPreferencesRepository? = null,
    private val promptRepository: GeminiPromptRepository = GeminiPromptRepository(clientWrapper, prefsRepo)
) : AIProvider {

    override val providerName: String = "Firebase AI Logic (Gemini)"

    override suspend fun testConnection(modelName: String): Result<String> {
        return promptRepository.verifyConnection(modelOverride = modelName)
    }

    override suspend fun interpretInstruction(
        instruction: String,
        observation: ScreenObservation?,
        modelName: String
    ): Result<List<PlanStep>> {
        val cleaned = instruction.trim()
        if (cleaned.isBlank()) {
            return Result.failure(IllegalArgumentException("Instruction cannot be blank."))
        }

        val prompt = buildString {
            appendLine("You are ZENO Neural Plan, an adaptive Android UI automation planner.")
            appendLine("Convert the user's instruction into 4 to 8 dynamic, app-agnostic action steps.")
            appendLine("Adapt to the current screen context if provided. Never assume fixed coordinates.")
            appendLine("User instruction: \"$cleaned\"")
            if (observation != null) {
                appendLine("Current screen package: ${observation.packageName} (${observation.appName})")
                appendLine("Screen summary: ${observation.summaryText}")
            }
        }

        return promptRepository.sendStructuredPrompt(
            prompt = prompt,
            schema = planSchema,
            modelOverride = modelName
        ).mapCatching { raw ->
            parsePlanStepsJson(raw)
        }.onFailure { e ->
            if (e is CancellationException) throw e
            Log.e(TAG, "Instruction interpretation failed", e)
        }
    }

    suspend fun interpretInstructionDetailed(
        instruction: String,
        observation: ScreenObservation?,
        modelName: String = GeminiClientWrapper.DEFAULT_MODEL
    ): Result<InstructionInterpretation> {
        val cleaned = instruction.trim()
        if (cleaned.isBlank()) {
            return Result.failure(IllegalArgumentException("Instruction cannot be blank."))
        }

        val prompt = buildString {
            appendLine("You are ZENO Core Instruction Interpreter.")
            appendLine("Summarize the user's intent, identify any named target app, flag risky/destructive intent, and produce 4 to 8 adaptive Android automation steps.")
            appendLine("User instruction: \"$cleaned\"")
            if (observation != null) {
                appendLine("Active app: ${observation.appName} (${observation.packageName})")
                appendLine("Screen summary: ${observation.summaryText}")
            }
        }

        return promptRepository.sendStructuredPrompt(
            prompt = prompt,
            schema = detailedInterpretationSchema,
            modelOverride = modelName
        ).mapCatching { raw ->
            parseDetailedInterpretationJson(raw, cleaned)
        }.onFailure { e ->
            if (e is CancellationException) throw e
            Log.e(TAG, "Detailed instruction interpretation failed", e)
        }
    }

    fun streamInstructionInterpretation(
        instruction: String,
        modelOverride: String? = null
    ): Flow<PromptResult> {
        val prompt = buildString {
            appendLine("You are ZENO Neural Plan. Briefly explain the step-by-step Android approach for this instruction:")
            appendLine("\"${instruction.trim()}\"")
        }
        return promptRepository.streamPrompt(
            prompt = prompt,
            modelOverride = modelOverride
        )
    }

    override suspend fun decideNextAction(
        memory: TaskMemory,
        observation: ScreenObservation,
        screenshot: Bitmap?,
        textModel: String,
        visionModel: String
    ): Result<AiDecisionResult> {
        val safeBitmap = screenshot?.let { prepareVisionBitmap(it) }
        val chosenModel = if (safeBitmap != null) visionModel else textModel
        val nodesText = formatNodesForPrompt(observation)
        val planText = memory.plan.mapIndexed { idx, step ->
            "$idx. [${step.status.name}] ${step.title}"
        }.joinToString("\n")
        val recentLogs = memory.logs.takeLast(6).joinToString("\n") {
            "- [${it.phase}] ${it.message}"
        }

        val promptText = buildString {
            appendLine("You are ZENO Core, an autonomous Android AI touch operator.")
            appendLine("Decide the SINGLE next action to progress the user's task based ONLY on the observed screen.")
            appendLine("Rules:")
            appendLine("1. Prefer semantic accessibility targets (targetNodeId and targetLabel) over coordinates.")
            appendLine("2. Set isConsequential=true BEFORE deleting files, sending messages, publishing posts, making purchases, or changing security/account settings.")
            appendLine("3. If the screen controls are inaccessible or uncertain, set needsUserInput=true and explain clearly.")
            appendLine("4. Only set isTaskComplete=true when the user's goal is genuinely achieved on screen.")
            appendLine("5. Allowed actionType values: tap, long_press, swipe, scroll, drag, text_input, back, navigate, open_app, select_element, slider_adjust, wait, screenshot, observe, verify, ask_user.")
            appendLine("6. For open_app, put the Android packageName or exact app display name (e.g., CapCut, Canva, Files) in packageName or targetLabel.")
            appendLine()
            appendLine("Goal: ${memory.originalInstruction}")
            appendLine("Current App: ${observation.appName} (${observation.packageName})")
            appendLine("Screen Dimensions: ${observation.screenWidth}x${observation.screenHeight}")
            appendLine("Retries on current step: ${memory.retryCount}")
            appendLine("Neural Plan:\n$planText")
            if (recentLogs.isNotBlank()) {
                appendLine("Recent Execution Logs:\n$recentLogs")
            }
            appendLine("Visible UI Nodes:\n$nodesText")
        }

        return promptRepository.sendStructuredPrompt(
            prompt = promptText,
            schema = decisionSchema,
            screenshot = safeBitmap,
            modelOverride = chosenModel
        ).mapCatching { raw ->
            parseDecisionJson(raw)
        }.onFailure { e ->
            if (e is CancellationException) throw e
            Log.e(TAG, "Action decision failed", e)
        }
    }

    override suspend fun verifyActionOutcome(
        action: ZenoAction,
        before: ScreenObservation,
        after: ScreenObservation,
        screenshot: Bitmap?,
        modelName: String
    ): Result<VerificationResult> {
        val safeBitmap = screenshot?.let { prepareVisionBitmap(it) }
        val promptText = buildString {
            appendLine("You are ZENO Self-Check, a strict verification engine.")
            appendLine("Compare the BEFORE and AFTER screen states to verify if the action genuinely succeeded.")
            appendLine("Never claim verified=true if nothing relevant changed or an error dialog appeared.")
            appendLine("Action performed: ${action.type.wireName} on '${action.targetLabel}' (${action.reason})")
            appendLine("Expected outcome: ${action.expectedOutcome}")
            appendLine("BEFORE (${before.appName}): ${before.summaryText}")
            appendLine("AFTER (${after.appName}): ${after.summaryText}")
            appendLine("AFTER nodes:\n${formatNodesForPrompt(after)}")
        }
        return promptRepository.sendStructuredPrompt(
            prompt = promptText,
            schema = verifySchema,
            screenshot = safeBitmap,
            modelOverride = modelName
        ).mapCatching { raw ->
            parseVerificationJson(raw)
        }.onFailure { e ->
            if (e is CancellationException) throw e
            Log.e(TAG, "Verification failed", e)
        }
    }

    override suspend fun analyzeScreen(
        observation: ScreenObservation,
        screenshot: Bitmap?,
        modelName: String
    ): Result<ScreenAnalysisReport> {
        if (!observation.hasAccessibilityData && screenshot == null && observation.packageName.isBlank()) {
            return Result.failure(
                IllegalStateException("No screen nodes or screenshot available to analyze.")
            )
        }
        val safeBitmap = screenshot?.let { prepareVisionBitmap(it) }
        val promptText = buildString {
            appendLine("You are ZENO Vision. Analyze the current Android screen honestly.")
            appendLine("App: ${observation.appName} (${observation.packageName})")
            appendLine("Has Accessibility Data: ${observation.hasAccessibilityData}")
            appendLine("Visible UI Nodes:\n${formatNodesForPrompt(observation)}")
        }
        return promptRepository.sendStructuredPrompt(
            prompt = promptText,
            schema = screenAnalysisSchema,
            screenshot = safeBitmap,
            modelOverride = modelName
        ).mapCatching { raw ->
            parseScreenAnalysisJson(raw, fallbackAppName = observation.appName)
        }.onFailure { e ->
            if (e is CancellationException) throw e
            Log.e(TAG, "Screen analysis failed", e)
        }
    }

    private fun prepareVisionBitmap(source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        if (w <= MAX_VISION_EDGE_PX && h <= MAX_VISION_EDGE_PX) return source
        val scale = MAX_VISION_EDGE_PX.toFloat() / maxOf(w, h).toFloat()
        val targetW = (w * scale).toInt().coerceAtLeast(1)
        val targetH = (h * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, targetW, targetH, true)
    }

    private fun formatNodesForPrompt(observation: ScreenObservation): String {
        if (observation.nodes.isEmpty()) {
            return "(No accessible UI nodes exposed by this window)"
        }
        return observation.nodes.take(65).joinToString("\n") { n ->
            val flags = buildList {
                if (n.isClickable) add("click")
                if (n.isEditable) add("edit")
                if (n.isScrollable) add("scroll")
                if (n.isCheckable) add(if (n.isChecked) "checked" else "unchecked")
            }.joinToString(",")
            val label = n.primaryLabel().replace("\n", " ").take(64)
            "${n.nodeId} | \"$label\" | ${n.bounds.toShortString()} | [$flags]"
        }
    }

    companion object {
        private val moshi: Moshi by lazy { Moshi.Builder().build() }
        private val planAdapter by lazy { moshi.adapter(PlanResponseDto::class.java) }
        private val detailedAdapter by lazy { moshi.adapter(DetailedInterpretationDto::class.java) }
        private val decisionAdapter by lazy { moshi.adapter(DecisionResponseDto::class.java) }
        private val verifyAdapter by lazy { moshi.adapter(VerificationResponseDto::class.java) }
        private val analysisAdapter by lazy { moshi.adapter(ScreenAnalysisResponseDto::class.java) }

        fun parsePlanStepsJson(raw: String): List<PlanStep> {
            val parsed = planAdapter.fromJson(raw)
                ?: throw IllegalStateException("Unable to parse Neural Plan response.")
            val steps = parsed.steps.mapIndexed { i, item ->
                PlanStep(
                    id = "step_${i + 1}",
                    title = item.title?.takeIf { it.isNotBlank() } ?: "Step ${i + 1}",
                    status = StepStatus.PENDING,
                    detail = item.detail.orEmpty()
                )
            }
            if (steps.isEmpty()) throw IllegalStateException("Neural Plan produced 0 steps.")
            return steps
        }

        fun parseDetailedInterpretationJson(
            raw: String,
            fallbackGoal: String
        ): InstructionInterpretation {
            val parsed = detailedAdapter.fromJson(raw)
                ?: throw IllegalStateException("Unable to parse instruction interpretation.")
            val steps = parsed.steps.mapIndexed { i, item ->
                PlanStep(
                    id = "step_${i + 1}",
                    title = item.title?.takeIf { it.isNotBlank() } ?: "Step ${i + 1}",
                    status = StepStatus.PENDING,
                    detail = item.detail.orEmpty()
                )
            }
            if (steps.isEmpty()) throw IllegalStateException("Neural Plan produced 0 steps.")
            return InstructionInterpretation(
                goalSummary = parsed.goalSummary?.takeIf { it.isNotBlank() } ?: fallbackGoal,
                targetAppHint = parsed.targetAppHint?.takeIf { it.isNotBlank() },
                requiresUserReview = parsed.requiresUserReview,
                steps = steps
            )
        }

        fun parseDecisionJson(raw: String): AiDecisionResult {
            val parsed = decisionAdapter.fromJson(raw)
                ?: throw IllegalStateException("Unable to parse action decision.")
            val nextAction = if (!parsed.isTaskComplete && !parsed.needsUserInput && parsed.action != null) {
                val a = parsed.action
                ZenoAction(
                    actionId = UUID.randomUUID().toString().take(8),
                    type = ActionType.fromWireName(a.actionType ?: "tap"),
                    targetNodeId = a.targetNodeId.orEmpty(),
                    targetLabel = a.targetLabel.orEmpty(),
                    x = a.x,
                    y = a.y,
                    endX = a.endX,
                    endY = a.endY,
                    inputText = a.inputText.orEmpty(),
                    packageName = a.packageName.orEmpty(),
                    scrollDirection = a.scrollDirection?.takeIf { it.isNotBlank() } ?: "forward",
                    sliderPercent = a.sliderPercent?.toFloat(),
                    reason = a.reason?.takeIf { it.isNotBlank() } ?: "Progress task",
                    expectedOutcome = a.expectedOutcome?.takeIf { it.isNotBlank() } ?: "Screen updates accordingly",
                    verificationMethod = a.verificationMethod?.takeIf { it.isNotBlank() } ?: "screen_diff",
                    isConsequential = a.isConsequential
                )
            } else null

            return AiDecisionResult(
                isTaskComplete = parsed.isTaskComplete,
                completionSummary = parsed.completionSummary.orEmpty(),
                activeStepIndex = parsed.activeStepIndex,
                needsUserInput = parsed.needsUserInput,
                userPromptReason = parsed.userPromptReason.orEmpty(),
                nextAction = nextAction
            )
        }

        fun parseVerificationJson(raw: String): VerificationResult {
            val parsed = verifyAdapter.fromJson(raw)
                ?: throw IllegalStateException("Unable to parse verification result.")
            return VerificationResult(
                verified = parsed.verified,
                confidenceSummary = parsed.confidenceSummary?.takeIf { it.isNotBlank() } ?: "Checked screen state",
                uiChanged = parsed.uiChanged,
                shouldReplan = parsed.shouldReplan
            )
        }

        fun parseScreenAnalysisJson(raw: String, fallbackAppName: String = "Unknown App"): ScreenAnalysisReport {
            val parsed = analysisAdapter.fromJson(raw)
                ?: throw IllegalStateException("Unable to parse screen analysis.")
            return ScreenAnalysisReport(
                appName = parsed.appName?.takeIf { it.isNotBlank() } ?: fallbackAppName,
                screenPurpose = parsed.screenPurpose?.takeIf { it.isNotBlank() } ?: "Unable to determine screen purpose.",
                keyControls = parsed.keyControls,
                accessibilityLimitation = parsed.accessibilityLimitation?.takeIf { it.isNotBlank() }
            )
        }

        private val planStepsArraySchema = Schema.array(
            items = Schema.obj(
                properties = mapOf(
                    "title" to Schema.string("Concise step title"),
                    "detail" to Schema.string("What to look for and verify")
                )
            ),
            description = "Ordered dynamic plan steps"
        )

        private val planSchema = Schema.obj(
            properties = mapOf("steps" to planStepsArraySchema)
        )

        private val detailedInterpretationSchema = Schema.obj(
            properties = mapOf(
                "goalSummary" to Schema.string("Concise summary of the user's goal"),
                "targetAppHint" to Schema.string("Optional app name or package mentioned in the instruction"),
                "requiresUserReview" to Schema.boolean("True if the task involves potentially consequential actions"),
                "steps" to planStepsArraySchema
            ),
            optionalProperties = listOf("targetAppHint")
        )

        private val actionSchema = Schema.obj(
            properties = mapOf(
                "actionType" to Schema.string("One of tap, long_press, swipe, scroll, drag, text_input, back, navigate, open_app, select_element, slider_adjust, wait, screenshot, observe, verify, ask_user"),
                "targetNodeId" to Schema.string("Node ID like n4 if targeting an accessibility node"),
                "targetLabel" to Schema.string("Visible text or description of target UI element"),
                "x" to Schema.integer("Optional X coordinate if no node ID"),
                "y" to Schema.integer("Optional Y coordinate if no node ID"),
                "endX" to Schema.integer("Optional end X for swipe/drag"),
                "endY" to Schema.integer("Optional end Y for swipe/drag"),
                "inputText" to Schema.string("Text to type for text_input"),
                "packageName" to Schema.string("Package name or display name for open_app"),
                "scrollDirection" to Schema.string("forward or backward"),
                "sliderPercent" to Schema.double("0.0 to 1.0 for slider_adjust"),
                "reason" to Schema.string("Why this action moves toward the goal"),
                "expectedOutcome" to Schema.string("What UI change proves this action worked"),
                "verificationMethod" to Schema.string("How Self-Check should verify"),
                "isConsequential" to Schema.boolean("True if deleting files, sending messages, publishing, paying, or changing account/security settings")
            ),
            optionalProperties = listOf(
                "targetNodeId", "targetLabel", "x", "y", "endX", "endY",
                "inputText", "packageName", "scrollDirection", "sliderPercent"
            )
        )

        private val decisionSchema = Schema.obj(
            properties = mapOf(
                "isTaskComplete" to Schema.boolean("True only when user goal is verified complete"),
                "completionSummary" to Schema.string("Summary of result or current progress"),
                "activeStepIndex" to Schema.integer("Zero-based index of active plan step"),
                "needsUserInput" to Schema.boolean("True if screen is inaccessible or ambiguous"),
                "userPromptReason" to Schema.string("Clear explanation if needsUserInput is true"),
                "action" to actionSchema
            ),
            optionalProperties = listOf("action", "userPromptReason")
        )

        private val verifySchema = Schema.obj(
            properties = mapOf(
                "verified" to Schema.boolean("True if expected UI outcome is confirmed"),
                "confidenceSummary" to Schema.string("Concise explanation of observed change"),
                "uiChanged" to Schema.boolean("True if screen changed meaningfully"),
                "shouldReplan" to Schema.boolean("True if UI changed unexpectedly and needs replanning")
            )
        )

        private val screenAnalysisSchema = Schema.obj(
            properties = mapOf(
                "appName" to Schema.string("Detected application name"),
                "screenPurpose" to Schema.string("What the user can do on this screen"),
                "keyControls" to Schema.array(Schema.string(), "Up to 8 detected interactive controls"),
                "accessibilityLimitation" to Schema.string("Any accessibility visibility limitation, or empty string if clear")
            ),
            optionalProperties = listOf("accessibilityLimitation")
        )
    }
}

@JsonClass(generateAdapter = true)
internal data class PlanStepDto(
    val title: String? = null,
    val detail: String? = null
)

@JsonClass(generateAdapter = true)
internal data class PlanResponseDto(
    val steps: List<PlanStepDto> = emptyList()
)

@JsonClass(generateAdapter = true)
internal data class DetailedInterpretationDto(
    val goalSummary: String? = null,
    val targetAppHint: String? = null,
    val requiresUserReview: Boolean = false,
    val steps: List<PlanStepDto> = emptyList()
)

@JsonClass(generateAdapter = true)
internal data class ActionDto(
    val actionType: String? = null,
    val targetNodeId: String? = null,
    val targetLabel: String? = null,
    val x: Int? = null,
    val y: Int? = null,
    val endX: Int? = null,
    val endY: Int? = null,
    val inputText: String? = null,
    val packageName: String? = null,
    val scrollDirection: String? = null,
    val sliderPercent: Double? = null,
    val reason: String? = null,
    val expectedOutcome: String? = null,
    val verificationMethod: String? = null,
    val isConsequential: Boolean = false
)

@JsonClass(generateAdapter = true)
internal data class DecisionResponseDto(
    val isTaskComplete: Boolean = false,
    val completionSummary: String? = null,
    val activeStepIndex: Int = 0,
    val needsUserInput: Boolean = false,
    val userPromptReason: String? = null,
    val action: ActionDto? = null
)

@JsonClass(generateAdapter = true)
internal data class VerificationResponseDto(
    val verified: Boolean = false,
    val confidenceSummary: String? = null,
    val uiChanged: Boolean = false,
    val shouldReplan: Boolean = false
)

@JsonClass(generateAdapter = true)
internal data class ScreenAnalysisResponseDto(
    val appName: String? = null,
    val screenPurpose: String? = null,
    val keyControls: List<String> = emptyList(),
    val accessibilityLimitation: String? = null
)

