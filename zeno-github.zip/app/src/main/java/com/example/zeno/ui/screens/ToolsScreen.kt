package com.example.zeno.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ZenoBorder
import com.example.ui.theme.ZenoElevatedBg
import com.example.ui.theme.ZenoError
import com.example.ui.theme.ZenoSuccess
import com.example.ui.theme.ZenoTextPrimary
import com.example.ui.theme.ZenoTextSecondary
import com.example.ui.theme.ZenoWarning
import com.example.zeno.capture.ScreenCaptureConsentActivity
import com.example.zeno.capture.ZenoCaptureService
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.core.model.InstalledAppInfo
import com.example.zeno.core.model.PromptTemplate
import com.example.zeno.data.local.PromptHistoryEntity
import com.example.zeno.overlay.OrbVoiceInputActivity
import com.example.zeno.ui.PlanPreviewUiState
import com.example.zeno.ui.ScreenAnalysisUiState
import com.example.zeno.ui.SystemReadiness
import com.example.zeno.ui.components.PlanStepRow
import com.example.zeno.ui.components.ZenoCard

@Composable
fun ToolsScreen(
    templates: List<PromptTemplate>,
    promptLibrary: List<PromptHistoryEntity>,
    installedApps: List<InstalledAppInfo>,
    readiness: SystemReadiness,
    promptDraft: String,
    screenAnalysisState: ScreenAnalysisUiState,
    planPreviewState: PlanPreviewUiState,
    onSelectTemplate: (String) -> Unit,
    onRunScreenAnalysis: () -> Unit,
    onPreviewNeuralPlan: () -> Unit,
    onLaunchAppWithOrb: (String) -> Unit,
    onOpenOrbCustomization: () -> Unit,
    onRefreshReadiness: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var appFilterQuery by remember { mutableStateOf("") }
    val filteredInstalledApps = remember(installedApps, appFilterQuery) {
        if (appFilterQuery.isBlank()) {
            installedApps.take(24)
        } else {
            installedApps.filter {
                it.appName.contains(appFilterQuery, ignoreCase = true) ||
                    it.categoryHint.contains(appFilterQuery, ignoreCase = true) ||
                    it.packageName.contains(appFilterQuery, ignoreCase = true)
            }.take(30)
        }
    }
    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        onRefreshReadiness()
        if (granted) OrbVoiceInputActivity.launch(context, applyToEngine = false)
    }

    val notifLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { onRefreshReadiness() }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "ZENO Tools",
                    style = MaterialTheme.typography.headlineMedium,
                    color = ZenoTextPrimary
                )
                Text(
                    text = "Vision diagnostics, editable prompt templates, app launcher, and system permissions",
                    style = MaterialTheme.typography.bodySmall,
                    color = ZenoTextSecondary
                )
            }

            // Voice Command & Screen Analysis Actions
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ZenoCard(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                if (ZenoSystemBridge.isMicrophoneGranted(context)) {
                                    OrbVoiceInputActivity.launch(context, applyToEngine = false)
                                } else {
                                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                            .testTag("tool_voice_command")
                    ) {
                        Icon(
                            Icons.Rounded.Mic,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Voice Command", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Dictate instruction directly into ZENO",
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                    }

                    ZenoCard(
                        modifier = Modifier
                            .weight(1f)
                            .clickable(onClick = onOpenOrbCustomization)
                            .testTag("tool_orb_custom")
                    ) {
                        Icon(
                            Icons.Rounded.Tune,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Orb Customization", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Size, opacity, ring speed & placement",
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                    }
                }
            }

            // Live Screen Analysis
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.Visibility,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("ZENO Vision Screen Analysis", style = MaterialTheme.typography.titleMedium)
                        }
                        Button(
                            onClick = onRunScreenAnalysis,
                            enabled = screenAnalysisState !is ScreenAnalysisUiState.Analyzing,
                            modifier = Modifier.testTag("tool_analyze_screen_btn")
                        ) {
                            Text("Analyze")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    when (screenAnalysisState) {
                        ScreenAnalysisUiState.Idle -> Text(
                            "Inspects the live Accessibility UI tree (and screenshot when enabled) using Gemini Vision.",
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                        ScreenAnalysisUiState.Analyzing -> Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("ZENO Vision analyzing current window...", style = MaterialTheme.typography.bodySmall)
                        }
                        is ScreenAnalysisUiState.Success -> {
                            Text(
                                "${screenAnalysisState.report.appName}: ${screenAnalysisState.report.screenPurpose}",
                                style = MaterialTheme.typography.bodySmall,
                                color = ZenoTextPrimary
                            )
                            if (screenAnalysisState.report.keyControls.isNotEmpty()) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "Controls: ${screenAnalysisState.report.keyControls.joinToString(", ")}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            screenAnalysisState.report.accessibilityLimitation?.let { limit ->
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "Limitation: $limit",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ZenoWarning
                                )
                            }
                        }
                        is ScreenAnalysisUiState.Error -> Text(
                            screenAnalysisState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoError
                        )
                    }
                }
            }

            // Neural Plan Preview
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Neural Plan Preview", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = promptDraft.ifBlank { "Enter an instruction on Home to preview steps" },
                                style = MaterialTheme.typography.bodySmall,
                                color = ZenoTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = onPreviewNeuralPlan,
                            enabled = planPreviewState !is PlanPreviewUiState.Loading,
                            modifier = Modifier.testTag("tool_preview_plan_btn")
                        ) {
                            Text("Plan")
                        }
                    }
                    when (planPreviewState) {
                        PlanPreviewUiState.Idle -> Unit
                        PlanPreviewUiState.Loading -> Row(
                            modifier = Modifier.padding(top = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Generating dynamic Neural Plan...", style = MaterialTheme.typography.bodySmall)
                        }
                        is PlanPreviewUiState.Success -> {
                            Spacer(Modifier.height(8.dp))
                            planPreviewState.steps.forEach { step ->
                                PlanStepRow(step = step)
                            }
                        }
                        is PlanPreviewUiState.Error -> Text(
                            planPreviewState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoError,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }

            // Automation Permissions
            item {
                Text(
                    text = "AUTOMATION PERMISSIONS",
                    style = MaterialTheme.typography.labelMedium,
                    color = ZenoTextSecondary
                )
            }
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth()) {
                    PermissionRow(
                        icon = Icons.Rounded.AccessibilityNew,
                        title = "Accessibility Service",
                        subtitle = "Reads UI nodes and executes taps, scrolls, and text input",
                        granted = readiness.accessibilityEnabled,
                        buttonLabel = if (readiness.accessibilityEnabled) "Active" else "Enable",
                        onClick = { ZenoSystemBridge.openAccessibilitySettings(context) }
                    )
                    Spacer(Modifier.height(10.dp))
                    PermissionRow(
                        icon = Icons.Rounded.Layers,
                        title = "Floating Overlay (ZENO Orb)",
                        subtitle = "Displays the ZENO Orb over supported apps",
                        granted = readiness.overlayPermitted,
                        buttonLabel = if (readiness.overlayPermitted) "Granted" else "Allow",
                        onClick = { ZenoSystemBridge.openOverlayPermissionSettings(context) }
                    )
                    Spacer(Modifier.height(10.dp))
                    PermissionRow(
                        icon = Icons.Rounded.CameraAlt,
                        title = "On-Demand Screen Capture",
                        subtitle = "Optional MediaProjection fallback when an app hides UI nodes",
                        granted = readiness.screenCaptureActive,
                        buttonLabel = if (readiness.screenCaptureActive) "Stop" else "Grant",
                        onClick = {
                            if (readiness.screenCaptureActive) {
                                ZenoCaptureService.stopCaptureService(context)
                                onRefreshReadiness()
                            } else {
                                ScreenCaptureConsentActivity.launch(context)
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    PermissionRow(
                        icon = Icons.Rounded.NotificationsActive,
                        title = "Operator Status Notifications",
                        subtitle = "Shows persistent control indicator while Orb runs",
                        granted = readiness.notificationsEnabled,
                        buttonLabel = if (readiness.notificationsEnabled) "Enabled" else "Allow",
                        onClick = {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                ZenoSystemBridge.openAppNotificationSettings(context)
                            }
                        }
                    )
                }
            }

            // Editable Task Templates
            item {
                Text(
                    text = "EDITABLE TASK TEMPLATES",
                    style = MaterialTheme.typography.labelMedium,
                    color = ZenoTextSecondary
                )
            }
            items(templates, key = { it.id }) { template ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectTemplate(template.prompt) }
                        .testTag("template_${template.id}"),
                    shape = MaterialTheme.shapes.small,
                    color = ZenoElevatedBg,
                    border = BorderStroke(1.dp, ZenoBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.AutoFixHigh,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "${template.title}  •  ${template.category}",
                                style = MaterialTheme.typography.titleMedium,
                                color = ZenoTextPrimary
                            )
                            Text(
                                template.prompt,
                                style = MaterialTheme.typography.bodySmall,
                                color = ZenoTextSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Prompt Library (if any saved prompts exist)
            if (promptLibrary.isNotEmpty()) {
                item {
                    Text(
                        text = "PROMPT LIBRARY",
                        style = MaterialTheme.typography.labelMedium,
                        color = ZenoTextSecondary
                    )
                }
                items(promptLibrary.take(6), key = { "lib_${it.id}" }) { saved ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectTemplate(saved.prompt) },
                        shape = MaterialTheme.shapes.small,
                        color = ZenoElevatedBg,
                        border = BorderStroke(1.dp, ZenoBorder)
                    ) {
                        Text(
                            text = saved.prompt,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextPrimary,
                            modifier = Modifier.padding(12.dp),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // App Compatibility & Launcher
            item {
                Text(
                    text = "APP COMPATIBILITY (${installedApps.size} INSTALLED)",
                    style = MaterialTheme.typography.labelMedium,
                    color = ZenoTextSecondary
                )
            }
            if (installedApps.isNotEmpty()) {
                item {
                    OutlinedTextField(
                        value = appFilterQuery,
                        onValueChange = { appFilterQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tools_app_search_input"),
                        singleLine = true,
                        leadingIcon = {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = ZenoTextSecondary)
                        },
                        placeholder = { Text("Search installed apps to launch with ZENO Orb...") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = ZenoBorder,
                            focusedContainerColor = ZenoElevatedBg,
                            unfocusedContainerColor = ZenoElevatedBg
                        ),
                        shape = MaterialTheme.shapes.small
                    )
                }
            }
            if (filteredInstalledApps.isEmpty()) {
                item {
                    ZenoCard {
                        Text(
                            if (installedApps.isEmpty()) {
                                "No third-party launchable apps reported by PackageManager."
                            } else {
                                "No apps match \"$appFilterQuery\"."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                    }
                }
            } else {
                items(filteredInstalledApps, key = { it.packageName }) { app ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onLaunchAppWithOrb(app.packageName) },
                        shape = MaterialTheme.shapes.small,
                        color = ZenoElevatedBg,
                        border = BorderStroke(1.dp, ZenoBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(app.appName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${app.categoryHint} • ${app.packageName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ZenoTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(
                                Icons.AutoMirrored.Rounded.OpenInNew,
                                contentDescription = "Open ${app.appName} with ZENO Orb",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    granted: Boolean,
    buttonLabel: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (granted) ZenoSuccess else ZenoWarning,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = ZenoTextPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = ZenoTextSecondary)
        }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = onClick) {
            Text(buttonLabel)
        }
    }
}
