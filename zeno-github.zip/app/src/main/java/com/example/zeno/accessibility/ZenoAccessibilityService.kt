package com.example.zeno.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.zeno.capture.ZenoCaptureService
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.core.model.ActionType
import com.example.zeno.core.model.RectBounds
import com.example.zeno.core.model.ScreenNode
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.ZenoAction
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

private const val TAG = "ZenoA11yService"
private const val MAX_CAPTURED_NODES = 140
private const val MAX_TREE_DEPTH = 18

class ZenoAccessibilityService : AccessibilityService() {

    private val liveNodeReferences = ConcurrentHashMap<String, AccessibilityNodeInfo>()
    @Volatile
    private var lastPassiveCaptureMs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        ZenoSystemBridge.attachAccessibilityService(this)
        Log.i(TAG, "ZENO AccessibilityService connected.")
        captureCurrentScreenObservation()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString().orEmpty()
        if (pkg == packageName) return
        val isRelevantEvent = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED
        if (isRelevantEvent) {
            val now = System.currentTimeMillis()
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                now - lastPassiveCaptureMs >= 200L
            ) {
                lastPassiveCaptureMs = now
                captureCurrentScreenObservation()
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "ZENO AccessibilityService interrupted.")
        clearNodeCache()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        ZenoSystemBridge.detachAccessibilityService()
        clearNodeCache()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ZenoSystemBridge.detachAccessibilityService()
        clearNodeCache()
        super.onDestroy()
    }

    private fun clearNodeCache() {
        liveNodeReferences.clear()
    }

    suspend fun captureFreshObservationWithRetry(): ScreenObservation {
        val first = captureCurrentScreenObservation()
        if (first.hasAccessibilityData || first.packageName.isNotBlank()) return first
        delay(120L)
        return captureCurrentScreenObservation()
    }

    fun captureCurrentScreenObservation(): ScreenObservation {
        clearNodeCache()
        val root = resolveTargetWindowRoot()
        val (screenW, screenH) = getScreenDimensions()

        if (root == null) {
            val emptyObs = ScreenObservation(
                timestampMs = System.currentTimeMillis(),
                packageName = "",
                appName = "Screen inaccessible",
                windowTitle = "",
                screenWidth = screenW,
                screenHeight = screenH,
                nodes = emptyList(),
                summaryText = "No accessible window content reported by current app.",
                hasAccessibilityData = false,
                hasScreenshot = ZenoSystemBridge.latestScreenshot.value != null
            )
            ZenoSystemBridge.updateObservation(emptyObs)
            return emptyObs
        }

        val pkg = root.packageName?.toString().orEmpty()
        val appName = resolveAppName(pkg)
        val nodes = mutableListOf<ScreenNode>()
        runCatching { traverseNodeTree(root, depth = 0, out = nodes) }
            .onFailure { Log.w(TAG, "Partial tree traversal error: ${it.message}") }

        val summary = buildScreenContextSummary(appName, pkg, nodes)

        val observation = ScreenObservation(
            timestampMs = System.currentTimeMillis(),
            packageName = pkg,
            appName = appName,
            windowTitle = nodes.firstOrNull { it.text.isNotBlank() }?.text.orEmpty(),
            screenWidth = screenW,
            screenHeight = screenH,
            nodes = nodes,
            summaryText = summary,
            hasAccessibilityData = nodes.isNotEmpty(),
            hasScreenshot = ZenoSystemBridge.latestScreenshot.value != null
        )
        ZenoSystemBridge.updateObservation(observation)
        return observation
    }

    private fun traverseNodeTree(
        node: AccessibilityNodeInfo,
        depth: Int,
        out: MutableList<ScreenNode>
    ) {
        if (depth > MAX_TREE_DEPTH || out.size >= MAX_CAPTURED_NODES) return

        val rect = Rect()
        node.getBoundsInScreen(rect)
        val rawText = node.text?.toString()?.trim().orEmpty()
        val hintText = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            node.hintText?.toString()?.trim().orEmpty()
        } else ""
        val text = rawText.ifBlank { hintText }
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val viewId = node.viewIdResourceName?.trim().orEmpty()
        val hasSemanticValue = text.isNotBlank() || desc.isNotBlank() ||
            node.isClickable || node.isEditable || node.isScrollable || node.isCheckable

        if (node.isVisibleToUser && !rect.isEmpty && rect.width() > 2 && rect.height() > 2 && hasSemanticValue) {
            val nodeId = "n${out.size}"
            liveNodeReferences[nodeId] = node
            out.add(
                ScreenNode(
                    nodeId = nodeId,
                    className = node.className?.toString().orEmpty(),
                    text = text.take(160),
                    contentDescription = desc.take(160),
                    viewIdResourceName = viewId,
                    bounds = RectBounds(rect.left, rect.top, rect.right, rect.bottom),
                    isClickable = node.isClickable,
                    isEditable = node.isEditable,
                    isScrollable = node.isScrollable,
                    isCheckable = node.isCheckable,
                    isChecked = node.isChecked,
                    isEnabled = node.isEnabled,
                    isFocused = node.isFocused,
                    childCount = node.childCount,
                    isPassword = node.isPassword
                )
            )
        }

        for (i in 0 until node.childCount) {
            if (out.size >= MAX_CAPTURED_NODES) break
            val child = node.getChild(i) ?: continue
            traverseNodeTree(child, depth + 1, out)
        }
    }

    suspend fun captureScreenshotOnDemand(): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val a11yBitmap = captureA11yScreenshotApi30()
            if (a11yBitmap != null) {
                val scaled = scaleBitmapForVision(a11yBitmap)
                ZenoSystemBridge.updateScreenshot(scaled)
                return scaled
            }
        }
        val projectionBitmap = ZenoCaptureService.captureSingleFrame()
        if (projectionBitmap != null) {
            val scaled = scaleBitmapForVision(projectionBitmap)
            ZenoSystemBridge.updateScreenshot(scaled)
            return scaled
        }
        return null
    }

    private suspend fun captureA11yScreenshotApi30(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return suspendCancellableCoroutine { cont ->
            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    mainExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(screenshot: ScreenshotResult) {
                            val hwBuffer = screenshot.hardwareBuffer
                            val bitmap = try {
                                val raw = Bitmap.wrapHardwareBuffer(hwBuffer, screenshot.colorSpace)
                                raw?.copy(Bitmap.Config.ARGB_8888, false)
                            } finally {
                                hwBuffer.close()
                            }
                            if (cont.isActive) cont.resume(bitmap)
                        }

                        override fun onFailure(errorCode: Int) {
                            Log.w(TAG, "takeScreenshot failed with errorCode=$errorCode")
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                )
            } catch (e: Exception) {
                Log.e(TAG, "takeScreenshot threw exception", e)
                if (cont.isActive) cont.resume(null)
            }
        }
    }

    private fun scaleBitmapForVision(source: Bitmap): Bitmap {
        val maxEdge = 1080
        val w = source.width
        val h = source.height
        if (w <= maxEdge && h <= maxEdge) return source
        val scale = maxEdge.toFloat() / maxOf(w, h).toFloat()
        val targetW = (w * scale).toInt().coerceAtLeast(1)
        val targetH = (h * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, targetW, targetH, true)
    }

    suspend fun executeAction(action: ZenoAction, observation: ScreenObservation): ExecutionOutcome {
        return when (action.type) {
            ActionType.TAP, ActionType.SELECT_ELEMENT -> executeTap(action, observation)
            ActionType.LONG_PRESS -> executeLongPress(action, observation)
            ActionType.TEXT_INPUT -> executeTextInput(action, observation)
            ActionType.SCROLL -> executeScroll(action, observation)
            ActionType.SWIPE, ActionType.DRAG -> executeSwipeOrDrag(action, observation)
            ActionType.SLIDER_ADJUST -> executeSliderAdjust(action, observation)
            ActionType.BACK -> {
                val ok = performGlobalAction(GLOBAL_ACTION_BACK)
                ExecutionOutcome(ok, if (ok) "Navigated back" else "Back action failed")
            }
            ActionType.NAVIGATE -> {
                val ok = when (action.targetLabel.lowercase()) {
                    "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                    "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                    else -> performGlobalAction(GLOBAL_ACTION_BACK)
                }
                ExecutionOutcome(ok, if (ok) "Performed navigation (${action.targetLabel})" else "Navigate failed")
            }
            ActionType.OPEN_APP -> {
                val pkg = action.packageName.ifBlank { action.targetLabel }
                val ok = ZenoSystemBridge.launchApp(this, pkg)
                ExecutionOutcome(ok, if (ok) "Launched $pkg" else "Unable to launch $pkg")
            }
            ActionType.WAIT -> {
                delay(action.timeoutMs.coerceIn(500L, 4000L))
                ExecutionOutcome(true, "Waited for UI response")
            }
            ActionType.SCREENSHOT -> {
                val bmp = captureScreenshotOnDemand()
                ExecutionOutcome(bmp != null, if (bmp != null) "Captured screen snapshot" else "Screenshot unavailable")
            }
            ActionType.OBSERVE, ActionType.VERIFY -> {
                captureCurrentScreenObservation()
                ExecutionOutcome(true, "Observed screen state")
            }
            ActionType.ASK_USER -> {
                ExecutionOutcome(false, "User input requested: ${action.reason}")
            }
        }
    }

    private suspend fun executeTap(action: ZenoAction, observation: ScreenObservation): ExecutionOutcome {
        val targetNode = resolveAccessibilityNode(action, observation)
        if (targetNode != null) {
            var current: AccessibilityNodeInfo? = targetNode
            while (current != null) {
                if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return ExecutionOutcome(true, "Clicked '${action.targetLabel.ifBlank { action.targetNodeId }}'")
                }
                current = current.parent
            }
            val rect = Rect()
            targetNode.getBoundsInScreen(rect)
            if (rect.width() > 0 && rect.height() > 0) {
                val tapped = dispatchTapGesture(rect.centerX().toFloat(), rect.centerY().toFloat(), 90L)
                return ExecutionOutcome(tapped, if (tapped) "Tapped node bounds (${rect.centerX()}, ${rect.centerY()})" else "Tap gesture failed")
            }
        }

        val x = action.x
        val y = action.y
        if (x != null && y != null) {
            val clampedX = x.coerceIn(1, (observation.screenWidth - 1).coerceAtLeast(1))
            val clampedY = y.coerceIn(1, (observation.screenHeight - 1).coerceAtLeast(1))
            val tapped = dispatchTapGesture(clampedX.toFloat(), clampedY.toFloat(), 90L)
            return ExecutionOutcome(tapped, if (tapped) "Tapped visual target ($clampedX, $clampedY)" else "Tap gesture failed")
        }
        return ExecutionOutcome(false, "Target element '${action.targetLabel}' not found on screen")
    }

    private suspend fun executeLongPress(action: ZenoAction, observation: ScreenObservation): ExecutionOutcome {
        val targetNode = resolveAccessibilityNode(action, observation)
        if (targetNode != null) {
            if (targetNode.isLongClickable && targetNode.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) {
                return ExecutionOutcome(true, "Long-pressed '${action.targetLabel}'")
            }
            val rect = Rect()
            targetNode.getBoundsInScreen(rect)
            if (rect.width() > 0 && rect.height() > 0) {
                val ok = dispatchTapGesture(rect.centerX().toFloat(), rect.centerY().toFloat(), 650L)
                return ExecutionOutcome(ok, if (ok) "Long-pressed bounds" else "Long-press gesture failed")
            }
        }
        val x = action.x
        val y = action.y
        if (x != null && y != null) {
            val cx = x.coerceIn(1, (observation.screenWidth - 1).coerceAtLeast(1))
            val cy = y.coerceIn(1, (observation.screenHeight - 1).coerceAtLeast(1))
            val ok = dispatchTapGesture(cx.toFloat(), cy.toFloat(), 650L)
            return ExecutionOutcome(ok, if (ok) "Long-pressed ($cx, $cy)" else "Long-press failed")
        }
        return ExecutionOutcome(false, "Target for long-press not found")
    }

    private suspend fun executeTextInput(action: ZenoAction, observation: ScreenObservation): ExecutionOutcome {
        val rawNode = resolveAccessibilityNode(action, observation)
            ?: observation.nodes.firstOrNull { it.isEditable }?.let { liveNodeReferences[it.nodeId] }
        val targetNode = rawNode?.let { node ->
            if (node.isEditable) node else findEditableDescendant(node) ?: node
        }
        if (targetNode == null) {
            return ExecutionOutcome(false, "No editable input field found for text input")
        }
        val rect = Rect()
        targetNode.getBoundsInScreen(rect)
        if (!targetNode.isFocused) {
            targetNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            if (rect.width() > 0 && rect.height() > 0) {
                dispatchTapGesture(rect.centerX().toFloat(), rect.centerY().toFloat(), 80L)
                delay(200L)
            }
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, action.inputText)
        }
        val ok = targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return ExecutionOutcome(ok, if (ok) "Entered text into field" else "Failed to set text on target field")
    }

    private fun findEditableDescendant(node: AccessibilityNodeInfo, depth: Int = 0): AccessibilityNodeInfo? {
        if (depth > 3) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val match = findEditableDescendant(child, depth + 1)
            if (match != null) return match
        }
        return null
    }

    private suspend fun executeScroll(action: ZenoAction, observation: ScreenObservation): ExecutionOutcome {
        val targetNode = resolveAccessibilityNode(action, observation)?.takeIf { it.isScrollable }
            ?: observation.nodes.firstOrNull { it.isScrollable }?.let { liveNodeReferences[it.nodeId] }
        val forward = !action.scrollDirection.equals("backward", ignoreCase = true) &&
            !action.scrollDirection.equals("up", ignoreCase = true)

        if (targetNode != null) {
            val a11yAction = if (forward) {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            if (targetNode.performAction(a11yAction)) {
                return ExecutionOutcome(true, "Scrolled ${action.scrollDirection}")
            }
        }

        val w = observation.screenWidth.coerceAtLeast(720)
        val h = observation.screenHeight.coerceAtLeast(1280)
        val startX = (w * 0.5f)
        val startY = if (forward) h * 0.72f else h * 0.30f
        val endY = if (forward) h * 0.28f else h * 0.72f
        val ok = dispatchSwipeGesture(startX, startY, startX, endY, 380L)
        return ExecutionOutcome(ok, if (ok) "Swiped to scroll ${action.scrollDirection}" else "Scroll gesture failed")
    }

    private suspend fun executeSwipeOrDrag(action: ZenoAction, observation: ScreenObservation): ExecutionOutcome {
        val w = observation.screenWidth.coerceAtLeast(720)
        val h = observation.screenHeight.coerceAtLeast(1280)
        val maxX = (w - 1).coerceAtLeast(1)
        val maxY = (h - 1).coerceAtLeast(1)
        val sx = (action.x ?: (w / 2)).coerceIn(1, maxX).toFloat()
        val sy = (action.y ?: (h * 0.65f).toInt()).coerceIn(1, maxY).toFloat()
        val ex = (action.endX ?: sx.toInt()).coerceIn(1, maxX).toFloat()
        val ey = (action.endY ?: (h * 0.28f).toInt()).coerceIn(1, maxY).toFloat()
        val duration = if (action.type == ActionType.DRAG) 550L else 320L
        val ok = dispatchSwipeGesture(sx, sy, ex, ey, duration)
        return ExecutionOutcome(ok, if (ok) "Executed ${action.type.wireName}" else "${action.type.wireName} failed")
    }

    private suspend fun executeSliderAdjust(action: ZenoAction, observation: ScreenObservation): ExecutionOutcome {
        val targetNode = resolveAccessibilityNode(action, observation)
        val percent = (action.sliderPercent ?: 0.5f).coerceIn(0f, 1f)
        if (targetNode != null) {
            val rangeInfo = targetNode.rangeInfo
            if (rangeInfo != null) {
                val value = rangeInfo.min + (rangeInfo.max - rangeInfo.min) * percent
                val args = Bundle().apply {
                    putFloat(AccessibilityNodeInfo.ACTION_ARGUMENT_PROGRESS_VALUE, value)
                }
                if (targetNode.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS.id, args)) {
                    return ExecutionOutcome(true, "Adjusted slider to ${(percent * 100).toInt()}%")
                }
            }
            val rect = Rect()
            targetNode.getBoundsInScreen(rect)
            if (rect.width() > 20) {
                val startX = rect.centerX().toFloat()
                val endX = rect.left + rect.width() * percent
                val y = rect.centerY().toFloat()
                val ok = dispatchSwipeGesture(startX, y, endX, y, 420L)
                return ExecutionOutcome(ok, if (ok) "Dragged slider to ${(percent * 100).toInt()}%" else "Slider drag failed")
            }
        }
        return ExecutionOutcome(false, "Slider control not found")
    }

    private fun resolveTargetWindowRoot(): AccessibilityNodeInfo? {
        val active = rootInActiveWindow
        if (active != null && active.packageName?.toString() != packageName) {
            return active
        }
        val allWindows = windows.orEmpty()
        val appWindowRoot = allWindows
            .asSequence()
            .filter { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION }
            .mapNotNull { it.root }
            .firstOrNull { it.packageName?.toString() != packageName }
        if (appWindowRoot != null) return appWindowRoot

        val dialogWindowRoot = allWindows
            .asSequence()
            .filter { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_SYSTEM }
            .mapNotNull { it.root }
            .firstOrNull { root ->
                val pkg = root.packageName?.toString().orEmpty()
                pkg.isNotBlank() && pkg != packageName && pkg != "com.android.systemui"
            }
        return dialogWindowRoot ?: active
    }

    private fun resolveAccessibilityNode(
        action: ZenoAction,
        observation: ScreenObservation
    ): AccessibilityNodeInfo? {
        if (action.targetNodeId.isNotBlank()) {
            liveNodeReferences[action.targetNodeId]?.let { node ->
                if (node.refresh()) return node
            }
        }
        if (action.targetLabel.isNotBlank()) {
            val candidates = observation.nodes.filter {
                it.text.equals(action.targetLabel, ignoreCase = true) ||
                    it.contentDescription.equals(action.targetLabel, ignoreCase = true) ||
                    it.viewIdResourceName.substringAfterLast('/').equals(action.targetLabel, ignoreCase = true)
            }.ifEmpty {
                observation.nodes.filter {
                    it.primaryLabel().contains(action.targetLabel, ignoreCase = true)
                }
            }
            val match = if (candidates.size > 1 && action.x != null && action.y != null) {
                candidates.minByOrNull { n ->
                    val dx = n.bounds.centerX - action.x
                    val dy = n.bounds.centerY - action.y
                    dx * dx + dy * dy
                }
            } else {
                candidates.firstOrNull()
            }
            if (match != null) {
                liveNodeReferences[match.nodeId]?.let { node ->
                    if (node.refresh()) return node
                }
            }
        }
        return null
    }

    private suspend fun dispatchTapGesture(x: Float, y: Float, durationMs: Long): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return dispatchGestureSuspend(GestureDescription.Builder().addStroke(stroke).build())
    }

    private suspend fun dispatchSwipeGesture(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long
    ): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return dispatchGestureSuspend(GestureDescription.Builder().addStroke(stroke).build())
    }

    private suspend fun dispatchGestureSuspend(gesture: GestureDescription): Boolean {
        return suspendCancellableCoroutine { cont ->
            val dispatched = dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                },
                null
            )
            if (!dispatched && cont.isActive) {
                cont.resume(false)
            }
        }
    }

    private fun resolveAppName(pkg: String): String {
        if (pkg.isBlank()) return "System"
        return runCatching {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        }.getOrElse { pkg.substringAfterLast('.') }
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }
    }

    data class ExecutionOutcome(
        val success: Boolean,
        val detail: String
    )

    companion object {
        fun buildScreenContextSummary(
            appName: String,
            packageName: String,
            nodes: List<ScreenNode>
        ): String = buildString {
            append("App: $appName ($packageName). ")
            append("Visible controls: ${nodes.size}. ")
            val interactiveLabels = nodes
                .filter { it.isClickable || it.isEditable || it.isScrollable }
                .map { it.primaryLabel() }
                .filter { it.isNotBlank() }
                .distinct()
                .take(12)
            if (interactiveLabels.isNotEmpty()) {
                append("Key items: ${interactiveLabels.joinToString(", ")}")
            }
        }
    }
}
