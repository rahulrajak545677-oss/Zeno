package com.example.zeno.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.ZenoBgPrimary
import com.example.ui.theme.ZenoBgSecondary
import com.example.ui.theme.ZenoTextSecondary
import com.example.zeno.data.local.TaskHistoryEntity
import com.example.zeno.ui.ZenoMainViewModel
import com.example.zeno.ui.screens.ActivityScreen
import com.example.zeno.ui.screens.HomeScreen
import com.example.zeno.ui.screens.SettingsScreen
import com.example.zeno.ui.screens.ToolsScreen

object ZenoRoutes {
    const val HOME = "home"
    const val ACTIVITY = "activity"
    const val TOOLS = "tools"
    const val SETTINGS = "settings"
}

private data class NavItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val navItems = listOf(
    NavItem(ZenoRoutes.HOME, "Home", Icons.Rounded.Home, Icons.Outlined.Home),
    NavItem(ZenoRoutes.ACTIVITY, "Activity", Icons.Rounded.History, Icons.Outlined.History),
    NavItem(ZenoRoutes.TOOLS, "Tools", Icons.Rounded.Build, Icons.Outlined.Build),
    NavItem(ZenoRoutes.SETTINGS, "Settings", Icons.Rounded.Settings, Icons.Outlined.Settings)
)

@Composable
fun ZenoAppScaffold(
    viewModel: ZenoMainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ZenoRoutes.HOME

    val promptDraft by viewModel.promptDraft.collectAsStateWithLifecycle()
    val memory by viewModel.taskMemory.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val readiness by viewModel.systemReadiness.collectAsStateWithLifecycle()
    val recentTasks by viewModel.taskHistory.collectAsStateWithLifecycle()
    val promptHistory by viewModel.promptHistory.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val screenAnalysisState by viewModel.screenAnalysisState.collectAsStateWithLifecycle()
    val planPreviewState by viewModel.planPreviewState.collectAsStateWithLifecycle()
    val connectionTestState by viewModel.connectionTestState.collectAsStateWithLifecycle()

    var selectedTaskForDetail by remember { mutableStateOf<TaskHistoryEntity?>(null) }

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(ZenoBgPrimary)
    ) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = ZenoBgSecondary,
                        tonalElevation = 0.dp
                    ) {
                        navItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                modifier = Modifier.testTag("nav_${item.route}"),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                                    unselectedIconColor = ZenoTextSecondary,
                                    unselectedTextColor = ZenoTextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = ZenoBgSecondary
                    ) {
                        navItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                modifier = Modifier.testTag("rail_${item.route}"),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                                    unselectedIconColor = ZenoTextSecondary,
                                    unselectedTextColor = ZenoTextSecondary
                                )
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ZenoRoutes.HOME,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(ZenoRoutes.HOME) {
                        HomeScreen(
                            promptDraft = promptDraft,
                            memory = memory,
                            settings = settings,
                            readiness = readiness,
                            recentTasks = recentTasks,
                            promptHistory = promptHistory,
                            installedApps = installedApps,
                            planPreviewState = planPreviewState,
                            statusBanner = statusBanner,
                            onPromptChange = viewModel::updatePromptDraft,
                            onClearPrompt = viewModel::clearPromptDraft,
                            onSaveInstruction = { viewModel.saveInstructionForOrb(context) },
                            onPreviewNeuralPlan = viewModel::previewNeuralPlan,
                            onLaunchOrb = { viewModel.launchOrbOrRequestOverlay(context) },
                            onStopOrb = { viewModel.stopOrb(context) },
                            onLaunchAppWithOrb = { pkg -> viewModel.launchAppWithOrb(context, pkg) },
                            onStartTask = viewModel::startTaskNow,
                            onPauseTask = viewModel::pauseTask,
                            onResumeTask = viewModel::resumeTask,
                            onStopTask = viewModel::stopTask,
                            onRestartTask = viewModel::restartTask,
                            onConfirmConsequential = viewModel::confirmConsequentialAction,
                            onCancelConsequential = viewModel::cancelConsequentialAction,
                            onOpenSettings = { navigateTo(ZenoRoutes.SETTINGS) },
                            onOpenTaskDetail = { task ->
                                selectedTaskForDetail = task
                                navigateTo(ZenoRoutes.ACTIVITY)
                            },
                            onDismissBanner = viewModel::dismissBanner,
                            onDeletePromptHistory = viewModel::deletePromptEntry
                        )
                    }

                    composable(ZenoRoutes.ACTIVITY) {
                        ActivityScreen(
                            tasks = recentTasks,
                            selectedTaskForDetail = selectedTaskForDetail,
                            onSelectTaskForDetail = { selectedTaskForDetail = it },
                            onReusePrompt = { prompt ->
                                viewModel.updatePromptDraft(prompt)
                                navigateTo(ZenoRoutes.HOME)
                            },
                            onRetryTask = { prompt ->
                                viewModel.updatePromptDraft(prompt)
                                viewModel.startTaskNow()
                                navigateTo(ZenoRoutes.HOME)
                            },
                            onDeleteTask = viewModel::deleteHistoryEntry,
                            onClearAll = viewModel::clearAllHistory
                        )
                    }

                    composable(ZenoRoutes.TOOLS) {
                        ToolsScreen(
                            templates = viewModel.templates,
                            promptLibrary = promptHistory,
                            installedApps = installedApps,
                            readiness = readiness,
                            promptDraft = promptDraft,
                            screenAnalysisState = screenAnalysisState,
                            planPreviewState = planPreviewState,
                            onSelectTemplate = { prompt ->
                                viewModel.updatePromptDraft(prompt)
                                navigateTo(ZenoRoutes.HOME)
                            },
                            onRunScreenAnalysis = viewModel::runScreenAnalysis,
                            onPreviewNeuralPlan = viewModel::previewNeuralPlan,
                            onLaunchAppWithOrb = { pkg -> viewModel.launchAppWithOrb(context, pkg) },
                            onOpenOrbCustomization = { navigateTo(ZenoRoutes.SETTINGS) },
                            onRefreshReadiness = { viewModel.refreshSystemReadiness(context) }
                        )
                    }

                    composable(ZenoRoutes.SETTINGS) {
                        SettingsScreen(
                            settings = settings,
                            readiness = readiness,
                            connectionTestState = connectionTestState,
                            onSetDarkTheme = viewModel::setDarkTheme,
                            onSetAccentStyle = viewModel::setAccentStyle,
                            onSetOrbSize = viewModel::setOrbSize,
                            onSetOrbTransparency = viewModel::setOrbTransparency,
                            onResetOrbPosition = viewModel::resetOrbPosition,
                            onSetAnimationIntensity = viewModel::setAnimationIntensity,
                            onSetHaptics = viewModel::setHapticsEnabled,
                            onSetAutoPilot = viewModel::setAutoPilotEnabled,
                            onSetScreenAwareness = viewModel::setScreenAwarenessEnabled,
                            onSetActionDelayMs = viewModel::setActionDelayMs,
                            onSetVerification = viewModel::setVerificationEnabled,
                            onSetMaxRetries = viewModel::setMaxRetries,
                            onSetPauseUnexpected = viewModel::setPauseOnUnexpectedScreen,
                            onSetConfirmConsequential = viewModel::setConfirmConsequentialActions,
                            onSetAiProvider = viewModel::setAiProviderType,
                            onSetTextModel = viewModel::setTextModel,
                            onSetVisionModel = viewModel::setVisionModel,
                            onSetReasoningDepth = viewModel::setReasoningDepth,
                            onSetCustomEndpoint = viewModel::setCustomEndpointUrl,
                            onSetCustomApiKey = viewModel::setCustomApiKey,
                            onSetCustomModelId = viewModel::setCustomModelId,
                            onTestConnection = viewModel::testAiConnection,
                            onClearCachedImages = viewModel::clearCachedScreenshots,
                            onClearTaskHistory = viewModel::clearAllHistory
                        )
                    }
                }
            }
        }
    }
}
