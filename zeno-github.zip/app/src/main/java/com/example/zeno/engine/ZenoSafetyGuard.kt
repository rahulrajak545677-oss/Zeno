package com.example.zeno.engine

import com.example.zeno.core.model.ActionType
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.ZenoAction

object ZenoSafetyGuard {

    private val authScreenKeywords = listOf(
        "password", "passcode", "pin code", "enter pin", "2fa",
        "two-factor", "verification code", "one-time password", "otp",
        "biometric", "fingerprint", "face unlock", "unlock to continue",
        "authenticate"
    )

    private val destructiveOrConsequentialKeywords = listOf(
        "delete", "erase", "remove permanently", "uninstall", "wipe",
        "purchase", "buy now", "pay now", "checkout", "place order",
        "confirm payment", "transfer", "send message", "send email",
        "publish", "post now", "share publicly", "sign out", "log out",
        "deactivate", "reset settings", "change password", "security settings"
    )

    private val safeSystemOverlays = setOf(
        "com.android.systemui",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        "android"
    )

    fun detectSecurityOrAuthScreen(observation: ScreenObservation): String? {
        val hasPasswordField = observation.nodes.any { it.isPassword }
        if (hasPasswordField) {
            return "Password or PIN input detected in ${observation.appName}. Complete authentication manually before resuming ZENO."
        }
        val combinedText = buildString {
            append(observation.windowTitle.lowercase())
            append(' ')
            observation.nodes.take(35).forEach { node ->
                append(node.text.lowercase())
                append(' ')
                append(node.contentDescription.lowercase())
                append(' ')
            }
        }
        val matchedKeyword = authScreenKeywords.firstOrNull { kw ->
            combinedText.contains(kw)
        }
        if (matchedKeyword != null && observation.nodes.any { it.isEditable }) {
            return "Authentication screen ($matchedKeyword) detected in ${observation.appName}. ZENO will not bypass security screens."
        }
        return null
    }

    fun evaluateConsequentialAction(
        action: ZenoAction,
        observation: ScreenObservation
    ): ZenoAction {
        if (action.isConsequential) return action
        if (action.type == ActionType.WAIT ||
            action.type == ActionType.OBSERVE ||
            action.type == ActionType.VERIFY ||
            action.type == ActionType.BACK ||
            action.type == ActionType.SCREENSHOT
        ) {
            return action
        }

        val targetNodeText = observation.nodes
            .firstOrNull { it.nodeId == action.targetNodeId }
            ?.primaryLabel()
            .orEmpty()

        val corpus = listOf(
            action.targetLabel,
            targetNodeText,
            action.reason
        ).joinToString(" ").lowercase()

        val matched = destructiveOrConsequentialKeywords.firstOrNull { kw ->
            corpus.contains(kw)
        }
        return if (matched != null) {
            action.copy(
                isConsequential = true,
                reason = "${action.reason} (Safety guard flagged '$matched')"
            )
        } else {
            action
        }
    }

    fun isUnexpectedAppSwitch(
        previousPackage: String,
        currentPackage: String,
        lastAction: ZenoAction?
    ): Boolean {
        if (previousPackage.isBlank() || currentPackage.isBlank()) return false
        if (previousPackage == currentPackage) return false
        if (currentPackage in safeSystemOverlays) return false
        if (lastAction?.type == ActionType.OPEN_APP || lastAction?.type == ActionType.NAVIGATE) {
            return false
        }
        return true
    }
}
