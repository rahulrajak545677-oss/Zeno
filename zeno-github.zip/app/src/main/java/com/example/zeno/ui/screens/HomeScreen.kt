package com.example.zeno.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PersonOutline
import androidx.compose.material.icons.rounded.PhotoFilter
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ZenoBgPrimary
import com.example.ui.theme.ZenoBorder
import com.example.ui.theme.ZenoCardBg
import com.example.ui.theme.ZenoElevatedBg
import com.example.ui.theme.ZenoError
import com.example.ui.theme.ZenoSuccess
import com.example.ui.theme.ZenoTextPrimary
import com.example.ui.theme.ZenoTextSecondary
import com.example.ui.theme.ZenoWarning
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.core.model.InstalledAppInfo
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.ZenoState
import com.example.zeno.data.local.AiProviderType
import com.example.zeno.data.local.PromptHistoryEntity
import com.example.zeno.data.local.TaskHistoryEntity
import com.example.zeno.data.local.ZenoSettings
import com.example.zeno.overlay.OrbVoiceInputActivity
import com.example.zeno.ui.PlanPreviewUiState
import com.example.zeno.ui.SystemReadiness
import com.example.zeno.ui.components.LiveTaskMonitorCard
import com.example.zeno.ui.components.PlanStepRow
import com.example.zeno.ui.components.ZenoCard
import com.example.zeno.ui.components.ZenoLogoMark
import com.example.zeno.ui.components.ZenoStatusPill
import com.example.zeno.ui.components.formatElapsed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    promptDraft: String,
    memory: TaskMemory,
    settings: ZenoSettings,
    readiness: SystemReadiness,
    recentTasks: List<TaskHistoryEntity>,
    promptHistory: List<PromptHistoryEntity>,
    installedApps: List<InstalledAppInfo>,
    planPreviewState: PlanPreviewUiState,
    statusBanner: String?,
    onPromptChange: (String) -> Unit,
    onClearPrompt: () -> Unit,
    onSaveInstruction: () -> Unit,
    onPreviewNeuralPlan: () -> Unit,
    onLaunchOrb: () -> Unit,
    onStopOrb: () -> Unit,
    onLaunchAppWithOrb: (String) -> Unit,
    onStartTask: () -> Unit,
    onPauseTask: () -> Unit,
    onResumeTask: () -> Unit,
    onStopTask: () -> Unit,
    onRestartTask: () -> Unit,
    onConfirmConsequential: () -> Unit,
    onCancelConsequential: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenTaskDetail: (TaskHistoryEntity) -> Unit,
    onDismissBanner: () -> Unit,
    onDeletePromptHistory: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showPromptHistorySheet by remember { mutableStateOf(false) }
    var showProfileSheet by remember { mutableStateOf(false) }
    var showAppPickerSheet by remember { mutableStateOf(false) }
    var showPlanPreviewSheet by remember { mutableStateOf(false) }
    var appSearchQuery by remember { mutableStateOf("") }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            OrbVoiceInputActivity.launch(context, applyToEngine = false)
        }
    }

    val effectiveAiState = remember(memory.status, readiness.accessibilityEnabled) {
        when {
            memory.status.isRunning || memory.status == ZenoState.PAUSED -> memory.status
            !readiness.accessibilityEnabled -> ZenoState.OFFLINE
            else -> ZenoState.READY
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ZenoLogoMark(size = 30.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ZENO AI",
                                style = MaterialTheme.typography.titleLarge,
                                color = ZenoTextPrimary
                            )
                            Text(
                                text = "Your AI. Your Apps. Your Actions.",
                                style = MaterialTheme.typography.bodySmall,
                                color = ZenoTextSecondary
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ZenoStatusPill(state = effectiveAiState)
                        IconButton(
                            onClick = { showProfileSheet = true },
                            modifier = Modifier.testTag("header_profile_btn")
                        ) {
                            Icon(
                                Icons.Rounded.PersonOutline,
                                contentDescription = "ZENO Core profile and readiness",
                                tint = ZenoTextPrimary
                            )
                        }
                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier.testTag("header_settings_btn")
                        ) {
                            Icon(
                                Icons.Rounded.Settings,
                                contentDescription = "Open Settings",
                                tint = ZenoTextPrimary
                            )
                        }
                    }
                }
            }

            // Status / Feedback banner
            if (statusBanner != null) {
                item {
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = statusBanner,
                                style = MaterialTheme.typography.bodySmall,
                                color = ZenoTextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = onDismissBanner) {
                                Text("OK")
                            }
                        }
                    }
                }
            }

            // Futuristic Hero Section
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.large)
                        .background(ZenoCardBg)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_zeno_hero_bg),
                        contentDescription = "ZENO orbital visual backdrop",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .matchParentSize()
                    )
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        ZenoBgPrimary.copy(alpha = 0.45f),
                                        ZenoBgPrimary.copy(alpha = 0.88f)
                                    )
                                )
                            )
                    )
                    Surface(
                        color = Color.Transparent,
                        shape = MaterialTheme.shapes.large,
                        border = BorderStroke(1.dp, ZenoBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "ZENO CORE • ${settings.textModel.uppercase()}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (readiness.overlayRunning) "ORB ACTIVE" else "ORB STANDBY",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (readiness.overlayRunning) ZenoSuccess else ZenoTextSecondary
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = "Hey, ready?",
                                style = MaterialTheme.typography.displaySmall,
                                color = ZenoTextPrimary
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Tell me what to do. I'll take care of the steps.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = ZenoTextSecondary
                            )
                            Spacer(Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        if (readiness.overlayRunning) onStopOrb() else onLaunchOrb()
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("hero_launch_orb_btn")
                                ) {
                                    Icon(
                                        Icons.Rounded.Layers,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (readiness.overlayRunning) "Hide ZENO Orb" else "Open ZENO Orb")
                                }
                                OutlinedButton(
                                    onClick = {
                                        if (!readiness.accessibilityEnabled) {
                                            ZenoSystemBridge.openAccessibilitySettings(context)
                                        } else {
                                            showProfileSheet = true
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("hero_a11y_btn")
                                ) {
                                    Icon(
                                        Icons.Rounded.AccessibilityNew,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = if (readiness.accessibilityEnabled) ZenoSuccess else ZenoWarning
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        if (readiness.accessibilityEnabled) "Vision Active" else "Enable Vision",
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Setup Readiness Checklist (shown until required system & AI capabilities are ready)
            val missingFirebaseConfig = settings.aiProviderType == AiProviderType.FIREBASE_GEMINI &&
                !readiness.firebaseConfigured
            if (!readiness.accessibilityEnabled || !readiness.overlayPermitted || missingFirebaseConfig) {
                item {
                    ZenoCard(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = ZenoWarning.copy(alpha = 0.45f)
                    ) {
                        Text(
                            text = "SETUP READINESS",
                            style = MaterialTheme.typography.labelMedium,
                            color = ZenoWarning
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Complete these steps so ZENO can observe screens, float over apps, and plan actions:",
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                        Spacer(Modifier.height(10.dp))
                        SystemReadinessRow(
                            title = "1. Accessibility Vision & Touch",
                            granted = readiness.accessibilityEnabled,
                            actionLabel = if (readiness.accessibilityEnabled) "Enabled" else "Enable",
                            onAction = { ZenoSystemBridge.openAccessibilitySettings(context) }
                        )
                        Spacer(Modifier.height(8.dp))
                        SystemReadinessRow(
                            title = "2. Floating ZENO Orb Overlay",
                            granted = readiness.overlayPermitted,
                            actionLabel = if (readiness.overlayPermitted) "Granted" else "Allow",
                            onAction = { ZenoSystemBridge.openOverlayPermissionSettings(context) }
                        )
                        if (missingFirebaseConfig) {
                            Spacer(Modifier.height(8.dp))
                            SystemReadinessRow(
                                title = "3. AI Engine (missing google-services.json)",
                                granted = false,
                                actionLabel = "Compatible API",
                                onAction = onOpenSettings
                            )
                        }
                    }
                }
            }

            // AI Instruction Composer
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "INSTRUCTION COMPOSER",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row {
                            IconButton(
                                onClick = { showPromptHistorySheet = true },
                                modifier = Modifier.testTag("composer_history_btn")
                            ) {
                                Icon(
                                    Icons.Rounded.History,
                                    contentDescription = "Prompt history",
                                    tint = ZenoTextSecondary
                                )
                            }
                            if (promptDraft.isNotBlank()) {
                                IconButton(
                                    onClick = onClearPrompt,
                                    modifier = Modifier.testTag("composer_clear_btn")
                                ) {
                                    Icon(
                                        Icons.Rounded.Clear,
                                        contentDescription = "Clear instruction",
                                        tint = ZenoTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = promptDraft,
                        onValueChange = onPromptChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("instruction_input"),
                        minLines = 3,
                        maxLines = 6,
                        placeholder = {
                            Text(
                                "Tell ZENO what you want done...\nExample: Open my editing app and create a cinematic edit with smooth zooms, beat sync, and dark color grading.",
                                color = ZenoTextSecondary.copy(alpha = 0.7f),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = ZenoBorder,
                            focusedContainerColor = ZenoBgPrimary,
                            unfocusedContainerColor = ZenoBgPrimary,
                            focusedTextColor = ZenoTextPrimary,
                            unfocusedTextColor = ZenoTextPrimary
                        ),
                        shape = MaterialTheme.shapes.small
                    )

                    Spacer(Modifier.height(12.dp))

                    val isSyncedToActiveOrb = readiness.overlayRunning &&
                        promptDraft.isNotBlank() &&
                        memory.originalInstruction.trim() == promptDraft.trim()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (ZenoSystemBridge.isMicrophoneGranted(context)) {
                                    OrbVoiceInputActivity.launch(context, applyToEngine = false)
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("composer_voice_btn")
                        ) {
                            Icon(Icons.Rounded.Mic, contentDescription = "Voice input", modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Voice", maxLines = 1, softWrap = false)
                        }

                        OutlinedButton(
                            onClick = {
                                showPlanPreviewSheet = true
                                onPreviewNeuralPlan()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("composer_plan_preview_btn")
                        ) {
                            Icon(Icons.Rounded.Psychology, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Neural Plan", maxLines = 1, softWrap = false)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = onSaveInstruction,
                            modifier = Modifier
                                .weight(1.2f)
                                .heightIn(min = 48.dp)
                                .testTag("composer_save_btn")
                        ) {
                            Icon(
                                imageVector = if (isSyncedToActiveOrb) {
                                    Icons.Rounded.CheckCircle
                                } else {
                                    Icons.AutoMirrored.Rounded.Send
                                },
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = if (isSyncedToActiveOrb) "Orb Ready" else "Ready for Orb",
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        OutlinedButton(
                            onClick = { showAppPickerSheet = true },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("composer_app_orb_btn")
                        ) {
                            Icon(
                                Icons.Rounded.Apps,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("App + Orb", maxLines = 1, softWrap = false)
                        }
                    }
                }
            }

            // Quick Actions
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "QUICK STARTERS",
                        style = MaterialTheme.typography.labelMedium,
                        color = ZenoTextSecondary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuickStarterChip(
                            label = "Edit Video",
                            icon = Icons.Rounded.Movie,
                            onClick = {
                                onPromptChange("Open my video editor and create a cinematic edit with smooth zooms, transitions, and dark color grading.")
                            }
                        )
                        QuickStarterChip(
                            label = "Photo Editing",
                            icon = Icons.Rounded.PhotoFilter,
                            onClick = {
                                onPromptChange("Enhance the current photo with balanced exposure, clean shadows, and crisp natural tones.")
                            }
                        )
                        QuickStarterChip(
                            label = "Automate App",
                            icon = Icons.Rounded.Tune,
                            onClick = {
                                onPromptChange("Navigate the open app, perform the requested repetitive steps cleanly, and verify each change.")
                            }
                        )
                        QuickStarterChip(
                            label = "Creative Tasks",
                            icon = Icons.Rounded.AutoAwesome,
                            onClick = {
                                onPromptChange("Refine the open design layout with aligned elements, readable typography, and balanced spacing.")
                            }
                        )
                    }
                }
            }

            // Live Task Monitor (visible when task has been initialized)
            item {
                AnimatedVisibility(visible = memory.taskId.isNotBlank()) {
                    LiveTaskMonitorCard(
                        memory = memory,
                        onStart = onStartTask,
                        onPause = onPauseTask,
                        onResume = onResumeTask,
                        onStop = onStopTask,
                        onRestart = onRestartTask,
                        onConfirmConsequential = onConfirmConsequential,
                        onCancelConsequential = onCancelConsequential
                    )
                }
            }

            // Recent Activity
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RECENT ACTIVITY",
                        style = MaterialTheme.typography.labelMedium,
                        color = ZenoTextSecondary
                    )
                    Text(
                        text = "${recentTasks.size} recorded",
                        style = MaterialTheme.typography.labelSmall,
                        color = ZenoTextSecondary
                    )
                }
            }

            if (recentTasks.isEmpty()) {
                item {
                    ZenoCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "No task runs recorded yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = ZenoTextPrimary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Write an instruction above, open your target app, tap the floating ZENO Orb, and press START.",
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                    }
                }
            } else {
                items(recentTasks.take(5), key = { it.taskId }) { task ->
                    RecentTaskRowCard(
                        entry = task,
                        onOpenDetails = { onOpenTaskDetail(task) },
                        onReuse = { onPromptChange(task.originalPrompt) }
                    )
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    if (showPromptHistorySheet) {
        ModalBottomSheet(
            onDismissRequest = { showPromptHistorySheet = false },
            containerColor = ZenoCardBg,
            contentColor = ZenoTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Prompt History",
                    style = MaterialTheme.typography.headlineSmall,
                    color = ZenoTextPrimary
                )
                Spacer(Modifier.height(8.dp))
                if (promptHistory.isEmpty()) {
                    Text(
                        text = "Your saved and executed instructions will appear here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ZenoTextSecondary,
                        modifier = Modifier.padding(vertical = 20.dp)
                    )
                } else {
                    LazyColumn(modifier = Modifier.height(300.dp)) {
                        items(promptHistory, key = { it.id }) { item ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        onPromptChange(item.prompt)
                                        showPromptHistorySheet = false
                                    },
                                shape = MaterialTheme.shapes.small,
                                color = ZenoElevatedBg,
                                border = BorderStroke(1.dp, ZenoBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.prompt,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = ZenoTextPrimary,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    IconButton(onClick = { onDeletePromptHistory(item.id) }) {
                                        Icon(
                                            Icons.Rounded.Clear,
                                            contentDescription = "Delete prompt",
                                            tint = ZenoTextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
            }
        }
    }

    if (showProfileSheet) {
        ModalBottomSheet(
            onDismissRequest = { showProfileSheet = false },
            containerColor = ZenoCardBg,
            contentColor = ZenoTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ZenoLogoMark(size = 34.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("ZENO Core Operator", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "One instruction. Every app.",
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                    }
                }
                SystemReadinessRow(
                    title = "Accessibility Vision & Touch",
                    granted = readiness.accessibilityEnabled,
                    actionLabel = "Configure",
                    onAction = { ZenoSystemBridge.openAccessibilitySettings(context) }
                )
                SystemReadinessRow(
                    title = "Floating ZENO Orb Overlay",
                    granted = readiness.overlayPermitted,
                    actionLabel = if (readiness.overlayPermitted) "Ready" else "Grant",
                    onAction = { ZenoSystemBridge.openOverlayPermissionSettings(context) }
                )
                SystemReadinessRow(
                    title = "AI Provider",
                    granted = true,
                    actionLabel = settings.textModel,
                    onAction = {
                        showProfileSheet = false
                        onOpenSettings()
                    }
                )
                Spacer(Modifier.height(18.dp))
            }
        }
    }

    if (showAppPickerSheet) {
        val filteredApps = remember(installedApps, appSearchQuery) {
            if (appSearchQuery.isBlank()) installedApps
            else installedApps.filter {
                it.appName.contains(appSearchQuery, ignoreCase = true) ||
                    it.categoryHint.contains(appSearchQuery, ignoreCase = true) ||
                    it.packageName.contains(appSearchQuery, ignoreCase = true)
            }
        }
        ModalBottomSheet(
            onDismissRequest = { showAppPickerSheet = false },
            containerColor = ZenoCardBg,
            contentColor = ZenoTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Launch App with ZENO Orb",
                    style = MaterialTheme.typography.headlineSmall,
                    color = ZenoTextPrimary
                )
                Text(
                    text = "Opens the floating orb alongside your selected app so you can press START right inside it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ZenoTextSecondary
                )
                OutlinedTextField(
                    value = appSearchQuery,
                    onValueChange = { appSearchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search installed apps...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) }
                )
                if (filteredApps.isEmpty()) {
                    Text(
                        text = "No matching launchable apps found.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ZenoTextSecondary,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    LazyColumn(modifier = Modifier.height(320.dp)) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        showAppPickerSheet = false
                                        onLaunchAppWithOrb(app.packageName)
                                    },
                                shape = MaterialTheme.shapes.small,
                                color = ZenoElevatedBg,
                                border = BorderStroke(1.dp, ZenoBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = app.appName,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = ZenoTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${app.categoryHint} • ${app.packageName}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = ZenoTextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Icon(
                                        Icons.Rounded.OpenInNew,
                                        contentDescription = "Launch ${app.appName}",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showPlanPreviewSheet) {
        ModalBottomSheet(
            onDismissRequest = { showPlanPreviewSheet = false },
            containerColor = ZenoCardBg,
            contentColor = ZenoTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Neural Plan Preview",
                    style = MaterialTheme.typography.headlineSmall,
                    color = ZenoTextPrimary
                )
                Text(
                    text = promptDraft.ifBlank { "No instruction entered yet." },
                    style = MaterialTheme.typography.bodySmall,
                    color = ZenoTextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                when (planPreviewState) {
                    PlanPreviewUiState.Idle -> Unit
                    PlanPreviewUiState.Loading -> Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Generating adaptive steps via ZENO Core...", style = MaterialTheme.typography.bodyMedium)
                    }
                    is PlanPreviewUiState.Success -> {
                        LazyColumn(modifier = Modifier.height(260.dp)) {
                            items(planPreviewState.steps, key = { it.id }) { step ->
                                PlanStepRow(step = step)
                            }
                        }
                        Button(
                            onClick = {
                                showPlanPreviewSheet = false
                                onSaveInstruction()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                        ) {
                            Text("Ready for Orb")
                        }
                    }
                    is PlanPreviewUiState.Error -> {
                        Text(
                            text = planPreviewState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoError,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

@Composable
private fun QuickStarterChip(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    AssistChip(
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelLarge) },
        leadingIcon = {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = ZenoCardBg,
            labelColor = ZenoTextPrimary
        ),
        border = BorderStroke(1.dp, ZenoBorder)
    )
}

@Composable
fun RecentTaskRowCard(
    entry: TaskHistoryEntity,
    onOpenDetails: () -> Unit,
    onReuse: () -> Unit
) {
    val dateText = remember(entry.timestampMs) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(entry.timestampMs))
    }
    ZenoCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenDetails)
            .testTag("recent_task_${entry.taskId}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.taskName,
                    style = MaterialTheme.typography.titleMedium,
                    color = ZenoTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${entry.targetAppName} • $dateText • ${formatElapsed(entry.durationMs)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ZenoTextSecondary
                )
            }
            Spacer(Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = when (entry.status) {
                    "Completed" -> ZenoSuccess.copy(alpha = 0.14f)
                    "Paused" -> ZenoWarning.copy(alpha = 0.14f)
                    else -> ZenoError.copy(alpha = 0.14f)
                }
            ) {
                Text(
                    text = entry.status,
                    style = MaterialTheme.typography.labelSmall,
                    color = when (entry.status) {
                        "Completed" -> ZenoSuccess
                        "Paused" -> ZenoWarning
                        else -> ZenoError
                    },
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = entry.summary,
            style = MaterialTheme.typography.bodySmall,
            color = ZenoTextSecondary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${entry.verifiedActions}/${entry.actionsPerformed} verified",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            TextButton(onClick = onReuse) {
                Icon(Icons.Rounded.Replay, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Reuse")
            }
        }
    }
}

@Composable
private fun SystemReadinessRow(
    title: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = ZenoElevatedBg,
        border = BorderStroke(1.dp, ZenoBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (granted) ZenoSuccess else ZenoWarning)
                )
                Spacer(Modifier.width(10.dp))
                Text(title, style = MaterialTheme.typography.bodyMedium, color = ZenoTextPrimary)
            }
            TextButton(onClick = onAction) {
                Text(actionLabel)
            }
        }
    }
}
