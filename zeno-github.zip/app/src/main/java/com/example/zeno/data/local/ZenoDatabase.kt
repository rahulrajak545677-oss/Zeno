package com.example.zeno.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [TaskHistoryEntity::class, PromptHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class ZenoDatabase : RoomDatabase() {
    abstract fun zenoDao(): ZenoDao

    companion object {
        @Volatile
        private var instance: ZenoDatabase? = null

        fun getInstance(context: Context): ZenoDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    ZenoDatabase::class.java,
                    "zeno_local.db"
                ).build().also { instance = it }
            }
        }
    }
}
