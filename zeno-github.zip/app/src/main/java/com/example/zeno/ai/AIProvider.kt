package com.example.zeno.ai

import android.graphics.Bitmap
import com.example.zeno.core.model.AiDecisionResult
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.ScreenAnalysisReport
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.VerificationResult
import com.example.zeno.core.model.ZenoAction

/**
 * Contract for ZENO AI providers managing instruction interpretation,
 * next-action planning, verification, and vision-based screen analysis.
 */
interface AIProvider {
    val providerName: String

    suspend fun testConnection(modelName: String): Result<String>

    /**
     * Interprets a natural-language user instruction (with optional current screen context)
     * into an ordered Neural Plan of adaptive steps.
     */
    suspend fun interpretInstruction(
        instruction: String,
        observation: ScreenObservation?,
        modelName: String
    ): Result<List<PlanStep>>

    /**
     * Evaluates the current accessibility observation and optional visual screenshot
     * to determine the single next touch/UI action toward the user's goal.
     */
    suspend fun decideNextAction(
        memory: TaskMemory,
        observation: ScreenObservation,
        screenshot: Bitmap?,
        textModel: String,
        visionModel: String
    ): Result<AiDecisionResult>

    /**
     * Compares before and after screen states (and optional screenshot) to verify
     * whether an executed action achieved its expected UI outcome.
     */
    suspend fun verifyActionOutcome(
        action: ZenoAction,
        before: ScreenObservation,
        after: ScreenObservation,
        screenshot: Bitmap?,
        modelName: String
    ): Result<VerificationResult>

    /**
     * Performs vision-based and accessibility-tree screen analysis to describe
     * the current app, purpose, interactive controls, and visibility limitations.
     */
    suspend fun analyzeScreen(
        observation: ScreenObservation,
        screenshot: Bitmap?,
        modelName: String
    ): Result<ScreenAnalysisReport>
}
