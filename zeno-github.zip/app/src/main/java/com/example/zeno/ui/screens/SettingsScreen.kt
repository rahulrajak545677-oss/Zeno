package com.example.zeno.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ZenoError
import com.example.ui.theme.ZenoSuccess
import com.example.ui.theme.ZenoTextPrimary
import com.example.ui.theme.ZenoTextSecondary
import com.example.ui.theme.ZenoWarning
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.data.local.AccentStyle
import com.example.zeno.data.local.AiProviderType
import com.example.zeno.data.local.AnimationIntensity
import com.example.zeno.data.local.ReasoningDepth
import com.example.zeno.data.local.ZenoSettings
import com.example.zeno.ui.ConnectionTestState
import com.example.zeno.ui.SystemReadiness
import com.example.zeno.ui.components.ZenoCard
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: ZenoSettings,
    readiness: SystemReadiness,
    connectionTestState: ConnectionTestState,
    onSetDarkTheme: (Boolean) -> Unit,
    onSetAccentStyle: (AccentStyle) -> Unit,
    onSetOrbSize: (Int) -> Unit,
    onSetOrbTransparency: (Float) -> Unit,
    onResetOrbPosition: () -> Unit,
    onSetAnimationIntensity: (AnimationIntensity) -> Unit,
    onSetHaptics: (Boolean) -> Unit,
    onSetAutoPilot: (Boolean) -> Unit,
    onSetScreenAwareness: (Boolean) -> Unit,
    onSetActionDelayMs: (Int) -> Unit,
    onSetVerification: (Boolean) -> Unit,
    onSetMaxRetries: (Int) -> Unit,
    onSetPauseUnexpected: (Boolean) -> Unit,
    onSetConfirmConsequential: (Boolean) -> Unit,
    onSetAiProvider: (AiProviderType) -> Unit,
    onSetTextModel: (String) -> Unit,
    onSetVisionModel: (String) -> Unit,
    onSetReasoningDepth: (ReasoningDepth) -> Unit,
    onSetCustomEndpoint: (String) -> Unit,
    onSetCustomApiKey: (String) -> Unit,
    onSetCustomModelId: (String) -> Unit,
    onTestConnection: () -> Unit,
    onClearCachedImages: () -> Unit,
    onClearTaskHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showClearHistoryConfirm by remember { mutableStateOf(false) }
    var showAboutZenoDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Settings", style = MaterialTheme.typography.headlineMedium, color = ZenoTextPrimary)
                Text(
                    "Appearance, ZENO Orb physics, AutoPilot safety, AI models, and privacy",
                    style = MaterialTheme.typography.bodySmall,
                    color = ZenoTextSecondary
                )
            }

            // 1. Appearance
            item { SectionHeader("APPEARANCE") }
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth()) {
                    SettingToggleRow(
                        title = "Obsidian Dark Theme",
                        subtitle = "Pure #080A09 surface vs dim graphite",
                        checked = settings.darkTheme,
                        onCheckedChange = onSetDarkTheme
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("Accent Color", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AccentStyle.entries.forEach { style ->
                            FilterChip(
                                selected = settings.accentStyle == style,
                                onClick = { onSetAccentStyle(style) },
                                label = { Text(style.label) }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Orb Size: ${settings.orbSizeDp}dp", style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = settings.orbSizeDp.toFloat(),
                        onValueChange = { onSetOrbSize(it.roundToInt()) },
                        valueRange = 48f..84f
                    )
                    Text(
                        "Orb Opacity: ${(settings.orbTransparency * 100).roundToInt()}%",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Slider(
                        value = settings.orbTransparency,
                        onValueChange = onSetOrbTransparency,
                        valueRange = 0.45f..1.0f
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Position: (${settings.orbPosX}, ${settings.orbPosY})",
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                        OutlinedButton(onClick = onResetOrbPosition) {
                            Text("Reset Orb Position")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Animation Intensity", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AnimationIntensity.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.animationIntensity == mode,
                                onClick = { onSetAnimationIntensity(mode) },
                                label = { Text(mode.label) }
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    SettingToggleRow(
                        title = "Haptic Feedback",
                        subtitle = "Subtle tactile confirmation when interacting with the orb",
                        checked = settings.hapticsEnabled,
                        onCheckedChange = onSetHaptics
                    )
                }
            }

            // 2. Automation
            item { SectionHeader("AUTOMATION & AUTOPILOT") }
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth()) {
                    SettingToggleRow(
                        title = "AutoPilot Mode",
                        subtitle = "Execute multi-step permitted actions without prompting each tap",
                        checked = settings.autoPilotEnabled,
                        onCheckedChange = onSetAutoPilot
                    )
                    SettingToggleRow(
                        title = "Screen Awareness (Vision)",
                        subtitle = "Allow on-demand screenshot vision when UI node tree is sparse",
                        checked = settings.screenAwarenessEnabled,
                        onCheckedChange = onSetScreenAwareness
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Action Delay: ${settings.actionDelayMs}ms", style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = settings.actionDelayMs.toFloat(),
                        onValueChange = { onSetActionDelayMs((it / 100f).roundToInt() * 100) },
                        valueRange = 400f..3000f
                    )
                    SettingToggleRow(
                        title = "Self-Check Verification",
                        subtitle = "Re-read and verify UI outcome after every meaningful action",
                        checked = settings.verificationEnabled,
                        onCheckedChange = onSetVerification
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Max Retries per Step: ${settings.maxRetries}", style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = settings.maxRetries.toFloat(),
                        onValueChange = { onSetMaxRetries(it.roundToInt()) },
                        valueRange = 1f..5f,
                        steps = 3
                    )
                    SettingToggleRow(
                        title = "Pause on Unexpected Screen",
                        subtitle = "Halt immediately if an unrecognized dialog or screen appears",
                        checked = settings.pauseOnUnexpectedScreen,
                        onCheckedChange = onSetPauseUnexpected
                    )
                    SettingToggleRow(
                        title = "Confirm Consequential Actions",
                        subtitle = "Always stop before delete, send, publish, pay, or security changes",
                        checked = settings.confirmConsequentialActions,
                        onCheckedChange = onSetConfirmConsequential
                    )
                }
            }

            // 3. AI Provider
            item { SectionHeader("AI ENGINE & MODELS") }
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Provider", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AiProviderType.entries.forEach { p ->
                            FilterChip(
                                selected = settings.aiProviderType == p,
                                onClick = { onSetAiProvider(p) },
                                label = { Text(if (p == AiProviderType.FIREBASE_GEMINI) "Gemini (Built-in)" else "Compatible API") }
                            )
                        }
                    }

                    if (settings.aiProviderType == AiProviderType.FIREBASE_GEMINI) {
                        Spacer(Modifier.height(8.dp))
                        Text("Text & Planning Model", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-4-argon").forEach { m ->
                                FilterChip(
                                    selected = settings.textModel == m,
                                    onClick = { onSetTextModel(m) },
                                    label = { Text(m.removePrefix("gemini-")) }
                                )
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Vision Model", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("gemini-3.8-flash", "gemini-4-argon").forEach { m ->
                                FilterChip(
                                    selected = settings.visionModel == m,
                                    onClick = { onSetVisionModel(m) },
                                    label = { Text(m.removePrefix("gemini-")) }
                                )
                            }
                        }
                        Text(
                            text = if (readiness.firebaseConfigured) {
                                "Powered by Firebase AI Logic & App Check — no API key required."
                            } else {
                                "FirebaseApp is not configured in this APK build (missing app/google-services.json). Add google-services.json and rebuild, or switch Provider to 'Compatible API' above."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (readiness.firebaseConfigured) ZenoTextSecondary else ZenoWarning
                        )
                    } else {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.customEndpointUrl,
                            onValueChange = onSetCustomEndpoint,
                            label = { Text("Chat Completions Endpoint URL") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.customModelId,
                            onValueChange = onSetCustomModelId,
                            label = { Text("Model ID") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = settings.customApiKey,
                            onValueChange = onSetCustomApiKey,
                            label = { Text("API Key (Stored locally in DataStore)") },
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    Text("Reasoning Depth", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ReasoningDepth.entries.forEach { d ->
                            FilterChip(
                                selected = settings.reasoningDepth == d,
                                onClick = { onSetReasoningDepth(d) },
                                label = { Text(d.label) }
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "AI Calls This Install: ${settings.totalAiCalls}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ZenoTextSecondary
                        )
                        Button(
                            onClick = onTestConnection,
                            enabled = connectionTestState !is ConnectionTestState.Testing,
                            modifier = Modifier.testTag("settings_test_ai_btn")
                        ) {
                            if (connectionTestState is ConnectionTestState.Testing) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(6.dp))
                            }
                            Text("Test Connection")
                        }
                    }

                    when (connectionTestState) {
                        is ConnectionTestState.Success -> Text(
                            connectionTestState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoSuccess,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        is ConnectionTestState.Error -> Text(
                            connectionTestState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoError,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        else -> Unit
                    }
                }
            }

            // 4. Privacy & Data
            item { SectionHeader("PRIVACY & PERMISSIONS") }
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "How ZENO analyzes screens",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "ZENO reads visible UI nodes through Android's Accessibility Service only when you start or run a task. Optional screenshots are captured on demand and kept strictly in memory until cleared.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ZenoTextSecondary
                    )
                    Spacer(Modifier.height(10.dp))
                    StatusLine("Accessibility Service", readiness.accessibilityEnabled)
                    StatusLine("Floating Overlay Permission", readiness.overlayPermitted)
                    StatusLine("Screen Capture Session", readiness.screenCaptureActive)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onClearCachedImages, modifier = Modifier.weight(1f)) {
                            Text("Clear Snapshots")
                        }
                        OutlinedButton(onClick = { showClearHistoryConfirm = true }, modifier = Modifier.weight(1f)) {
                            Text("Clear History", color = ZenoError)
                        }
                    }
                }
            }

            // 5. System
            item { SectionHeader("SYSTEM & ABOUT") }
            item {
                ZenoCard(modifier = Modifier.fillMaxWidth()) {
                    StatusLine("Notifications", readiness.notificationsEnabled)
                    StatusLine("Unrestricted Battery", readiness.batteryOptimizationIgnored)
                    StatusLine("Orb Foreground Service", readiness.overlayRunning)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "If Android stops the floating orb while switching heavy creative apps, exempt ZENO from battery optimization.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ZenoTextSecondary
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { ZenoSystemBridge.openBatteryOptimizationSettings(context) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Battery Settings")
                        }
                        OutlinedButton(
                            onClick = { ZenoSystemBridge.openAppNotificationSettings(context) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Notifications")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "ZENO v1.0 • Universal AI Touch Operator",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        TextButton(onClick = { showAboutZenoDialog = true }) {
                            Text("Core Architecture")
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(14.dp)) }
        }
    }

    if (showClearHistoryConfirm) {
        AlertDialog(
            onDismissRequest = { showClearHistoryConfirm = false },
            containerColor = com.example.ui.theme.ZenoCardBg,
            title = { Text("Clear all task history?", color = ZenoTextPrimary) },
            text = {
                Text(
                    "All recorded automation runs and verification logs will be permanently deleted from local storage.",
                    color = ZenoTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onClearTaskHistory()
                        showClearHistoryConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ZenoError,
                        contentColor = ZenoTextPrimary
                    )
                ) { Text("Clear All") }
            },
            dismissButton = {
                TextButton(onClick = { showClearHistoryConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showAboutZenoDialog) {
        AlertDialog(
            onDismissRequest = { showAboutZenoDialog = false },
            containerColor = com.example.ui.theme.ZenoCardBg,
            title = { Text("ZENO Architecture", color = ZenoTextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "• ZENO Core: Autonomous reasoning engine powered by Firebase AI Logic & App Check.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ZenoTextPrimary
                    )
                    Text(
                        "• Vision: Real-time Android Accessibility tree inspection paired with optional on-demand screen snapshots.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ZenoTextPrimary
                    )
                    Text(
                        "• Neural Plan: Dynamic app-agnostic step planner that adapts to whatever app is open.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ZenoTextPrimary
                    )
                    Text(
                        "• Self-Check: Post-action before/after screen verification with automatic retry and safety confirmation gates.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ZenoTextPrimary
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutZenoDialog = false }) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        color = ZenoTextSecondary
    )
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = ZenoTextPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = ZenoTextSecondary)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun StatusLine(label: String, active: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = ZenoTextSecondary)
        Text(
            text = if (active) "Active" else "Inactive",
            style = MaterialTheme.typography.labelSmall,
            color = if (active) ZenoSuccess else ZenoWarning
        )
    }
}
