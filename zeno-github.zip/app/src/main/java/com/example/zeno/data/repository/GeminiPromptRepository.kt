package com.example.zeno.data.repository

import android.graphics.Bitmap
import android.util.Log
import com.example.zeno.ai.GeminiClientWrapper
import com.example.zeno.data.local.ZenoPreferencesRepository
import com.google.firebase.ai.type.Schema
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow

private const val TAG = "GeminiPromptRepository"

sealed interface PromptResult {
    data object Idle : PromptResult
    data object Loading : PromptResult
    data class Streaming(val partialText: String) : PromptResult
    data class Success(
        val text: String,
        val modelName: String,
        val latencyMs: Long
    ) : PromptResult
    data class Error(val message: String) : PromptResult
}

/**
 * Repository handling prompt-to-model requests using the secure [GeminiClientWrapper].
 */
class GeminiPromptRepository(
    private val clientWrapper: GeminiClientWrapper = GeminiClientWrapper(),
    private val prefsRepo: ZenoPreferencesRepository? = null
) {

    suspend fun sendPrompt(
        prompt: String,
        systemInstruction: String? = null,
        modelOverride: String? = null
    ): Result<String> {
        val model = resolveModelName(modelOverride)
        val result = clientWrapper.generateText(
            prompt = prompt,
            modelName = model,
            systemInstruction = systemInstruction
        )
        if (result.isSuccess) {
            prefsRepo?.incrementAiCalls()
        }
        return result
    }

    suspend fun sendMultimodalPrompt(
        prompt: String,
        screenshot: Bitmap,
        modelOverride: String? = null
    ): Result<String> {
        val model = resolveVisionModelName(modelOverride)
        val result = clientWrapper.generateMultimodal(
            prompt = prompt,
            image = screenshot,
            modelName = model
        )
        if (result.isSuccess) {
            prefsRepo?.incrementAiCalls()
        }
        return result
    }

    suspend fun sendStructuredPrompt(
        prompt: String,
        schema: Schema,
        screenshot: Bitmap? = null,
        modelOverride: String? = null
    ): Result<String> {
        val model = if (screenshot != null) {
            resolveVisionModelName(modelOverride)
        } else {
            resolveModelName(modelOverride)
        }
        val result = clientWrapper.generateStructuredJson(
            prompt = prompt,
            schema = schema,
            image = screenshot,
            modelName = model
        )
        if (result.isSuccess) {
            prefsRepo?.incrementAiCalls()
        }
        return result
    }

    fun streamPrompt(
        prompt: String,
        modelOverride: String? = null
    ): Flow<PromptResult> = flow {
        emit(PromptResult.Loading)
        val started = System.currentTimeMillis()
        val model = resolveModelName(modelOverride)
        val builder = StringBuilder()

        clientWrapper.streamText(prompt = prompt, modelName = model).collect { chunk ->
            builder.append(chunk)
            emit(PromptResult.Streaming(builder.toString()))
        }

        val finalText = builder.toString().trim()
        if (finalText.isBlank()) {
            emit(PromptResult.Error("Model returned an empty response."))
        } else {
            prefsRepo?.incrementAiCalls()
            emit(
                PromptResult.Success(
                    text = finalText,
                    modelName = model,
                    latencyMs = System.currentTimeMillis() - started
                )
            )
        }
    }.catch { throwable ->
        if (throwable is CancellationException && throwable !is TimeoutCancellationException) {
            throw throwable
        }
        val msg = when (throwable) {
            is TimeoutCancellationException -> "Request timed out after 60 seconds. Please try again."
            else -> throwable.localizedMessage ?: "Prompt request failed."
        }
        Log.e(TAG, "streamPrompt failed", throwable)
        emit(PromptResult.Error(msg))
    }

    suspend fun verifyConnection(modelOverride: String? = null): Result<String> {
        val started = System.currentTimeMillis()
        val model = resolveModelName(modelOverride)
        return sendPrompt(
            prompt = "Reply with 'ZENO Core online' and nothing else.",
            modelOverride = model
        ).map { text ->
            val elapsed = System.currentTimeMillis() - started
            "$text ($model • ${elapsed}ms)"
        }
    }

    private suspend fun resolveModelName(override: String?): String {
        val raw = override ?: prefsRepo?.settingsFlow?.first()?.textModel
            ?: GeminiClientWrapper.DEFAULT_MODEL
        return GeminiClientWrapper.sanitizeModelName(raw)
    }

    private suspend fun resolveVisionModelName(override: String?): String {
        val raw = override ?: prefsRepo?.settingsFlow?.first()?.visionModel
            ?: GeminiClientWrapper.DEFAULT_MODEL
        return GeminiClientWrapper.sanitizeModelName(raw)
    }
}
