package com.example.zeno.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.core.model.InstalledAppInfo
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.PromptTemplate
import com.example.zeno.core.model.ScreenAnalysisReport
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.data.local.AccentStyle
import com.example.zeno.data.local.AiProviderType
import com.example.zeno.data.local.AnimationIntensity
import com.example.zeno.data.local.PromptHistoryEntity
import com.example.zeno.data.local.ReasoningDepth
import com.example.zeno.data.local.TaskHistoryEntity
import com.example.zeno.data.local.TaskHistoryRepository
import com.example.zeno.data.local.ZenoDatabase
import com.example.zeno.data.local.ZenoPreferencesRepository
import com.example.zeno.data.local.ZenoSettings
import com.example.zeno.engine.ZenoAgentEngine
import com.example.zeno.overlay.ZenoOverlayService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SystemReadiness(
    val accessibilityEnabled: Boolean = false,
    val overlayPermitted: Boolean = false,
    val overlayRunning: Boolean = false,
    val screenCaptureActive: Boolean = false,
    val notificationsEnabled: Boolean = false,
    val microphoneGranted: Boolean = false,
    val batteryOptimizationIgnored: Boolean = false,
    val firebaseConfigured: Boolean = true
)

sealed interface ConnectionTestState {
    data object Idle : ConnectionTestState
    data object Testing : ConnectionTestState
    data class Success(val message: String) : ConnectionTestState
    data class Error(val message: String) : ConnectionTestState
}

sealed interface ScreenAnalysisUiState {
    data object Idle : ScreenAnalysisUiState
    data object Analyzing : ScreenAnalysisUiState
    data class Success(val report: ScreenAnalysisReport) : ScreenAnalysisUiState
    data class Error(val message: String) : ScreenAnalysisUiState
}

sealed interface PlanPreviewUiState {
    data object Idle : PlanPreviewUiState
    data object Loading : PlanPreviewUiState
    data class Success(val steps: List<PlanStep>) : PlanPreviewUiState
    data class Error(val message: String) : PlanPreviewUiState
}

class ZenoMainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val prefsRepo = ZenoPreferencesRepository(appContext)
    private val historyRepo = TaskHistoryRepository(ZenoDatabase.getInstance(appContext).zenoDao())
    private val engine = ZenoAgentEngine.getInstance(appContext)

    val settings: StateFlow<ZenoSettings> = prefsRepo.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ZenoSettings()
    )

    val taskMemory: StateFlow<TaskMemory> = engine.taskMemory

    val taskHistory: StateFlow<List<TaskHistoryEntity>> = historyRepo.taskHistory.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val promptHistory: StateFlow<List<PromptHistoryEntity>> = historyRepo.promptHistory.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val isAccessibilityConnected = ZenoSystemBridge.isAccessibilityConnected
    val isOverlayRunning = ZenoSystemBridge.isOverlayRunning
    val isScreenCaptureActive = ZenoSystemBridge.isScreenCaptureActive
    val latestObservation = ZenoSystemBridge.latestObservation

    private val _promptDraft = MutableStateFlow("")
    val promptDraft: StateFlow<String> = _promptDraft.asStateFlow()

    private val _systemReadiness = MutableStateFlow(SystemReadiness())
    val systemReadiness: StateFlow<SystemReadiness> = _systemReadiness.asStateFlow()

    private val _connectionTestState = MutableStateFlow<ConnectionTestState>(ConnectionTestState.Idle)
    val connectionTestState: StateFlow<ConnectionTestState> = _connectionTestState.asStateFlow()

    private val _screenAnalysisState = MutableStateFlow<ScreenAnalysisUiState>(ScreenAnalysisUiState.Idle)
    val screenAnalysisState: StateFlow<ScreenAnalysisUiState> = _screenAnalysisState.asStateFlow()

    private val _planPreviewState = MutableStateFlow<PlanPreviewUiState>(PlanPreviewUiState.Idle)
    val planPreviewState: StateFlow<PlanPreviewUiState> = _planPreviewState.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    val templates: List<PromptTemplate> = listOf(
        PromptTemplate(
            id = "cinematic_edit",
            title = "Cinematic edit",
            category = "Edit Video",
            prompt = "In the currently open video editor, add a smooth zoom transition, apply subtle dark cinematic color grading, and prepare the timeline for review."
        ),
        PromptTemplate(
            id = "photo_enhance",
            title = "Smooth photo enhancement",
            category = "Photo Editing",
            prompt = "Enhance the open photo with balanced contrast, crisp highlights, natural warmth, and slight vignette without oversaturating."
        ),
        PromptTemplate(
            id = "animate_image",
            title = "Animate image",
            category = "Creative Tasks",
            prompt = "Create a subtle keyframe scale and pan animation on the selected layer using available motion controls."
        ),
        PromptTemplate(
            id = "organize_files",
            title = "Organize files",
            category = "Automate App",
            prompt = "Sort the visible files by date, create a clean project folder if needed, and group matching items without deleting anything."
        ),
        PromptTemplate(
            id = "create_design",
            title = "Create design",
            category = "Creative Tasks",
            prompt = "Adjust the open canvas layout for balanced spacing, high-contrast typography, and clean alignment."
        ),
        PromptTemplate(
            id = "clean_document",
            title = "Clean up document",
            category = "Docs & Writing",
            prompt = "Review the open document, clean up heading hierarchy, fix spacing, and organize bullet lists."
        ),
        PromptTemplate(
            id = "repetitive_task",
            title = "Repetitive task",
            category = "Automate App",
            prompt = "Perform the visible repetitive selection and formatting steps consistently across the listed items and stop for review."
        )
    )

    init {
        viewModelScope.launch {
            val saved = prefsRepo.settingsFlow.first().savedInstruction
            if (saved.isNotBlank() && _promptDraft.value.isBlank()) {
                _promptDraft.value = saved
                engine.setInstructionDraft(saved)
            }
        }
        viewModelScope.launch {
            ZenoSystemBridge.lastVoiceTranscript.collect { transcript ->
                if (!transcript.isNullOrBlank()) {
                    updatePromptDraft(transcript)
                    ZenoSystemBridge.consumeVoiceTranscript()
                }
            }
        }
        refreshSystemReadiness(appContext)
        loadInstalledApps()
    }

    fun refreshSystemReadiness(context: Context = appContext) {
        _systemReadiness.value = SystemReadiness(
            accessibilityEnabled = ZenoSystemBridge.isAccessibilityConnected.value ||
                ZenoSystemBridge.isAccessibilityEnabledInSettings(context),
            overlayPermitted = ZenoSystemBridge.canDrawOverlays(context),
            overlayRunning = ZenoSystemBridge.isOverlayRunning.value,
            screenCaptureActive = ZenoSystemBridge.isScreenCaptureActive.value,
            notificationsEnabled = ZenoSystemBridge.areNotificationsEnabled(context),
            microphoneGranted = ZenoSystemBridge.isMicrophoneGranted(context),
            batteryOptimizationIgnored = ZenoSystemBridge.isIgnoringBatteryOptimizations(context),
            firebaseConfigured = ZenoSystemBridge.isFirebaseReady(context)
        )
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            val apps = withContext(Dispatchers.IO) {
                ZenoSystemBridge.getLaunchableApps(appContext)
            }
            _installedApps.value = apps
        }
    }

    fun updatePromptDraft(text: String) {
        _promptDraft.value = text
        engine.setInstructionDraft(text)
    }

    fun clearPromptDraft() {
        _promptDraft.value = ""
        engine.setInstructionDraft("")
    }

    fun saveInstructionForOrb(context: Context = appContext) {
        val text = _promptDraft.value.trim()
        if (text.isBlank()) {
            _statusBanner.value = "Write an instruction for ZENO first."
            return
        }
        engine.setInstructionDraft(text)
        viewModelScope.launch {
            historyRepo.recordPrompt(text)
        }
        if (!ZenoSystemBridge.canDrawOverlays(context)) {
            ZenoSystemBridge.openOverlayPermissionSettings(context)
            refreshSystemReadiness(context)
            _statusBanner.value = "Instruction saved! Allow 'Display over other apps' so the ZENO Orb can appear."
            return
        }
        ZenoOverlayService.start(context)
        refreshSystemReadiness(context)
        val a11yReady = ZenoSystemBridge.isAccessibilityConnected.value ||
            ZenoSystemBridge.isAccessibilityEnabledInSettings(context)
        _statusBanner.value = if (a11yReady) {
            "ZENO Orb is ready with your instruction! Open any app and tap the Orb to START."
        } else {
            "Instruction loaded in ZENO Orb! Enable Accessibility Vision to let ZENO read screens and tap."
        }
    }

    fun launchOrbOrRequestOverlay(context: Context) {
        if (!ZenoSystemBridge.canDrawOverlays(context)) {
            ZenoSystemBridge.openOverlayPermissionSettings(context)
            _statusBanner.value = "Enable 'Display over other apps' for ZENO to launch the floating orb."
            return
        }
        if (_promptDraft.value.isNotBlank()) {
            engine.setInstructionDraft(_promptDraft.value.trim())
            viewModelScope.launch { historyRepo.recordPrompt(_promptDraft.value.trim()) }
        }
        ZenoOverlayService.start(context)
        refreshSystemReadiness(context)
        _statusBanner.value = "ZENO Orb launched. Switch to any supported app and tap the orb."
    }

    fun stopOrb(context: Context) {
        ZenoOverlayService.stop(context)
        refreshSystemReadiness(context)
    }

    fun launchAppWithOrb(context: Context, packageName: String) {
        val text = _promptDraft.value.trim()
        if (text.isNotBlank()) {
            engine.setInstructionDraft(text)
            viewModelScope.launch { historyRepo.recordPrompt(text) }
        }
        val overlayPermitted = ZenoSystemBridge.canDrawOverlays(context)
        if (overlayPermitted && !ZenoSystemBridge.isOverlayRunning.value) {
            ZenoOverlayService.start(context)
        }
        refreshSystemReadiness(context)
        val ok = ZenoSystemBridge.launchApp(context, packageName)
        if (!ok) {
            _statusBanner.value = "Unable to launch package $packageName."
        } else if (!overlayPermitted) {
            _statusBanner.value = "Opened app without ZENO Orb — allow 'Display over other apps' to float ZENO."
        }
    }

    fun startTaskNow() {
        val text = _promptDraft.value.trim()
        if (text.isNotBlank()) {
            engine.startTask(text)
        } else {
            engine.startTask()
        }
    }

    fun pauseTask() = engine.pauseTask()
    fun resumeTask() = engine.resumeTask()
    fun stopTask() = engine.stopTask()
    fun restartTask() = engine.restartTask()
    fun confirmConsequentialAction() = engine.confirmPendingConsequentialAction()
    fun cancelConsequentialAction() = engine.cancelPendingConsequentialAction()

    fun dismissBanner() {
        _statusBanner.value = null
    }

    fun runScreenAnalysis() {
        viewModelScope.launch {
            _screenAnalysisState.value = ScreenAnalysisUiState.Analyzing
            val result = engine.analyzeCurrentScreenOnce()
            _screenAnalysisState.value = result.fold(
                onSuccess = { ScreenAnalysisUiState.Success(it) },
                onFailure = { ScreenAnalysisUiState.Error(it.localizedMessage ?: "Screen analysis failed.") }
            )
        }
    }

    fun previewNeuralPlan() {
        val text = _promptDraft.value.trim()
        viewModelScope.launch {
            _planPreviewState.value = PlanPreviewUiState.Loading
            val result = engine.previewNeuralPlan(text)
            _planPreviewState.value = result.fold(
                onSuccess = { PlanPreviewUiState.Success(it) },
                onFailure = { PlanPreviewUiState.Error(it.localizedMessage ?: "Failed to generate Neural Plan.") }
            )
        }
    }

    fun testAiConnection() {
        viewModelScope.launch {
            _connectionTestState.value = ConnectionTestState.Testing
            val result = engine.testAiConnection()
            _connectionTestState.value = result.fold(
                onSuccess = { ConnectionTestState.Success(it) },
                onFailure = { ConnectionTestState.Error(it.localizedMessage ?: "Connection failed.") }
            )
        }
    }

    fun deleteHistoryEntry(taskId: String) {
        viewModelScope.launch { historyRepo.deleteTask(taskId) }
    }

    fun clearAllHistory() {
        viewModelScope.launch { historyRepo.clearAllTasks() }
    }

    fun deletePromptEntry(id: Long) {
        viewModelScope.launch { historyRepo.deletePrompt(id) }
    }

    fun clearCachedScreenshots() {
        ZenoSystemBridge.clearCachedScreenshots()
        _statusBanner.value = "Cleared cached screen snapshots from memory."
    }

    // Settings updates
    fun setDarkTheme(enabled: Boolean) = viewModelScope.launch { prefsRepo.setDarkTheme(enabled) }
    fun setAccentStyle(style: AccentStyle) = viewModelScope.launch { prefsRepo.setAccentStyle(style) }
    fun setOrbSize(dp: Int) = viewModelScope.launch { prefsRepo.setOrbSize(dp) }
    fun setOrbTransparency(alpha: Float) = viewModelScope.launch { prefsRepo.setOrbTransparency(alpha) }
    fun resetOrbPosition() = viewModelScope.launch { prefsRepo.updateOrbPosition(40, 420) }
    fun setAnimationIntensity(intensity: AnimationIntensity) = viewModelScope.launch { prefsRepo.setAnimationIntensity(intensity) }
    fun setHapticsEnabled(enabled: Boolean) = viewModelScope.launch { prefsRepo.setHapticsEnabled(enabled) }
    fun setAutoPilotEnabled(enabled: Boolean) = viewModelScope.launch { prefsRepo.setAutoPilotEnabled(enabled) }
    fun setScreenAwarenessEnabled(enabled: Boolean) = viewModelScope.launch { prefsRepo.setScreenAwarenessEnabled(enabled) }
    fun setActionDelayMs(ms: Int) = viewModelScope.launch { prefsRepo.setActionDelayMs(ms) }
    fun setVerificationEnabled(enabled: Boolean) = viewModelScope.launch { prefsRepo.setVerificationEnabled(enabled) }
    fun setMaxRetries(retries: Int) = viewModelScope.launch { prefsRepo.setMaxRetries(retries) }
    fun setPauseOnUnexpectedScreen(enabled: Boolean) = viewModelScope.launch { prefsRepo.setPauseOnUnexpectedScreen(enabled) }
    fun setConfirmConsequentialActions(enabled: Boolean) = viewModelScope.launch { prefsRepo.setConfirmConsequentialActions(enabled) }
    fun setAiProviderType(type: AiProviderType) = viewModelScope.launch { prefsRepo.setAiProviderType(type) }
    fun setTextModel(model: String) = viewModelScope.launch { prefsRepo.setTextModel(model) }
    fun setVisionModel(model: String) = viewModelScope.launch { prefsRepo.setVisionModel(model) }
    fun setReasoningDepth(depth: ReasoningDepth) = viewModelScope.launch { prefsRepo.setReasoningDepth(depth) }
    fun setCustomEndpointUrl(url: String) = viewModelScope.launch { prefsRepo.setCustomEndpointUrl(url) }
    fun setCustomApiKey(key: String) = viewModelScope.launch { prefsRepo.setCustomApiKey(key) }
    fun setCustomModelId(modelId: String) = viewModelScope.launch { prefsRepo.setCustomModelId(modelId) }
}
