package com.example.zeno.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ZenoDao {
    @Query("SELECT * FROM task_history ORDER BY timestampMs DESC")
    fun observeTaskHistory(): Flow<List<TaskHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTaskHistory(entry: TaskHistoryEntity)

    @Query("DELETE FROM task_history WHERE taskId = :taskId")
    suspend fun deleteTaskHistoryById(taskId: String)

    @Query("DELETE FROM task_history")
    suspend fun clearTaskHistory()

    @Query("SELECT * FROM prompt_history ORDER BY lastUsedTimestampMs DESC LIMIT 25")
    fun observePromptHistory(): Flow<List<PromptHistoryEntity>>

    @Query("SELECT * FROM prompt_history WHERE prompt = :prompt LIMIT 1")
    suspend fun findPrompt(prompt: String): PromptHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromptHistory(entry: PromptHistoryEntity)

    @Query("DELETE FROM prompt_history WHERE id = :id")
    suspend fun deletePromptById(id: Long)

    @Query("DELETE FROM prompt_history")
    suspend fun clearPromptHistory()
}
