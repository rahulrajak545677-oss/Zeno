package com.example.zeno.data.local

import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.StepStatus
import com.example.zeno.core.model.TaskLogEntry
import com.example.zeno.core.model.TaskMemory
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.flow.Flow

@JsonClass(generateAdapter = true)
internal data class StoredPlanStepDto(
    val id: String = "",
    val title: String = "",
    val status: String = StepStatus.PENDING.name,
    val detail: String = ""
)

@JsonClass(generateAdapter = true)
internal data class StoredTaskLogDto(
    val id: String = "",
    val timestampMs: Long = 0L,
    val phase: String = "INFO",
    val message: String = "",
    val isVerified: Boolean = false,
    val isError: Boolean = false
)

class TaskHistoryRepository(private val dao: ZenoDao) {
    val taskHistory: Flow<List<TaskHistoryEntity>> = dao.observeTaskHistory()
    val promptHistory: Flow<List<PromptHistoryEntity>> = dao.observePromptHistory()

    suspend fun saveCompletedTask(memory: TaskMemory, summary: String) {
        if (memory.taskId.isBlank() || memory.originalInstruction.isBlank()) return
        val entity = TaskHistoryEntity(
            taskId = memory.taskId,
            taskName = memory.taskTitle.ifBlank {
                memory.originalInstruction.take(46).trim()
            },
            originalPrompt = memory.originalInstruction,
            targetAppName = memory.targetAppName,
            targetAppPackage = memory.targetAppPackage,
            timestampMs = memory.startTimeMs.takeIf { it > 0L } ?: System.currentTimeMillis(),
            durationMs = memory.elapsedMs,
            status = memory.status.label,
            actionsPerformed = memory.totalActionsCount,
            verifiedActions = memory.verifiedActionsCount,
            failedActions = memory.failedSteps,
            summary = summary,
            planJson = serializePlan(memory.plan),
            logsJson = serializeLogs(memory.logs.takeLast(60))
        )
        dao.insertTaskHistory(entity)
    }

    suspend fun recordPrompt(prompt: String) {
        val trimmed = prompt.trim()
        if (trimmed.isBlank()) return
        val existing = dao.findPrompt(trimmed)
        if (existing != null) {
            dao.insertPromptHistory(
                existing.copy(
                    lastUsedTimestampMs = System.currentTimeMillis(),
                    useCount = existing.useCount + 1
                )
            )
        } else {
            dao.insertPromptHistory(
                PromptHistoryEntity(
                    prompt = trimmed,
                    lastUsedTimestampMs = System.currentTimeMillis(),
                    useCount = 1
                )
            )
        }
    }

    suspend fun deleteTask(taskId: String) = dao.deleteTaskHistoryById(taskId)
    suspend fun clearAllTasks() = dao.clearTaskHistory()
    suspend fun deletePrompt(id: Long) = dao.deletePromptById(id)
    suspend fun clearPromptHistory() = dao.clearPromptHistory()

    companion object {
        private val moshi: Moshi = Moshi.Builder().build()
        private val planListAdapter = moshi.adapter<List<StoredPlanStepDto>>(
            Types.newParameterizedType(List::class.java, StoredPlanStepDto::class.java)
        )
        private val logListAdapter = moshi.adapter<List<StoredTaskLogDto>>(
            Types.newParameterizedType(List::class.java, StoredTaskLogDto::class.java)
        )

        fun serializePlan(plan: List<PlanStep>): String {
            val dtos = plan.map {
                StoredPlanStepDto(
                    id = it.id,
                    title = it.title,
                    status = it.status.name,
                    detail = it.detail
                )
            }
            return planListAdapter.toJson(dtos)
        }

        fun serializeLogs(logs: List<TaskLogEntry>): String {
            val dtos = logs.map {
                StoredTaskLogDto(
                    id = it.id,
                    timestampMs = it.timestampMs,
                    phase = it.phase,
                    message = it.message,
                    isVerified = it.isVerified,
                    isError = it.isError
                )
            }
            return logListAdapter.toJson(dtos)
        }

        fun parsePlan(planJson: String): List<PlanStep> {
            return runCatching {
                planListAdapter.fromJson(planJson).orEmpty().mapIndexed { i, dto ->
                    PlanStep(
                        id = dto.id.ifBlank { "step_$i" },
                        title = dto.title,
                        status = runCatching {
                            StepStatus.valueOf(dto.status)
                        }.getOrDefault(StepStatus.PENDING),
                        detail = dto.detail
                    )
                }
            }.getOrDefault(emptyList())
        }

        fun parseLogs(logsJson: String): List<TaskLogEntry> {
            return runCatching {
                logListAdapter.fromJson(logsJson).orEmpty().mapIndexed { i, dto ->
                    TaskLogEntry(
                        id = dto.id.ifBlank { "log_$i" },
                        timestampMs = dto.timestampMs,
                        phase = dto.phase.ifBlank { "INFO" },
                        message = dto.message,
                        isVerified = dto.isVerified,
                        isError = dto.isError
                    )
                }
            }.getOrDefault(emptyList())
        }
    }
}
