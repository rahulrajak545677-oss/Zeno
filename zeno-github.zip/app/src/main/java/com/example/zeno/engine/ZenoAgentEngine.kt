package com.example.zeno.engine

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.zeno.ai.ZenoAiRouter
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.core.model.ActionType
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.ScreenAnalysisReport
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.StepStatus
import com.example.zeno.core.model.TaskLogEntry
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.ZenoAction
import com.example.zeno.core.model.ZenoState
import com.example.zeno.data.local.TaskHistoryRepository
import com.example.zeno.data.local.ZenoDatabase
import com.example.zeno.data.local.ZenoPreferencesRepository
import com.example.zeno.data.local.ZenoSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

private const val TAG = "ZenoAgentEngine"
private const val MAX_STEPS_PER_TASK = 24

class ZenoAgentEngine private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefsRepo = ZenoPreferencesRepository(appContext)
    private val historyRepo = TaskHistoryRepository(ZenoDatabase.getInstance(appContext).zenoDao())
    private val aiRouter = ZenoAiRouter(prefsRepo)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _taskMemory = MutableStateFlow(TaskMemory())
    val taskMemory: StateFlow<TaskMemory> = _taskMemory.asStateFlow()

    private var executionJob: Job? = null
    private var timerJob: Job? = null
    private var isPausedFlag = false
    private var isConsequentialApproved = false

    fun setInstructionDraft(instruction: String) {
        scope.launch {
            prefsRepo.updateSavedInstruction(instruction)
        }
        _taskMemory.update {
            if (!it.status.isRunning && it.status != ZenoState.PAUSED) {
                it.copy(
                    originalInstruction = instruction,
                    taskTitle = deriveTaskTitle(instruction),
                    status = if (ZenoSystemBridge.isAccessibilityConnected.value) ZenoState.READY else ZenoState.OFFLINE
                )
            } else {
                it.copy(originalInstruction = instruction, taskTitle = deriveTaskTitle(instruction))
            }
        }
    }

    fun startTask(instructionInput: String? = null) {
        val instruction = (instructionInput ?: _taskMemory.value.originalInstruction).trim()
        if (instruction.isBlank()) {
            appendLog("SYSTEM", "Enter an instruction before starting ZENO.", isError = true)
            _taskMemory.update { it.copy(status = ZenoState.ERROR, currentOperation = "No instruction provided") }
            return
        }

        val a11yService = ZenoSystemBridge.getAccessibilityService()
        if (a11yService == null) {
            appendLog("PERMISSION", "Accessibility Service is not active. Enable ZENO Vision in Android Accessibility Settings.", isError = true)
            _taskMemory.update {
                it.copy(
                    originalInstruction = instruction,
                    taskTitle = deriveTaskTitle(instruction),
                    status = ZenoState.OFFLINE,
                    currentOperation = "Accessibility Service required"
                )
            }
            return
        }

        executionJob?.cancel()
        timerJob?.cancel()
        isPausedFlag = false
        isConsequentialApproved = false

        val taskId = UUID.randomUUID().toString().take(12)
        val startedAt = System.currentTimeMillis()

        _taskMemory.value = TaskMemory(
            taskId = taskId,
            taskTitle = deriveTaskTitle(instruction),
            originalInstruction = instruction,
            status = ZenoState.OBSERVING,
            currentOperation = "Reading instruction and observing screen",
            startTimeMs = startedAt,
            elapsedMs = 0L,
            logs = listOf(
                TaskLogEntry(
                    id = UUID.randomUUID().toString().take(8),
                    timestampMs = startedAt,
                    phase = "INIT",
                    message = "Task initialized: \"$instruction\""
                )
            )
        )

        scope.launch {
            prefsRepo.updateSavedInstruction(instruction)
            historyRepo.recordPrompt(instruction)
        }

        startElapsedTimer(startedAt)
        executionJob = scope.launch {
            runPerceptionActionLoop()
        }
    }

    fun pauseTask(reason: String = "Paused by user") {
        if (!_taskMemory.value.status.isRunning) return
        isPausedFlag = true
        executionJob?.cancel()
        timerJob?.cancel()
        appendLog("CONTROL", reason)
        _taskMemory.update {
            it.copy(
                status = ZenoState.PAUSED,
                currentOperation = reason
            )
        }
    }

    fun resumeTask() {
        val current = _taskMemory.value
        if (current.status != ZenoState.PAUSED && current.status != ZenoState.ERROR) return
        val a11yService = ZenoSystemBridge.getAccessibilityService()
        if (a11yService == null) {
            appendLog("PERMISSION", "Cannot resume: Accessibility Service is disconnected.", isError = true)
            _taskMemory.update { it.copy(status = ZenoState.OFFLINE, currentOperation = "Accessibility disconnected") }
            return
        }
        isPausedFlag = false
        appendLog("CONTROL", "Resuming: re-observing current screen before acting")
        _taskMemory.update {
            it.copy(
                status = ZenoState.OBSERVING,
                currentOperation = "Re-observing screen after pause",
                pendingConfirmationReason = null
            )
        }
        startElapsedTimer(current.startTimeMs)
        executionJob = scope.launch {
            runPerceptionActionLoop(isResume = true)
        }
    }

    fun confirmPendingConsequentialAction() {
        val pending = _taskMemory.value.pendingAction ?: return
        isConsequentialApproved = true
        appendLog("SAFETY", "User confirmed consequential action: ${pending.reason}", isVerified = true)
        _taskMemory.update {
            it.copy(
                pendingConfirmationReason = null,
                status = ZenoState.EXECUTING,
                currentOperation = "Executing confirmed action"
            )
        }
        resumeTask()
    }

    fun cancelPendingConsequentialAction() {
        appendLog("SAFETY", "User declined consequential action. Task paused.", isError = false)
        _taskMemory.update {
            it.copy(
                pendingAction = null,
                pendingConfirmationReason = null,
                status = ZenoState.PAUSED,
                currentOperation = "Action declined by user"
            )
        }
    }

    fun updateInstructionLive(newInstruction: String) {
        val trimmed = newInstruction.trim()
        if (trimmed.isBlank()) return
        scope.launch {
            prefsRepo.updateSavedInstruction(trimmed)
            historyRepo.recordPrompt(trimmed)
        }
        appendLog("EDIT", "Instruction updated: \"$trimmed\"")
        _taskMemory.update {
            it.copy(
                originalInstruction = trimmed,
                taskTitle = deriveTaskTitle(trimmed)
            )
        }
    }

    fun restartTask() {
        val instruction = _taskMemory.value.originalInstruction
        if (instruction.isBlank()) return
        stopTask(saveToHistory = false)
        startTask(instruction)
    }

    fun stopTask(saveToHistory: Boolean = true) {
        isPausedFlag = true
        executionJob?.cancel()
        timerJob?.cancel()
        val current = _taskMemory.value
        val canStop = current.taskId.isNotBlank() && (
            current.status.isRunning ||
                current.status == ZenoState.PAUSED ||
                current.status == ZenoState.ERROR ||
                current.status == ZenoState.FAILED
            )
        if (canStop) {
            appendLog("CONTROL", "Task stopped by user.")
            _taskMemory.update {
                it.copy(
                    status = ZenoState.CANCELLED,
                    currentOperation = "Stopped by user",
                    pendingAction = null,
                    pendingConfirmationReason = null
                )
            }
            if (saveToHistory) {
                scope.launch {
                    historyRepo.saveCompletedTask(_taskMemory.value, "Task stopped by user.")
                }
            }
        }
    }

    suspend fun analyzeCurrentScreenOnce(): Result<ScreenAnalysisReport> {
        val a11yService = ZenoSystemBridge.getAccessibilityService()
            ?: return Result.failure(IllegalStateException("Accessibility Service is not enabled."))
        val observation = a11yService.captureCurrentScreenObservation()
        val screenshot = a11yService.captureScreenshotOnDemand()
        return aiRouter.analyzeScreen(observation, screenshot)
    }

    suspend fun previewNeuralPlan(instruction: String): Result<List<PlanStep>> {
        if (instruction.isBlank()) {
            return Result.failure(IllegalArgumentException("Enter an instruction to preview Neural Plan."))
        }
        val obs = ZenoSystemBridge.getAccessibilityService()?.captureCurrentScreenObservation()
        return aiRouter.createNeuralPlan(instruction.trim(), obs)
    }

    suspend fun testAiConnection(): Result<String> = aiRouter.testConnection()

    private fun startElapsedTimer(startTimeMs: Long) {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive) {
                delay(500L)
                _taskMemory.update { mem ->
                    if (mem.status.isRunning) {
                        mem.copy(elapsedMs = (System.currentTimeMillis() - startTimeMs).coerceAtLeast(0L))
                    } else mem
                }
            }
        }
    }

    private suspend fun runPerceptionActionLoop(isResume: Boolean = false) {
        try {
            val a11yService = ZenoSystemBridge.getAccessibilityService()
                ?: throw IllegalStateException("Accessibility Service disconnected.")
            val settings = prefsRepo.settingsFlow.first()

            // Step 1: Observe current screen
            _taskMemory.update {
                it.copy(status = ZenoState.OBSERVING, currentOperation = "Capturing current screen UI tree")
            }
            var observation = a11yService.captureFreshObservationWithRetry()
            var screenshot: Bitmap? = if (!observation.hasAccessibilityData || settings.screenAwarenessEnabled) {
                if (!observation.hasAccessibilityData) a11yService.captureScreenshotOnDemand() else null
            } else null

            _taskMemory.update {
                it.copy(
                    targetAppPackage = observation.packageName,
                    targetAppName = observation.appName,
                    currentScreenSummary = observation.summaryText
                )
            }
            appendLog("VISION", "Observed ${observation.appName} (${observation.nodes.size} nodes)")

            // Step 2: Neural Plan (only if no plan yet or replanning)
            if (!isResume || _taskMemory.value.plan.isEmpty()) {
                _taskMemory.update {
                    it.copy(status = ZenoState.PLANNING, currentOperation = "Generating Neural Plan")
                }
                val planResult = aiRouter.createNeuralPlan(
                    instruction = _taskMemory.value.originalInstruction,
                    observation = observation
                )
                val steps = planResult.getOrElse { err ->
                    throw IllegalStateException("Neural Plan error: ${err.localizedMessage ?: "Failed"}")
                }
                _taskMemory.update { it.copy(plan = steps) }
                appendLog("PLAN", "Neural Plan ready (${steps.size} steps)")
            }

            // Step 3: Perception -> Thinking -> Safety Gate -> Execution -> Self-Check loop
            var iterations = 0
            var expectedForegroundPkg = observation.packageName
            while (!isPausedFlag && iterations < MAX_STEPS_PER_TASK) {
                iterations++
                val currentSettings = prefsRepo.settingsFlow.first()
                val activeService = ZenoSystemBridge.getAccessibilityService()
                    ?: throw IllegalStateException("Accessibility Service lost during execution.")

                // Re-observe fresh screen
                _taskMemory.update {
                    it.copy(status = ZenoState.OBSERVING, currentOperation = "Analyzing current screen")
                }
                observation = activeService.captureFreshObservationWithRetry()

                // Safety: Never bypass security/authentication screens
                val authWarning = ZenoSafetyGuard.detectSecurityOrAuthScreen(observation)
                if (authWarning != null) {
                    appendLog("SAFETY", authWarning, isError = false)
                    pauseTask(authWarning)
                    return
                }

                // Safety: Pause on unexpected app switches when enabled
                if (iterations > 1 &&
                    currentSettings.pauseOnUnexpectedScreen &&
                    ZenoSafetyGuard.isUnexpectedAppSwitch(
                        previousPackage = expectedForegroundPkg,
                        currentPackage = observation.packageName,
                        lastAction = _taskMemory.value.lastAction
                    )
                ) {
                    val switchMsg = "Paused: screen switched unexpectedly to ${observation.appName}."
                    appendLog("SAFETY", switchMsg)
                    pauseTask(switchMsg)
                    return
                }
                if (observation.packageName.isNotBlank()) {
                    expectedForegroundPkg = observation.packageName
                }

                screenshot = if (!observation.hasAccessibilityData || currentSettings.screenAwarenessEnabled) {
                    if (!observation.hasAccessibilityData || iterations == 1) {
                        activeService.captureScreenshotOnDemand()
                    } else null
                } else null

                _taskMemory.update {
                    it.copy(
                        targetAppPackage = observation.packageName,
                        targetAppName = observation.appName,
                        currentScreenSummary = observation.summaryText
                    )
                }

                // If pending action was just confirmed by user, execute it directly
                val confirmedAction = _taskMemory.value.pendingAction?.takeIf { isConsequentialApproved }
                val decisionResult = if (confirmedAction != null) {
                    isConsequentialApproved = false
                    _taskMemory.update { it.copy(pendingAction = null) }
                    com.example.zeno.core.model.AiDecisionResult(
                        isTaskComplete = false,
                        completionSummary = "",
                        activeStepIndex = _taskMemory.value.completedSteps,
                        needsUserInput = false,
                        userPromptReason = "",
                        nextAction = confirmedAction
                    )
                } else {
                    _taskMemory.update {
                        it.copy(status = ZenoState.THINKING, currentOperation = "ZENO Core deciding next action")
                    }
                    aiRouter.decideNextAction(
                        memory = _taskMemory.value,
                        observation = observation,
                        screenshot = screenshot
                    ).getOrElse { err ->
                        throw IllegalStateException("ZENO Core error: ${err.localizedMessage ?: "AI call failed"}")
                    }
                }

                // Update active step indicator
                markActiveStep(decisionResult.activeStepIndex)

                if (decisionResult.isTaskComplete) {
                    val summary = decisionResult.completionSummary.ifBlank {
                        "Task completed in ${observation.appName}."
                    }
                    markAllRemainingStepsVerified()
                    appendLog("COMPLETE", summary, isVerified = true)
                    _taskMemory.update {
                        it.copy(
                            status = ZenoState.COMPLETED,
                            currentOperation = summary,
                            lastVerification = "Goal verified complete"
                        )
                    }
                    timerJob?.cancel()
                    historyRepo.saveCompletedTask(_taskMemory.value, summary)
                    return
                }

                if (decisionResult.needsUserInput || decisionResult.nextAction == null) {
                    val reason = decisionResult.userPromptReason.ifBlank {
                        "Controls on this screen require user assistance."
                    }
                    appendLog("ASSIST", reason)
                    pauseTask(reason)
                    return
                }

                val action = ZenoSafetyGuard.evaluateConsequentialAction(
                    action = decisionResult.nextAction,
                    observation = observation
                )

                // Safety check for consequential actions or AutoPilot disabled
                if ((action.isConsequential && currentSettings.confirmConsequentialActions) ||
                    !currentSettings.autoPilotEnabled
                ) {
                    val gateReason = if (action.isConsequential) {
                        "Confirm consequential action: ${action.reason}"
                    } else {
                        "AutoPilot off — confirm step: ${action.reason}"
                    }
                    appendLog("SAFETY", gateReason)
                    _taskMemory.update {
                        it.copy(
                            pendingAction = action,
                            pendingConfirmationReason = gateReason,
                            status = ZenoState.PAUSED,
                            currentOperation = "Waiting for user confirmation"
                        )
                    }
                    timerJob?.cancel()
                    return
                }

                // Execute action
                _taskMemory.update {
                    it.copy(
                        status = ZenoState.EXECUTING,
                        currentOperation = action.reason,
                        lastAction = action,
                        totalActionsCount = it.totalActionsCount + 1
                    )
                }
                appendLog("ACTION", "${action.type.wireName}: ${action.reason}")

                val beforeObs = observation
                val execOutcome = activeService.executeAction(action, beforeObs)

                if (!execOutcome.success) {
                    handleStepFailure(
                        reason = execOutcome.detail,
                        settings = currentSettings
                    )
                    if (_taskMemory.value.status == ZenoState.PAUSED || _taskMemory.value.status == ZenoState.FAILED) {
                        return
                    }
                    continue
                }

                // Wait for UI response
                _taskMemory.update {
                    it.copy(status = ZenoState.WAITING, currentOperation = "Waiting for UI response")
                }
                delay(currentSettings.actionDelayMs.toLong())

                // Self-Check Verification
                if (currentSettings.verificationEnabled &&
                    action.type != ActionType.WAIT &&
                    action.type != ActionType.OBSERVE
                ) {
                    _taskMemory.update {
                        it.copy(status = ZenoState.VERIFYING, currentOperation = "Self-Check verifying outcome")
                    }
                    val afterObs = activeService.captureFreshObservationWithRetry()
                    val afterShot = if (!afterObs.hasAccessibilityData) {
                        activeService.captureScreenshotOnDemand()
                    } else null

                    val verifyRes = aiRouter.verifyActionOutcome(
                        action = action,
                        before = beforeObs,
                        after = afterObs,
                        screenshot = afterShot
                    ).getOrElse { err ->
                        Log.w(TAG, "Self-Check AI error, using structural diff: ${err.message}")
                        com.example.zeno.core.model.VerificationResult(
                            verified = false,
                            confidenceSummary = "Verification error: ${err.localizedMessage}",
                            uiChanged = afterObs.summaryText != beforeObs.summaryText,
                            shouldReplan = false
                        )
                    }

                    if (verifyRes.verified) {
                        appendLog("VERIFY", "✓ ${verifyRes.confidenceSummary}", isVerified = true)
                        _taskMemory.update {
                            it.copy(
                                verifiedActionsCount = it.verifiedActionsCount + 1,
                                lastVerification = verifyRes.confidenceSummary,
                                retryCount = 0
                            )
                        }
                        markStepVerified(decisionResult.activeStepIndex)
                    } else {
                        appendLog("VERIFY", "Not verified: ${verifyRes.confidenceSummary}", isError = true)
                        _taskMemory.update {
                            it.copy(lastVerification = "Unverified: ${verifyRes.confidenceSummary}")
                        }
                        if (verifyRes.shouldReplan && currentSettings.pauseOnUnexpectedScreen) {
                            pauseTask("Unexpected screen change: ${verifyRes.confidenceSummary}")
                            return
                        }
                        handleStepFailure(verifyRes.confidenceSummary, currentSettings)
                        if (_taskMemory.value.status == ZenoState.PAUSED || _taskMemory.value.status == ZenoState.FAILED) {
                            return
                        }
                    }
                } else {
                    appendLog("ACTION", execOutcome.detail)
                }
            }

            // Reached max steps safety limit
            val summary = "Reached step budget ($MAX_STEPS_PER_TASK actions). Please review screen and resume if needed."
            appendLog("LIMIT", summary)
            _taskMemory.update {
                it.copy(status = ZenoState.PAUSED, currentOperation = summary)
            }
            timerJob?.cancel()
            historyRepo.saveCompletedTask(_taskMemory.value, summary)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Execution loop failed", e)
            val msg = e.localizedMessage ?: "Automation loop encountered an error."
            appendLog("ERROR", msg, isError = true)
            _taskMemory.update {
                it.copy(status = ZenoState.ERROR, currentOperation = msg)
            }
            timerJob?.cancel()
            historyRepo.saveCompletedTask(_taskMemory.value, msg)
        }
    }

    private fun handleStepFailure(reason: String, settings: ZenoSettings) {
        val nextRetry = _taskMemory.value.retryCount + 1
        if (nextRetry > settings.maxRetries) {
            val pauseMsg = "Paused after $nextRetry retries: $reason"
            appendLog("RETRY", pauseMsg, isError = true)
            _taskMemory.update {
                it.copy(
                    failedSteps = it.failedSteps + 1,
                    retryCount = nextRetry,
                    status = ZenoState.PAUSED,
                    currentOperation = pauseMsg
                )
            }
            timerJob?.cancel()
        } else {
            appendLog("RETRY", "Attempt $nextRetry/${settings.maxRetries} failed ($reason) — re-analyzing screen")
            _taskMemory.update {
                it.copy(
                    failedSteps = it.failedSteps + 1,
                    retryCount = nextRetry
                )
            }
        }
    }

    private fun markActiveStep(index: Int) {
        _taskMemory.update { mem ->
            if (mem.plan.isEmpty()) return@update mem
            val clamped = index.coerceIn(0, mem.plan.lastIndex)
            val updated = mem.plan.mapIndexed { idx, step ->
                when {
                    idx < clamped && step.status == StepStatus.IN_PROGRESS -> step.copy(status = StepStatus.VERIFIED)
                    idx == clamped && step.status == StepStatus.PENDING -> step.copy(status = StepStatus.IN_PROGRESS)
                    else -> step
                }
            }
            mem.copy(
                plan = updated,
                completedSteps = updated.count { it.status == StepStatus.VERIFIED }
            )
        }
    }

    private fun markStepVerified(index: Int) {
        _taskMemory.update { mem ->
            if (mem.plan.isEmpty()) return@update mem
            val clamped = index.coerceIn(0, mem.plan.lastIndex)
            val updated = mem.plan.mapIndexed { idx, step ->
                if (idx == clamped) step.copy(status = StepStatus.VERIFIED) else step
            }
            mem.copy(
                plan = updated,
                completedSteps = updated.count { it.status == StepStatus.VERIFIED }
            )
        }
    }

    private fun markAllRemainingStepsVerified() {
        _taskMemory.update { mem ->
            val updated = mem.plan.map { step ->
                if (step.status == StepStatus.PENDING || step.status == StepStatus.IN_PROGRESS) {
                    step.copy(status = StepStatus.VERIFIED)
                } else step
            }
            mem.copy(plan = updated, completedSteps = updated.size)
        }
    }

    private fun appendLog(
        phase: String,
        message: String,
        isVerified: Boolean = false,
        isError: Boolean = false
    ) {
        val entry = TaskLogEntry(
            id = UUID.randomUUID().toString().take(8),
            timestampMs = System.currentTimeMillis(),
            phase = phase,
            message = message,
            isVerified = isVerified,
            isError = isError
        )
        _taskMemory.update { mem ->
            mem.copy(logs = (mem.logs + entry).takeLast(80))
        }
    }

    private fun deriveTaskTitle(instruction: String): String {
        val clean = instruction.trim().replace("\n", " ")
        return if (clean.length <= 42) clean else clean.take(39) + "..."
    }

    companion object {
        @Volatile
        private var instance: ZenoAgentEngine? = null

        fun getInstance(context: Context): ZenoAgentEngine {
            return instance ?: synchronized(this) {
                instance ?: ZenoAgentEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
