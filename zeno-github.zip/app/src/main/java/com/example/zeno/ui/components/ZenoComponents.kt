package com.example.zeno.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ZenoBgPrimary
import com.example.ui.theme.ZenoBorder
import com.example.ui.theme.ZenoCardBg
import com.example.ui.theme.ZenoElevatedBg
import com.example.ui.theme.ZenoError
import com.example.ui.theme.ZenoSuccess
import com.example.ui.theme.ZenoTextPrimary
import com.example.ui.theme.ZenoTextSecondary
import com.example.ui.theme.ZenoWarning
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.StepStatus
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.ZenoState

@Composable
fun ZenoCard(
    modifier: Modifier = Modifier,
    elevated: Boolean = false,
    borderColor: Color = ZenoBorder,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = if (elevated) ZenoElevatedBg else ZenoCardBg,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun ZenoStatusPill(
    state: ZenoState,
    modifier: Modifier = Modifier
) {
    val dotColor by animateColorAsState(
        targetValue = when (state) {
            ZenoState.READY, ZenoState.COMPLETED -> ZenoSuccess
            ZenoState.OBSERVING, ZenoState.THINKING, ZenoState.PLANNING,
            ZenoState.EXECUTING, ZenoState.VERIFYING, ZenoState.WAITING, ZenoState.WORKING ->
                MaterialTheme.colorScheme.primary
            ZenoState.PAUSED, ZenoState.LISTENING -> ZenoWarning
            ZenoState.ERROR, ZenoState.FAILED, ZenoState.OFFLINE -> ZenoError
            ZenoState.IDLE, ZenoState.CANCELLED -> ZenoTextSecondary
        },
        label = "status_dot"
    )
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = dotColor.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, dotColor.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = state.label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = dotColor,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun PlanStepRow(
    step: PlanStep,
    modifier: Modifier = Modifier
) {
    val (icon, tint) = when (step.status) {
        StepStatus.VERIFIED -> Icons.Rounded.CheckCircle to ZenoSuccess
        StepStatus.IN_PROGRESS -> Icons.Rounded.PlayArrow to MaterialTheme.colorScheme.primary
        StepStatus.FAILED -> Icons.Rounded.ErrorOutline to ZenoError
        StepStatus.SKIPPED -> Icons.Rounded.RadioButtonUnchecked to ZenoTextSecondary.copy(alpha = 0.5f)
        StepStatus.PENDING -> Icons.Rounded.RadioButtonUnchecked to ZenoTextSecondary
    }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = step.status.name,
            tint = tint,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = step.title,
            style = MaterialTheme.typography.bodyMedium,
            color = if (step.status == StepStatus.PENDING) ZenoTextSecondary else ZenoTextPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun LiveTaskMonitorCard(
    memory: TaskMemory,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onRestart: () -> Unit,
    onConfirmConsequential: () -> Unit,
    onCancelConsequential: () -> Unit,
    modifier: Modifier = Modifier
) {
    ZenoCard(
        modifier = modifier.fillMaxWidth(),
        elevated = true,
        borderColor = if (memory.status.isRunning) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
        } else {
            ZenoBorder
        }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "ZENO AUTOPILOT",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = memory.taskTitle.ifBlank { "Active Session" },
                    style = MaterialTheme.typography.titleMedium,
                    color = ZenoTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            ZenoStatusPill(state = memory.status)
        }

        Spacer(modifier = Modifier.size(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "App: ${memory.targetAppName}",
                style = MaterialTheme.typography.bodySmall,
                color = ZenoTextSecondary
            )
            Text(
                text = "${memory.verifiedActionsCount}/${memory.totalActionsCount} verified • ${formatElapsed(memory.elapsedMs)}",
                style = MaterialTheme.typography.labelSmall,
                color = ZenoTextSecondary
            )
        }

        Spacer(modifier = Modifier.size(6.dp))

        Text(
            text = memory.currentOperation,
            style = MaterialTheme.typography.bodyMedium,
            color = ZenoTextPrimary
        )

        if (memory.pendingConfirmationReason != null) {
            Spacer(modifier = Modifier.size(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.small)
                    .background(ZenoWarning.copy(alpha = 0.12f))
                    .border(1.dp, ZenoWarning.copy(alpha = 0.5f), MaterialTheme.shapes.small)
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "CONFIRMATION REQUIRED",
                        style = MaterialTheme.typography.labelMedium,
                        color = ZenoWarning
                    )
                    Spacer(modifier = Modifier.size(4.dp))
                    Text(
                        text = memory.pendingConfirmationReason,
                        style = MaterialTheme.typography.bodySmall,
                        color = ZenoTextPrimary
                    )
                    Spacer(modifier = Modifier.size(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onConfirmConsequential,
                            modifier = Modifier.testTag("confirm_consequential_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ZenoWarning,
                                contentColor = ZenoBgPrimary
                            )
                        ) {
                            Text("Confirm", style = MaterialTheme.typography.labelLarge)
                        }
                        OutlinedButton(
                            onClick = onCancelConsequential,
                            modifier = Modifier.testTag("decline_consequential_btn")
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }

        if (memory.plan.isNotEmpty()) {
            Spacer(modifier = Modifier.size(10.dp))
            memory.plan.forEach { step ->
                PlanStepRow(step = step)
            }
        }

        Spacer(modifier = Modifier.size(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when {
                memory.status.isRunning -> {
                    Button(
                        onClick = onPause,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("monitor_pause_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ZenoWarning,
                            contentColor = ZenoBgPrimary
                        )
                    ) {
                        Icon(Icons.Rounded.PauseCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("PAUSE")
                    }
                    OutlinedButton(
                        onClick = onStop,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("monitor_stop_btn")
                    ) {
                        Icon(Icons.Rounded.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("STOP")
                    }
                }
                memory.status == ZenoState.PAUSED -> {
                    Button(
                        onClick = onResume,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("monitor_resume_btn")
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("RESUME")
                    }
                    OutlinedButton(
                        onClick = onStop,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("monitor_stop_btn")
                    ) {
                        Icon(Icons.Rounded.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("STOP")
                    }
                }
                else -> {
                    Button(
                        onClick = onStart,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("monitor_start_btn")
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("START")
                    }
                    OutlinedButton(
                        onClick = onRestart,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("monitor_restart_btn")
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("RESTART")
                    }
                }
            }
        }
    }
}

fun formatElapsed(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return "${min}m ${sec.toString().padStart(2, '0')}s"
}
