package com.example.zeno.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.example.zeno.core.ZenoSystemBridge
import com.example.zeno.engine.ZenoAgentEngine

class OrbVoiceInputActivity : ComponentActivity() {

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val transcript = matches?.firstOrNull()?.trim().orEmpty()
            if (transcript.isNotBlank()) {
                ZenoSystemBridge.postVoiceTranscript(transcript)
                if (intent.getBooleanExtra(EXTRA_APPLY_TO_ENGINE, false)) {
                    ZenoAgentEngine.getInstance(this).updateInstructionLive(transcript)
                }
            }
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell ZENO what you want done...")
        }
        runCatching {
            speechLauncher.launch(speechIntent)
        }.onFailure {
            android.widget.Toast.makeText(
                this,
                "Speech recognition service is unavailable on this device.",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            finish()
        }
    }

    companion object {
        private const val EXTRA_APPLY_TO_ENGINE = "apply_to_engine"

        fun launch(context: Context, applyToEngine: Boolean) {
            val intent = Intent(context, OrbVoiceInputActivity::class.java).apply {
                putExtra(EXTRA_APPLY_TO_ENGINE, applyToEngine)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
