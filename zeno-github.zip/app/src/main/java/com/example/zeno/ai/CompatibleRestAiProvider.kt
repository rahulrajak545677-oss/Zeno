package com.example.zeno.ai

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.zeno.core.model.ActionType
import com.example.zeno.core.model.AiDecisionResult
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.ScreenAnalysisReport
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.StepStatus
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.VerificationResult
import com.example.zeno.core.model.ZenoAction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit

private const val TAG = "CompatibleRestProvider"

class CompatibleRestAiProvider(
    private val endpointProvider: () -> String,
    private val apiKeyProvider: () -> String,
    private val modelIdProvider: () -> String
) : ZenoAiProvider {

    override val providerName: String = "Compatible REST Provider"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(55, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    override suspend fun testConnection(modelName: String): Result<String> {
        return callChatCompletion(
            systemPrompt = "Respond concisely.",
            userText = "Reply with 'Compatible AI endpoint connected' and nothing else.",
            screenshot = null,
            expectJson = false
        ).map { "${it.trim()} (${modelIdProvider().ifBlank { modelName }})" }
    }

    override suspend fun interpretInstruction(
        instruction: String,
        observation: ScreenObservation?,
        modelName: String
    ): Result<List<PlanStep>> {
        val sys = """Return valid JSON only: {"steps":[{"title":"...","detail":"..."}]}"""
        val usr = buildString {
            appendLine("Create 4 to 7 adaptive Android automation steps for: $instruction")
            if (observation != null) {
                appendLine("Current app: ${observation.appName} (${observation.packageName})")
                appendLine("Summary: ${observation.summaryText}")
            }
        }
        return callChatCompletion(sys, usr, null, expectJson = true).mapCatching { raw ->
            val obj = JSONObject(extractJsonObject(raw))
            val arr = obj.getJSONArray("steps")
            (0 until arr.length()).map { i ->
                val item = arr.getJSONObject(i)
                PlanStep(
                    id = "step_${i + 1}",
                    title = item.optString("title", "Step ${i + 1}"),
                    status = StepStatus.PENDING,
                    detail = item.optString("detail", "")
                )
            }.ifEmpty { throw IllegalStateException("Empty plan steps") }
        }
    }

    override suspend fun decideNextAction(
        memory: TaskMemory,
        observation: ScreenObservation,
        screenshot: Bitmap?,
        textModel: String,
        visionModel: String
    ): Result<AiDecisionResult> {
        val sys = """Return valid JSON only matching {"isTaskComplete":bool,"completionSummary":str,"activeStepIndex":int,"needsUserInput":bool,"userPromptReason":str,"action":{"actionType":str,"targetNodeId":str,"targetLabel":str,"x":int|null,"y":int|null,"inputText":str,"packageName":str,"scrollDirection":str,"reason":str,"expectedOutcome":str,"isConsequential":bool}}"""
        val usr = buildString {
            appendLine("Goal: ${memory.originalInstruction}")
            appendLine("App: ${observation.appName} (${observation.packageName}) ${observation.screenWidth}x${observation.screenHeight}")
            appendLine("Nodes:")
            observation.nodes.take(60).forEach { n ->
                appendLine("${n.nodeId} | \"${n.primaryLabel()}\" | ${n.bounds.toShortString()} | click=${n.isClickable} edit=${n.isEditable} scroll=${n.isScrollable}")
            }
        }
        return callChatCompletion(sys, usr, screenshot, expectJson = true).mapCatching { raw ->
            val json = JSONObject(extractJsonObject(raw))
            val isComplete = json.optBoolean("isTaskComplete", false)
            val needsUser = json.optBoolean("needsUserInput", false)
            val action = if (!isComplete && !needsUser && json.has("action") && !json.isNull("action")) {
                val a = json.getJSONObject("action")
                ZenoAction(
                    actionId = UUID.randomUUID().toString().take(8),
                    type = ActionType.fromWireName(a.optString("actionType", "tap")),
                    targetNodeId = a.optString("targetNodeId", ""),
                    targetLabel = a.optString("targetLabel", ""),
                    x = if (a.has("x") && !a.isNull("x")) a.optInt("x") else null,
                    y = if (a.has("y") && !a.isNull("y")) a.optInt("y") else null,
                    inputText = a.optString("inputText", ""),
                    packageName = a.optString("packageName", ""),
                    scrollDirection = a.optString("scrollDirection", "forward"),
                    reason = a.optString("reason", "Progress task"),
                    expectedOutcome = a.optString("expectedOutcome", "UI updates"),
                    isConsequential = a.optBoolean("isConsequential", false)
                )
            } else null

            AiDecisionResult(
                isTaskComplete = isComplete,
                completionSummary = json.optString("completionSummary", ""),
                activeStepIndex = json.optInt("activeStepIndex", 0),
                needsUserInput = needsUser,
                userPromptReason = json.optString("userPromptReason", ""),
                nextAction = action
            )
        }
    }

    override suspend fun verifyActionOutcome(
        action: ZenoAction,
        before: ScreenObservation,
        after: ScreenObservation,
        screenshot: Bitmap?,
        modelName: String
    ): Result<VerificationResult> {
        val sys = """Return valid JSON only: {"verified":bool,"confidenceSummary":str,"uiChanged":bool,"shouldReplan":bool}"""
        val usr = "Action: ${action.type.wireName} ${action.targetLabel}. Expected: ${action.expectedOutcome}. Before: ${before.summaryText}. After: ${after.summaryText}"
        return callChatCompletion(sys, usr, screenshot, expectJson = true).mapCatching { raw ->
            val json = JSONObject(extractJsonObject(raw))
            VerificationResult(
                verified = json.optBoolean("verified", false),
                confidenceSummary = json.optString("confidenceSummary", "Checked state"),
                uiChanged = json.optBoolean("uiChanged", false),
                shouldReplan = json.optBoolean("shouldReplan", false)
            )
        }
    }

    override suspend fun analyzeScreen(
        observation: ScreenObservation,
        screenshot: Bitmap?,
        modelName: String
    ): Result<ScreenAnalysisReport> {
        val sys = """Return valid JSON only: {"appName":str,"screenPurpose":str,"keyControls":[str],"accessibilityLimitation":str}"""
        val usr = "Analyze app=${observation.appName} (${observation.packageName}), nodes=${observation.summaryText}"
        return callChatCompletion(sys, usr, screenshot, expectJson = true).mapCatching { raw ->
            val json = JSONObject(extractJsonObject(raw))
            val arr = json.optJSONArray("keyControls") ?: JSONArray()
            ScreenAnalysisReport(
                appName = json.optString("appName", observation.appName),
                screenPurpose = json.optString("screenPurpose", ""),
                keyControls = (0 until arr.length()).map { arr.getString(it) },
                accessibilityLimitation = json.optString("accessibilityLimitation", "").ifBlank { null }
            )
        }
    }

    private suspend fun callChatCompletion(
        systemPrompt: String,
        userText: String,
        screenshot: Bitmap?,
        expectJson: Boolean
    ): Result<String> {
        val endpoint = endpointProvider().trim()
        val apiKey = apiKeyProvider().trim()
        val modelId = modelIdProvider().trim()
        if (endpoint.isBlank() || apiKey.isBlank() || modelId.isBlank()) {
            return Result.failure(
                IllegalStateException("Compatible provider requires endpoint URL, API key, and model ID in Settings.")
            )
        }
        return try {
            withTimeout(60_000L) {
                withContext(Dispatchers.IO) {
                    val userContent: Any = if (screenshot != null) {
                        val b64 = encodeBitmapJpegBase64(screenshot)
                        JSONArray().apply {
                            put(JSONObject().apply {
                                put("type", "text")
                                put("text", userText)
                            })
                            put(JSONObject().apply {
                                put("type", "image_url")
                                put("image_url", JSONObject().apply {
                                    put("url", "data:image/jpeg;base64,$b64")
                                })
                            })
                        }
                    } else {
                        userText
                    }

                    val bodyJson = JSONObject().apply {
                        put("model", modelId)
                        put("messages", JSONArray().apply {
                            put(JSONObject().apply {
                                put("role", "system")
                                put("content", systemPrompt)
                            })
                            put(JSONObject().apply {
                                put("role", "user")
                                put("content", userContent)
                            })
                        })
                        if (expectJson) {
                            put("response_format", JSONObject().apply { put("type", "json_object") })
                        }
                    }

                    val req = Request.Builder()
                        .url(endpoint)
                        .addHeader("Authorization", "Bearer $apiKey")
                        .addHeader("Content-Type", "application/json")
                        .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
                        .build()

                    client.newCall(req).execute().use { resp ->
                        val respBody = resp.body?.string().orEmpty()
                        if (!resp.isSuccessful) {
                            throw IllegalStateException("HTTP ${resp.code}: ${respBody.take(240)}")
                        }
                        val root = JSONObject(respBody)
                        val content = root.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                        Result.success(content)
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Compatible REST call failed", e)
            Result.failure(e)
        }
    }

    private fun encodeBitmapJpegBase64(bitmap: Bitmap): String {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 78, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    private fun extractJsonObject(raw: String): String {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        return if (start >= 0 && end > start) raw.substring(start, end + 1) else raw
    }
}
