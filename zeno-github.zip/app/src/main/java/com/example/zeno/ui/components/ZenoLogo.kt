package com.example.zeno.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ZenoTextPrimary

/**
 * Original ZENO emblem combining an angled orbit ring, a four-point spark,
 * and a forward-moving precision chevron.
 */
@Composable
fun ZenoLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    chevronColor: Color = ZenoTextPrimary
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cx = w * 0.5f
        val cy = h * 0.5f
        val stroke = (w * 0.085f).coerceAtLeast(1.8f)

        // 1. Primary outer arc (open on the right for forward chevron)
        drawArc(
            color = accentColor,
            startAngle = 42f,
            sweepAngle = 276f,
            useCenter = false,
            topLeft = Offset(w * 0.12f, h * 0.12f),
            size = Size(w * 0.76f, h * 0.76f),
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )

        // 2. Tilted orbital ring
        rotate(degrees = -24f, pivot = Offset(cx, cy)) {
            drawOval(
                color = accentColor.copy(alpha = 0.65f),
                topLeft = Offset(w * 0.05f, h * 0.34f),
                size = Size(w * 0.90f, h * 0.32f),
                style = Stroke(width = stroke * 0.72f)
            )
        }

        // 3. Central four-point electric spark
        val sparkR = w * 0.21f
        val innerR = w * 0.065f
        val sparkPath = Path().apply {
            moveTo(cx - w * 0.04f, cy - sparkR)
            lineTo(cx - w * 0.04f + innerR, cy - innerR)
            lineTo(cx - w * 0.04f + sparkR, cy)
            lineTo(cx - w * 0.04f + innerR, cy + innerR)
            lineTo(cx - w * 0.04f, cy + sparkR)
            lineTo(cx - w * 0.04f - innerR, cy + innerR)
            lineTo(cx - w * 0.04f - sparkR, cy)
            lineTo(cx - w * 0.04f - innerR, cy - innerR)
            close()
        }
        drawPath(sparkPath, color = accentColor)

        // 4. Forward-moving precision chevron
        val chevronPath = Path().apply {
            moveTo(w * 0.66f, h * 0.30f)
            lineTo(w * 0.88f, h * 0.50f)
            lineTo(w * 0.66f, h * 0.70f)
        }
        drawPath(
            path = chevronPath,
            color = chevronColor,
            style = Stroke(width = stroke * 1.1f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}
