package com.example.zeno.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ZenoBgPrimary
import com.example.ui.theme.ZenoBorder
import com.example.ui.theme.ZenoCardBg
import com.example.ui.theme.ZenoError
import com.example.ui.theme.ZenoTextPrimary
import com.example.ui.theme.ZenoTextSecondary
import com.example.zeno.data.local.TaskHistoryEntity
import com.example.zeno.data.local.TaskHistoryRepository
import com.example.zeno.ui.components.PlanStepRow
import com.example.zeno.ui.components.ZenoCard
import com.example.zeno.ui.components.formatElapsed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ActivityScreen(
    tasks: List<TaskHistoryEntity>,
    selectedTaskForDetail: TaskHistoryEntity?,
    onSelectTaskForDetail: (TaskHistoryEntity?) -> Unit,
    onReusePrompt: (String) -> Unit,
    onRetryTask: (String) -> Unit,
    onDeleteTask: (String) -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("All") }
    var showClearDialog by remember { mutableStateOf(false) }

    val filteredTasks = remember(tasks, searchQuery, statusFilter) {
        tasks.filter { item ->
            val matchesFilter = when (statusFilter) {
                "Completed" -> item.status == "Completed"
                "Paused" -> item.status == "Paused"
                "Stopped" -> item.status != "Completed" && item.status != "Paused"
                else -> true
            }
            val matchesSearch = searchQuery.isBlank() ||
                item.taskName.contains(searchQuery, ignoreCase = true) ||
                item.originalPrompt.contains(searchQuery, ignoreCase = true) ||
                item.targetAppName.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Task Activity",
                            style = MaterialTheme.typography.headlineMedium,
                            color = ZenoTextPrimary
                        )
                        Text(
                            text = "Verified runs, logs, and reusable automation prompts",
                            style = MaterialTheme.typography.bodySmall,
                            color = ZenoTextSecondary
                        )
                    }
                    if (tasks.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearDialog = true },
                            modifier = Modifier.testTag("activity_clear_all_btn")
                        ) {
                            Icon(
                                Icons.Rounded.DeleteSweep,
                                contentDescription = "Clear all history",
                                tint = ZenoError
                            )
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("activity_search_input"),
                    singleLine = true,
                    leadingIcon = {
                        Icon(Icons.Rounded.Search, contentDescription = null, tint = ZenoTextSecondary)
                    },
                    placeholder = { Text("Search tasks or apps...", color = ZenoTextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = ZenoBorder,
                        focusedContainerColor = ZenoCardBg,
                        unfocusedContainerColor = ZenoCardBg
                    ),
                    shape = MaterialTheme.shapes.small
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All", "Completed", "Paused", "Stopped").forEach { filter ->
                        FilterChip(
                            selected = statusFilter == filter,
                            onClick = { statusFilter = filter },
                            label = { Text(filter) }
                        )
                    }
                }
            }

            if (filteredTasks.isEmpty()) {
                item {
                    ZenoCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Rounded.History,
                                contentDescription = null,
                                tint = ZenoTextSecondary,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = "No matching activity",
                                style = MaterialTheme.typography.titleMedium,
                                color = ZenoTextPrimary
                            )
                            Text(
                                text = "Completed, paused, and stopped ZENO tasks appear here automatically.",
                                style = MaterialTheme.typography.bodySmall,
                                color = ZenoTextSecondary
                            )
                        }
                    }
                }
            } else {
                items(filteredTasks, key = { it.taskId }) { entry ->
                    HistoryDetailCard(
                        entry = entry,
                        onViewDetails = { onSelectTaskForDetail(entry) },
                        onReuse = { onReusePrompt(entry.originalPrompt) },
                        onRetry = { onRetryTask(entry.originalPrompt) },
                        onDelete = { onDeleteTask(entry.taskId) }
                    )
                }
            }
        }
    }

    if (selectedTaskForDetail != null) {
        TaskDetailsSheet(
            entry = selectedTaskForDetail,
            onDismiss = { onSelectTaskForDetail(null) },
            onReuse = {
                onReusePrompt(selectedTaskForDetail.originalPrompt)
                onSelectTaskForDetail(null)
            },
            onRetry = {
                onRetryTask(selectedTaskForDetail.originalPrompt)
                onSelectTaskForDetail(null)
            }
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = ZenoCardBg,
            titleContentColor = ZenoTextPrimary,
            textContentColor = ZenoTextSecondary,
            title = { Text("Clear task history?") },
            text = { Text("This permanently deletes all locally stored ZENO task logs and summaries.") },
            confirmButton = {
                TextButton(onClick = {
                    onClearAll()
                    showClearDialog = false
                }) {
                    Text("Clear", color = ZenoError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun HistoryDetailCard(
    entry: TaskHistoryEntity,
    onViewDetails: () -> Unit,
    onReuse: () -> Unit,
    onRetry: () -> Unit,
    onDelete: () -> Unit
) {
    val dateLabel = remember(entry.timestampMs) {
        SimpleDateFormat("MMM d, yyyy • HH:mm", Locale.getDefault()).format(Date(entry.timestampMs))
    }
    ZenoCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onViewDetails)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.taskName,
                    style = MaterialTheme.typography.titleMedium,
                    color = ZenoTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${entry.targetAppName} • $dateLabel",
                    style = MaterialTheme.typography.labelSmall,
                    color = ZenoTextSecondary
                )
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Rounded.DeleteOutline,
                    contentDescription = "Delete entry",
                    tint = ZenoTextSecondary
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = entry.originalPrompt,
            style = MaterialTheme.typography.bodySmall,
            color = ZenoTextPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Status: ${entry.status} • Duration: ${formatElapsed(entry.durationMs)} • Verified: ${entry.verifiedActions}/${entry.actionsPerformed} • Failed: ${entry.failedActions}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onViewDetails) { Text("Details") }
            OutlinedButton(onClick = onReuse) {
                Icon(Icons.Rounded.Replay, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Reuse")
            }
            Button(onClick = onRetry) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Retry")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailsSheet(
    entry: TaskHistoryEntity,
    onDismiss: () -> Unit,
    onReuse: () -> Unit,
    onRetry: () -> Unit
) {
    val plan = remember(entry.planJson) { TaskHistoryRepository.parsePlan(entry.planJson) }
    val logs = remember(entry.logsJson) { TaskHistoryRepository.parseLogs(entry.logsJson) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = ZenoCardBg,
        contentColor = ZenoTextPrimary
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(entry.taskName, style = MaterialTheme.typography.headlineSmall)
                Text(
                    "${entry.targetAppName} (${entry.targetAppPackage.ifBlank { "System" }}) • ${entry.status}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            item {
                ZenoCard(elevated = true) {
                    Text("ORIGINAL PROMPT", style = MaterialTheme.typography.labelSmall, color = ZenoTextSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text(entry.originalPrompt, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("SUMMARY", style = MaterialTheme.typography.labelSmall, color = ZenoTextSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text(entry.summary, style = MaterialTheme.typography.bodySmall, color = ZenoTextSecondary)
                }
            }
            if (plan.isNotEmpty()) {
                item {
                    Text("NEURAL PLAN", style = MaterialTheme.typography.labelMedium, color = ZenoTextSecondary)
                }
                items(plan, key = { it.id }) { step ->
                    PlanStepRow(step = step)
                }
            }
            if (logs.isNotEmpty()) {
                item {
                    Text("EXECUTION LOGS", style = MaterialTheme.typography.labelMedium, color = ZenoTextSecondary)
                }
                items(logs, key = { it.id }) { log ->
                    Text(
                        text = "[${log.phase}] ${log.message}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (log.isError) ZenoError else ZenoTextSecondary
                    )
                }
            }
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(onClick = onReuse, modifier = Modifier.weight(1f)) { Text("Reuse Prompt") }
                    Button(onClick = onRetry, modifier = Modifier.weight(1f)) { Text("Retry Task") }
                }
            }
        }
    }
}
