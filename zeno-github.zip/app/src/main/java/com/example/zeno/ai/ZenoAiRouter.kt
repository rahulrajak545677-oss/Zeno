package com.example.zeno.ai

import android.graphics.Bitmap
import com.example.zeno.core.model.AiDecisionResult
import com.example.zeno.core.model.PlanStep
import com.example.zeno.core.model.ScreenAnalysisReport
import com.example.zeno.core.model.ScreenObservation
import com.example.zeno.core.model.TaskMemory
import com.example.zeno.core.model.VerificationResult
import com.example.zeno.core.model.ZenoAction
import com.example.zeno.data.local.AiProviderType
import com.example.zeno.data.local.ZenoPreferencesRepository
import com.example.zeno.data.local.ZenoSettings
import com.example.zeno.data.repository.GeminiRepository
import kotlinx.coroutines.flow.first

class ZenoAiRouter(
    private val prefsRepo: ZenoPreferencesRepository
) {
    private val geminiRepository = GeminiRepository(prefsRepo = prefsRepo)
    private val firebaseProvider: ZenoAiProvider = FirebaseAiLogicProvider(
        geminiRepository = geminiRepository
    )

    @Volatile
    private var latestSettings: ZenoSettings = ZenoSettings()

    private val compatibleProvider: ZenoAiProvider = CompatibleRestAiProvider(
        endpointProvider = { latestSettings.customEndpointUrl },
        apiKeyProvider = { latestSettings.customApiKey },
        modelIdProvider = { latestSettings.customModelId }
    )

    private suspend fun activeProvider(): Pair<ZenoAiProvider, ZenoSettings> {
        val settings = prefsRepo.settingsFlow.first()
        latestSettings = settings
        val provider = when (settings.aiProviderType) {
            AiProviderType.FIREBASE_GEMINI -> firebaseProvider
            AiProviderType.CUSTOM_COMPATIBLE -> compatibleProvider
        }
        return provider to settings
    }

    suspend fun getActiveAIProvider(): AIProvider = activeProvider().first

    suspend fun testConnection(): Result<String> {
        val (provider, settings) = activeProvider()
        val result = provider.testConnection(settings.textModel)
        if (result.isSuccess && settings.aiProviderType != AiProviderType.FIREBASE_GEMINI) {
            prefsRepo.incrementAiCalls()
        }
        return result
    }

    suspend fun createNeuralPlan(
        instruction: String,
        observation: ScreenObservation?
    ): Result<List<PlanStep>> {
        val (provider, settings) = activeProvider()
        val result = provider.createNeuralPlan(instruction, observation, settings.textModel)
        if (result.isSuccess && settings.aiProviderType != AiProviderType.FIREBASE_GEMINI) {
            prefsRepo.incrementAiCalls()
        }
        return result
    }

    suspend fun decideNextAction(
        memory: TaskMemory,
        observation: ScreenObservation,
        screenshot: Bitmap?
    ): Result<AiDecisionResult> {
        val (provider, settings) = activeProvider()
        val result = provider.decideNextAction(
            memory = memory,
            observation = observation,
            screenshot = screenshot,
            textModel = settings.textModel,
            visionModel = settings.visionModel
        )
        if (result.isSuccess && settings.aiProviderType != AiProviderType.FIREBASE_GEMINI) {
            prefsRepo.incrementAiCalls()
        }
        return result
    }

    suspend fun verifyActionOutcome(
        action: ZenoAction,
        before: ScreenObservation,
        after: ScreenObservation,
        screenshot: Bitmap?
    ): Result<VerificationResult> {
        val (provider, settings) = activeProvider()
        val result = provider.verifyActionOutcome(
            action = action,
            before = before,
            after = after,
            screenshot = screenshot,
            modelName = settings.textModel
        )
        if (result.isSuccess && settings.aiProviderType != AiProviderType.FIREBASE_GEMINI) {
            prefsRepo.incrementAiCalls()
        }
        return result
    }

    suspend fun analyzeScreen(
        observation: ScreenObservation,
        screenshot: Bitmap?
    ): Result<ScreenAnalysisReport> {
        val (provider, settings) = activeProvider()
        val model = if (screenshot != null) settings.visionModel else settings.textModel
        val result = provider.analyzeScreen(observation, screenshot, model)
        if (result.isSuccess && settings.aiProviderType != AiProviderType.FIREBASE_GEMINI) {
            prefsRepo.incrementAiCalls()
        }
        return result
    }
}
