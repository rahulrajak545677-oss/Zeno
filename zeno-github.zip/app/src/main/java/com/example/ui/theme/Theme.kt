package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.zeno.data.local.AccentStyle

val ZenoShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ZenoTheme(
    darkTheme: Boolean = true,
    accentStyle: AccentStyle = AccentStyle.ELECTRIC_LIME,
    content: @Composable () -> Unit
) {
    val accentPrimary = Color(accentStyle.primaryHex)
    val accentSecondary = Color(accentStyle.secondaryHex)

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = accentPrimary,
            onPrimary = ZenoBgPrimary,
            primaryContainer = accentSecondary.copy(alpha = 0.22f),
            onPrimaryContainer = accentPrimary,
            secondary = accentSecondary,
            onSecondary = ZenoBgPrimary,
            secondaryContainer = ZenoElevatedBg,
            onSecondaryContainer = ZenoTextPrimary,
            tertiary = ZenoSuccess,
            onTertiary = ZenoBgPrimary,
            background = ZenoBgPrimary,
            onBackground = ZenoTextPrimary,
            surface = ZenoBgSecondary,
            onSurface = ZenoTextPrimary,
            surfaceVariant = ZenoCardBg,
            onSurfaceVariant = ZenoTextSecondary,
            surfaceContainerLowest = ZenoBgPrimary,
            surfaceContainerLow = ZenoBgSecondary,
            surfaceContainer = ZenoCardBg,
            surfaceContainerHigh = ZenoElevatedBg,
            surfaceContainerHighest = Color(0xFF282E28),
            outline = ZenoBorder,
            outlineVariant = ZenoBorder.copy(alpha = 0.65f),
            error = ZenoError,
            onError = ZenoBgPrimary
        )
    } else {
        darkColorScheme(
            primary = accentPrimary,
            onPrimary = ZenoBgPrimary,
            primaryContainer = accentSecondary.copy(alpha = 0.28f),
            onPrimaryContainer = accentPrimary,
            secondary = accentSecondary,
            onSecondary = ZenoBgPrimary,
            secondaryContainer = ZenoSoftCard,
            onSecondaryContainer = ZenoTextPrimary,
            tertiary = ZenoSuccess,
            onTertiary = ZenoBgPrimary,
            background = ZenoSoftSurface,
            onBackground = ZenoTextPrimary,
            surface = ZenoSoftCard,
            onSurface = ZenoTextPrimary,
            surfaceVariant = Color(0xFF252C25),
            onSurfaceVariant = ZenoTextSecondary,
            surfaceContainer = ZenoSoftCard,
            surfaceContainerHigh = Color(0xFF2B332B),
            outline = Color(0xFF364036),
            error = ZenoError,
            onError = ZenoBgPrimary
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = ZenoTypography,
        shapes = ZenoShapes,
        content = content
    )
}
