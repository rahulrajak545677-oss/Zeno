package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ZenoBgPrimary = Color(0xFF080A09)
val ZenoBgSecondary = Color(0xFF101310)
val ZenoCardBg = Color(0xFF171B17)
val ZenoElevatedBg = Color(0xFF202520)

val ZenoLimePrimary = Color(0xFFC6FF45)
val ZenoLimeSecondary = Color(0xFF93C42F)

val ZenoTextPrimary = Color(0xFFF4F6F0)
val ZenoTextSecondary = Color(0xFF9CA49A)
val ZenoBorder = Color(0xFF292F29)

val ZenoSuccess = Color(0xFFB9F936)
val ZenoWarning = Color(0xFFFFC857)
val ZenoError = Color(0xFFFF5B65)

// Secondary surface palette when Dark Theme toggle is switched to Graphite Light-Contrast
val ZenoSoftSurface = Color(0xFF141814)
val ZenoSoftCard = Color(0xFF1E241E)
